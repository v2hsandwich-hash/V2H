

import React from 'react';
import { OrderItemType, WeeklyMealPlan, DayOfWeek, MealType, DAYS_OF_WEEK, PLANNER_MEAL_TYPES } from '../types';

interface AddToPlanModalProps {
    orderItem: OrderItemType;
    onClose: () => void;
}

export const AddToPlanModal: React.FC<AddToPlanModalProps> = ({ orderItem, onClose }) => {

    const handleSelectSlot = (day: DayOfWeek, mealType: MealType) => {
        const phone = localStorage.getItem('currentUserPhone');
        if (!phone) {
            console.error("No current user phone found to save plan.");
            onClose();
            return;
        }

        try {
            const allPlansRaw = localStorage.getItem('weeklyMealPlans');
            const allPlans: Record<string, WeeklyMealPlan> = allPlansRaw ? JSON.parse(allPlansRaw) : {};
            const userPlan = allPlans[phone] || {};

            const updatedPlan: WeeklyMealPlan = {
                ...userPlan,
                [day]: {
                    ...(userPlan[day] || {}),
                    [mealType]: orderItem,
                }
            };
            
            allPlans[phone] = updatedPlan;
            localStorage.setItem('weeklyMealPlans', JSON.stringify(allPlans));
        } catch (e) {
            console.error("Failed to update meal plan:", e);
        }
        onClose();
    };

    return (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex justify-center items-center p-4" onClick={onClose}>
            <div 
                className="bg-gray-900/80 backdrop-blur-xl rounded-2xl shadow-lg w-full max-w-2xl border border-cyan-500/20 animate-fade-in-up" 
                onClick={e => e.stopPropagation()}
            >
                <div className="p-6 border-b border-gray-700 text-center">
                    <h3 className="text-2xl font-bold text-cyan-300">Thêm "{orderItem.menuItem.name}" vào Kế hoạch</h3>
                    <p className="text-sm text-gray-400 mt-1">Chọn một ngày và bữa ăn để thêm món này.</p>
                </div>
                <div className="p-6">
                    <div className="grid grid-cols-7 gap-2">
                        {DAYS_OF_WEEK.map(day => (
                            <div key={day} className="text-center">
                                <h4 className="font-bold text-cyan-400 text-sm mb-2">{day.replace('Thứ ', '')}</h4>
                                <div className="space-y-2">
                                    {PLANNER_MEAL_TYPES.map(mealType => (
                                        <button
                                            key={mealType}
                                            onClick={() => handleSelectSlot(day, mealType)}
                                            className="w-full text-xs p-2 rounded-md bg-gray-800/60 hover:bg-cyan-600 transition-colors text-gray-300 hover:text-white"
                                        >
                                            {mealType}
                                        </button>
                                    ))}
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
                 <div className="p-4 bg-gray-900/50 rounded-b-2xl border-t border-gray-700 text-right">
                    <button onClick={onClose} className="bg-gray-600 hover:bg-gray-500 text-white font-bold py-2 px-6 rounded-lg">
                        Hủy
                    </button>
                </div>
            </div>
        </div>
    );
};