import React, { useEffect, useRef } from 'react';
import { UserData, MenuItemType, Promotion } from '../types';
import { generatePromotionForUser, markPromotionAsShown } from '../utils/aiMarketingUtils';

interface AIMarketingEngineProps {
    user: UserData;
    menuItems: Record<string, MenuItemType[]>;
    onGeneratePromotion: (promotion: Promotion) => void;
}

export const AIMarketingEngine: React.FC<AIMarketingEngineProps> = ({ user, menuItems, onGeneratePromotion }) => {
    const hasRun = useRef(false);

    useEffect(() => {
        // Run only once per session/component mount
        if (hasRun.current || user.phone === 'guest') {
            return;
        }
        hasRun.current = true;

        // Delay the check to not be intrusive on page load
        const timer = setTimeout(() => {
            const promotion = generatePromotionForUser(user, menuItems);
            if (promotion) {
                onGeneratePromotion(promotion);
                markPromotionAsShown(user.phone);
            }
        }, 4000); // 4-second delay

        return () => clearTimeout(timer);
    }, [user, menuItems, onGeneratePromotion]);

    return null; // This component does not render anything
};
