

import React, { useState } from 'react';
import { StarIcon } from './Icons';

interface StarRatingProps {
    rating: number;
    onRate?: (rating: number) => void;
    readOnly?: boolean;
    size?: string;
    className?: string;
}

export const StarRating: React.FC<StarRatingProps> = ({ rating, onRate, readOnly = false, size = 'w-5 h-5', className = '' }) => {
    const [hoverRating, setHoverRating] = useState(0);

    const handleMouseEnter = (index: number) => {
        if (readOnly) return;
        setHoverRating(index);
    };

    const handleMouseLeave = () => {
        if (readOnly) return;
        setHoverRating(0);
    };

    const handleClick = (index: number) => {
        if (readOnly || !onRate) return;
        onRate(index);
    };
    
    return (
        <div role="group" aria-label={`Đánh giá: ${rating} trên 5 sao.`} className={`flex items-center ${className}`}>
            {[1, 2, 3, 4, 5].map((index) => {
                const currentRating = hoverRating || rating;
                const isFilled = index <= currentRating;
                return (
                    <button
                        key={index}
                        type="button"
                        aria-label={`Đánh giá ${index} sao`}
                        aria-pressed={!readOnly && index === rating}
                        title={readOnly ? `${rating} sao` : `Đánh giá ${index} sao`}
                        disabled={readOnly}
                        className={`p-0.5 rounded-full transition-colors focus:outline-none ${!readOnly ? 'cursor-pointer focus:ring-2 focus:ring-yellow-500 focus:ring-offset-2 focus:ring-offset-gray-900' : ''}`}
                        onMouseEnter={() => handleMouseEnter(index)}
                        onMouseLeave={handleMouseLeave}
                        onClick={() => handleClick(index)}
                    >
                        <StarIcon
                            className={`${size} transition-colors ${
                                isFilled ? 'text-yellow-400' : 'text-gray-500'
                            } ${!readOnly && isFilled ? 'hover:text-yellow-300' : ''}
                               ${!readOnly && !isFilled ? 'hover:text-yellow-400/50' : ''}
                            `}
                        />
                    </button>
                );
            })}
        </div>
    );
};