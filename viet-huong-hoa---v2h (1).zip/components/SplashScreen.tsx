
import React, { useState } from 'react';
import { generateSpeech } from '../services/geminiService';
import { decode, decodeAudioData, playAudio, unlockAudioContext } from '../utils/audioUtils';
import { SpinnerIcon } from './Icons';
import { Language } from '../types';

interface SplashScreenProps {
    onComplete: (language: Language) => void;
}

interface LanguageConfig {
    label: string;
    flag: string;
    welcomeTextDisplay: string;
    subTextDisplay: string;
    speechText: string;
    ctaText: string;
}

const LANGUAGE_DATA: Record<Language, LanguageConfig> = {
    vi: {
        label: 'Tiếng Việt',
        flag: '🇻🇳',
        welcomeTextDisplay: 'Việt Hương Hoa - Fastfood, Mealbox & Detox',
        subTextDisplay: 'Tinh hoa ẩm thực Việt • Công nghệ tương lai',
        speechText: "Chào mừng đến với Việt Hương Hoa - Fastfood, Mealbox & Detox! Chúng tôi mang đến giải pháp dinh dưỡng hiện đại đậm đà bản sắc Việt.",
        ctaText: 'KHÁM PHÁ NGAY'
    },
    en: {
        label: 'English',
        flag: '🇬🇧',
        welcomeTextDisplay: 'Viet Huong Hoa - Fastfood, Mealbox & Detox',
        subTextDisplay: 'Vietnamese Culinary Essence • Future Technology',
        speechText: "Welcome to Viet Huong Hoa - Fastfood, Mealbox & Detox! We bring modern nutritional solutions rich in Vietnamese identity.",
        ctaText: 'EXPLORE NOW'
    },
    zh: {
        label: '中文',
        flag: '🇨🇳',
        welcomeTextDisplay: '越香花 - 快餐、餐盒与排毒饮品',
        subTextDisplay: '越南烹饪精髓 • 未来科技',
        speechText: "欢迎来到越香花 - 快餐、餐盒与排毒饮品！我们为您带来富含越南特色的现代营养方案。",
        ctaText: '立即探索'
    },
    ja: {
        label: '日本語',
        flag: '🇯🇵',
        welcomeTextDisplay: 'ベト・フオン・ホア - ファストフード & デトックス',
        subTextDisplay: 'ベトナム料理の真髄 • 未来のテクノロジー',
        speechText: "ベト・フオン・ホアへようこそ！ベトナムのアイデンティティ豊かな現代的な栄養ソリューションをお届けします。",
        ctaText: '今すぐ探索'
    },
    ko: {
        label: '한국어',
        flag: '🇰🇷',
        welcomeTextDisplay: '비엣 흐엉 호아 - 패스트푸드 & 디톡스',
        subTextDisplay: '베트남 요리의 정수 • 미래 기술',
        speechText: "비엣 흐엉 호아에 오신 것을 환영합니다! 베트남의 정체성이 풍부한 현대적인 영양 솔루션을 제공합니다.",
        ctaText: '지금 탐색'
    },
    hi: {
        label: 'हिन्दी',
        flag: '🇮🇳',
        welcomeTextDisplay: 'वियत हुओंग होआ - फास्टफूड और डिटॉक्स',
        subTextDisplay: 'वियतनामी पाक सार • भविष्य की तकनीक',
        speechText: "वियत हुओंग होआ में आपका स्वागत है! हम वियतनामी पहचान से समृद्ध आधुनिक पोषण समाधान लाते हैं।",
        ctaText: 'अभी खोजें'
    }
};

export const SplashScreen: React.FC<SplashScreenProps> = ({ onComplete }) => {
    const [step, setStep] = useState<'logo' | 'welcome' | 'order'>('logo');
    const [isLoading, setIsLoading] = useState(false);
    const [selectedLang, setSelectedLang] = useState<Language>('vi');

    const handleLogoClick = async () => {
        // Unlock audio context immediately on user interaction (fix for mobile)
        await unlockAudioContext();

        setIsLoading(true);
        try {
            const currentLangData = LANGUAGE_DATA[selectedLang];
            const audioData = await generateSpeech(currentLangData.speechText);
            setStep('welcome');
            const duration = await playAudio(audioData);
            
            // Show the order button after the speech finishes, with a slight overlap
            setTimeout(() => {
                setStep('order');
            }, Math.max(0, (duration * 1000) - 500));

        } catch (error) {
            console.error(error);
            // If audio fails, just proceed after a short delay
            setStep('welcome');
            setTimeout(() => setStep('order'), 3000);
        } finally {
            setIsLoading(false);
        }
    };

    const handleOrderClick = async () => {
        // Ensure audio context is unlocked again just in case
        await unlockAudioContext();
        onComplete(selectedLang);
    };

    return (
        <div className="fixed inset-0 bg-transparent backdrop-blur-[2px] flex flex-col justify-center items-center text-center p-4 z-50 overflow-hidden animate-fade-in font-['Orbitron']">
            {/* Background is largely transparent to let the Cyber-DongSon pattern shine through */}
            
            <div className="z-20 flex flex-col items-center w-full max-w-3xl relative">
                {/* Logo and Button */}
                {(step === 'logo' || step === 'welcome' || step === 'order') && (
                    <div className="flex flex-col items-center gap-8">
                        <button 
                            onClick={handleLogoClick} 
                            disabled={step !== 'logo' || isLoading}
                            className="w-56 h-56 sm:w-72 sm:h-72 rounded-full bg-black/60 backdrop-blur-xl border border-cyan-500/50 flex flex-col justify-center items-center transition-all duration-500 hover:border-cyan-400 hover:shadow-[0_0_50px_rgba(34,211,238,0.4)] disabled:cursor-not-allowed relative overflow-hidden group shadow-[0_0_30px_rgba(6,182,212,0.2)]"
                        >
                             {/* Inner rotating rings for futuristic effect */}
                            <div className="absolute inset-2 border border-cyan-500/30 rounded-full animate-spin duration-[20s] border-dashed"></div>
                            <div className="absolute inset-6 border border-cyan-300/20 rounded-full animate-spin duration-[10s] direction-reverse border-dotted"></div>
                            
                            {/* Scanning line effect */}
                            <div className="absolute inset-0 bg-gradient-to-b from-transparent via-cyan-400/10 to-transparent h-[20%] w-full animate-[scan-line_3s_infinite_linear]"></div>

                            {isLoading ? (
                                <SpinnerIcon className="w-20 h-20 text-cyan-400" />
                            ) : (
                                <>
                                    <h1 className="text-6xl sm:text-7xl font-black text-transparent bg-clip-text bg-gradient-to-br from-cyan-300 via-white to-cyan-300 tracking-tighter drop-shadow-[0_0_10px_rgba(34,211,238,0.8)]">V2H</h1>
                                    <div className="h-0.5 w-24 bg-gradient-to-r from-transparent via-cyan-500 to-transparent my-4"></div>
                                    <p className="text-cyan-200 text-sm sm:text-base font-bold tracking-widest uppercase mb-1 drop-shadow-[0_0_5px_rgba(6,182,212,0.5)]">VIỆT HƯƠNG HOA</p>
                                    <p className="text-cyan-100 text-xs sm:text-sm tracking-[0.3em] uppercase">Cyber Nutrition</p>
                                </>
                            )}
                        </button>

                        {/* Language Selection (Only visible in 'logo' step) */}
                        {step === 'logo' && !isLoading && (
                            <div className="animate-fade-in-up space-y-4 w-full">
                                <p className="text-cyan-300 text-xs tracking-widest uppercase border-b border-cyan-900/50 pb-2 w-fit mx-auto px-6 bg-black/60 rounded-full backdrop-blur-sm">
                                    Chọn Ngôn Ngữ / Select Language
                                </p>
                                <div className="flex flex-wrap justify-center gap-3">
                                    {(Object.keys(LANGUAGE_DATA) as Language[]).map((code) => (
                                        <button
                                            key={code}
                                            onClick={() => setSelectedLang(code)}
                                            className={`flex items-center gap-2 px-4 py-2 rounded-lg border transition-all duration-300 relative overflow-hidden ${
                                                selectedLang === code
                                                    ? 'bg-cyan-900/40 border-cyan-400 text-cyan-50 shadow-[0_0_20px_rgba(34,211,238,0.3)]'
                                                    : 'bg-black/60 border-gray-800 text-gray-400 hover:border-cyan-700 hover:text-cyan-200'
                                            }`}
                                        >
                                            <span className="text-lg relative z-10">{LANGUAGE_DATA[code].flag}</span>
                                            <span className="text-sm font-bold relative z-10 font-sans">{LANGUAGE_DATA[code].label}</span>
                                            {selectedLang === code && <div className="absolute inset-0 bg-cyan-400/10 animate-pulse"></div>}
                                        </button>
                                    ))}
                                </div>
                            </div>
                        )}
                    </div>
                )}

                {/* Welcome Text */}
                {step === 'welcome' || step === 'order' ? (
                    <div className="mt-12 space-y-4 animate-fade-in-up bg-black/40 p-6 rounded-2xl backdrop-blur-md border border-cyan-500/30 shadow-[0_0_30px_rgba(0,0,0,0.5)] max-w-2xl mx-auto">
                        <p className="text-2xl sm:text-3xl font-bold text-white tracking-tight drop-shadow-[0_0_10px_rgba(34,211,238,0.5)] font-sans">
                            {LANGUAGE_DATA[selectedLang].welcomeTextDisplay}
                        </p>
                        <div className="h-px w-1/2 mx-auto bg-gradient-to-r from-transparent via-cyan-500 to-transparent"></div>
                        <p className="text-base sm:text-lg text-cyan-200 font-light font-sans tracking-wide">
                            {LANGUAGE_DATA[selectedLang].subTextDisplay}
                        </p>
                    </div>
                ) : null}

                {/* Order Button */}
                {step === 'order' ? (
                    <div className="mt-12 animate-fade-in" style={{ animationDelay: '0.5s' }}>
                        <button 
                            onClick={handleOrderClick}
                            className="relative overflow-hidden bg-cyan-600 hover:bg-cyan-500 text-white font-bold py-4 px-12 rounded-xl shadow-[0_0_30px_rgba(6,182,212,0.4)] text-lg transition-all duration-300 group hover:scale-105 border border-cyan-400"
                        >
                            <span className="relative z-10 uppercase tracking-[0.2em]">{LANGUAGE_DATA[selectedLang].ctaText}</span>
                            
                            {/* Tech scan effect on button */}
                            <div className="absolute inset-0 h-full w-full bg-gradient-to-r from-transparent via-white/30 to-transparent -translate-x-full group-hover:animate-[shimmer_1s_infinite]"></div>
                            <div className="absolute bottom-0 left-0 w-full h-1 bg-cyan-300"></div>
                        </button>
                    </div>
                ) : null}
            </div>
        </div>
    );
}
