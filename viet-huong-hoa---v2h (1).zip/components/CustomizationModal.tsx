
import React, { useState, useMemo, useEffect, useRef } from 'react';
import { MenuItemType, OrderItemType, SelectedOption, NutritionInfo, Customization, CustomizationOption, Language } from '../types';
import { getMenuItemTranslation } from '../constants';

interface CustomizationModalProps {
  item: MenuItemType;
  onClose: () => void;
  onConfirm: (item: OrderItemType) => void;
  language: Language;
}

export const CustomizationModal: React.FC<CustomizationModalProps> = ({ item, onClose, onConfirm, language }) => {
  const [quantity, setQuantity] = useState(1);
  const [selectedOptions, setSelectedOptions] = useState<SelectedOption[]>(() => {
    // Set default single-choice options
    const defaults: SelectedOption[] = [];
    item.customizations?.forEach(cust => {
        if (cust.type === 'single' && cust.options.length > 0) {
            defaults.push({ customizationId: cust.id, optionId: cust.options[0].id });
        }
    });
    return defaults;
  });

  const modalRef = useRef<HTMLDivElement>(null);
  const confirmButtonRef = useRef<HTMLButtonElement>(null);
  const { name, description } = getMenuItemTranslation(item, language);

  useEffect(() => {
    const previouslyFocusedElement = document.activeElement as HTMLElement;

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
      if (event.key === 'Tab' && modalRef.current) {
        // FIX: Explicitly cast NodeList to HTMLElement[] to fix type inference issues
        const focusableElements = (Array.from(
          modalRef.current.querySelectorAll(
            'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
          )
        ) as HTMLElement[]).filter(el => !el.hasAttribute('disabled'));
        
        if (focusableElements.length === 0) return;

        const firstElement = focusableElements[0];
        const lastElement = focusableElements[focusableElements.length - 1];

        if (event.shiftKey) { // Shift + Tab
          if (document.activeElement === firstElement) {
            lastElement.focus();
            event.preventDefault();
          }
        } else { // Tab
          if (document.activeElement === lastElement) {
            firstElement.focus();
            event.preventDefault();
          }
        }
      }
    };
    
    document.addEventListener('keydown', handleKeyDown);
    confirmButtonRef.current?.focus();

    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      previouslyFocusedElement?.focus();
    };
  }, [onClose]);

  const handleOptionChange = (customization: Customization, option: CustomizationOption) => {
    setSelectedOptions(prev => {
      const otherOptions = prev.filter(opt => opt.customizationId !== customization.id);
      if (customization.type === 'single') {
        return [...otherOptions, { customizationId: customization.id, optionId: option.id }];
      } else { // multiple
        const existing = prev.find(opt => opt.customizationId === customization.id && opt.optionId === option.id);
        if (existing) {
          return otherOptions; // Uncheck
        } else {
          const groupOptions = prev.filter(opt => opt.customizationId === customization.id);
          return [...otherOptions, ...groupOptions, { customizationId: customization.id, optionId: option.id }];
        }
      }
    });
  };
  
  const { totalPrice, totalNutrition } = useMemo(() => {
    let price = item.price;
    let nutrition: NutritionInfo = {
        calories: item.calories,
        carbs: item.carbs,
        protein: item.protein,
        fat: item.fat,
    };

    selectedOptions.forEach(selected => {
        const customization = item.customizations?.find(c => c.id === selected.customizationId);
        const option = customization?.options.find(o => o.id === selected.optionId);
        if (option) {
            price += option.priceChange;
            nutrition.calories += option.nutritionChange?.calories || 0;
            nutrition.carbs += option.nutritionChange?.carbs || 0;
            nutrition.protein += option.nutritionChange?.protein || 0;
            nutrition.fat += option.nutritionChange?.fat || 0;
        }
    });

    return {
        totalPrice: price * quantity,
        totalNutrition: {
            calories: nutrition.calories * quantity,
            carbs: nutrition.carbs * quantity,
            protein: nutrition.protein * quantity,
            fat: nutrition.fat * quantity,
        }
    };
  }, [item, quantity, selectedOptions]);

  const handleConfirm = () => {
    const orderItem: OrderItemType = {
      id: `${item.id}-${Date.now()}`,
      menuItem: item,
      quantity,
      selectedOptions,
      totalPrice,
      totalNutrition,
    };
    onConfirm(orderItem);
  };

  return (
    <div 
        className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex justify-center items-center p-4" 
        onClick={onClose}
        role="dialog"
        aria-modal="true"
        aria-labelledby="customization-modal-title"
    >
      <div 
        ref={modalRef}
        className="bg-gray-900/80 backdrop-blur-xl rounded-2xl shadow-lg w-full max-w-lg border border-cyan-500/20 animate-fade-in-up" 
        onClick={e => e.stopPropagation()}>
        <div className="p-6 border-b border-gray-700">
            <h3 id="customization-modal-title" className="text-2xl font-bold text-cyan-300">{name}</h3>
            <p className="text-sm text-gray-400 mt-1">{description}</p>
        </div>
        <div className="p-6 space-y-6 max-h-[60vh] overflow-y-auto">
          {item.customizations?.map(cust => (
            <fieldset key={cust.id}>
              <legend className="text-lg font-semibold text-cyan-400 mb-2">{cust.name}</legend>
              <div className="space-y-2">
                {cust.options.map(opt => {
                  const isChecked = selectedOptions.some(s => s.customizationId === cust.id && s.optionId === opt.id);
                  return (
                    <label key={opt.id} className={`flex items-center justify-between p-3 rounded-lg cursor-pointer transition-all ${isChecked ? 'bg-cyan-900/50 ring-2 ring-cyan-500' : 'bg-gray-800/60 hover:bg-gray-700/80'}`}>
                        <span>{opt.name}</span>
                        <input
                            type={cust.type === 'single' ? 'radio' : 'checkbox'}
                            name={cust.id}
                            checked={isChecked}
                            onChange={() => handleOptionChange(cust, opt)}
                            className="form-checkbox h-5 w-5 text-cyan-500 bg-gray-700 border-gray-600 focus:ring-cyan-600"
                        />
                    </label>
                  );
                })}
              </div>
            </fieldset>
          ))}
          <div>
            <h4 className="text-lg font-semibold text-cyan-400 mb-2">Số lượng</h4>
            <div className="flex items-center gap-4 bg-gray-800/60 rounded-lg p-2 max-w-[150px]">
                <button aria-label="Giảm số lượng" onClick={() => setQuantity(q => Math.max(1, q - 1))} className="text-2xl px-3 text-cyan-400 hover:text-white transition-colors">-</button>
                <input type="text" readOnly value={quantity} aria-label={`Số lượng hiện tại: ${quantity}`} className="w-12 bg-transparent text-center text-lg font-bold"/>
                <button aria-label="Tăng số lượng" onClick={() => setQuantity(q => q + 1)} className="text-2xl px-3 text-cyan-400 hover:text-white transition-colors">+</button>
            </div>
          </div>
        </div>
        <div className="p-6 bg-gray-900/50 rounded-b-2xl border-t border-gray-700 flex justify-between items-center">
            <div>
                <span className="text-sm text-gray-400">Tổng cộng</span>
                <p className="text-2xl font-bold text-cyan-400">{totalPrice.toLocaleString()}đ</p>
            </div>
            <button 
                ref={confirmButtonRef} 
                onClick={handleConfirm} 
                aria-label={`Thêm ${quantity} ${name} vào đơn hàng với giá ${totalPrice.toLocaleString()} đồng`}
                className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold py-3 px-8 rounded-lg shadow-lg shadow-cyan-500/20 transition-all">
                Thêm vào đơn
            </button>
        </div>
      </div>
    </div>
  );
};
