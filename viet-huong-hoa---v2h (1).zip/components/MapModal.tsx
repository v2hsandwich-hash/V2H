
import React, { useState } from 'react';
import { getDirections } from '../services/geminiService';
import { SpinnerIcon, LocationMarkerIcon } from './Icons';
import { Language, DirectionsResult } from '../types';
import { TRANSLATIONS } from '../constants';

interface MapModalProps {
    isOpen: boolean;
    onClose: () => void;
    language: Language;
}

const RESTAURANT_ADDRESS = "123 Đường Sức Khỏe, Quận Dinh Dưỡng, Thành phố Vui Vẻ";

export const MapModal: React.FC<MapModalProps> = ({ isOpen, onClose, language }) => {
    const [directionsResult, setDirectionsResult] = useState<DirectionsResult | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const t = TRANSLATIONS[language];

    const handleGetDirections = () => {
        setIsLoading(true);
        setError(null);
        setDirectionsResult(null);

        if (!navigator.geolocation) {
            setError("Geolocation not supported.");
            setIsLoading(false);
            return;
        }

        navigator.geolocation.getCurrentPosition(
            async (position) => {
                try {
                    const { latitude, longitude } = position.coords;
                    const result = await getDirections({ latitude, longitude }, language);
                    setDirectionsResult(result);
                } catch (err) {
                    setError((err as Error).message);
                } finally {
                    setIsLoading(false);
                }
            },
            (geoError) => {
                setError("Cannot get location: " + geoError.message);
                setIsLoading(false);
            }
        );
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex justify-center items-center p-4" onClick={onClose}>
            <div 
                className="bg-gray-900/80 backdrop-blur-xl rounded-2xl shadow-lg w-full max-w-2xl h-[90vh] flex flex-col border border-cyan-500/20 animate-fade-in-up" 
                onClick={e => e.stopPropagation()}
            >
                <header className="p-4 rounded-t-2xl flex justify-between items-center border-b border-gray-700">
                    <div className="flex items-center gap-3">
                        <LocationMarkerIcon className="w-6 h-6 text-cyan-400" />
                        {/* Title updated to 'contact' to match the navigation button */}
                        <h3 className="font-bold text-white text-xl">{t.contact}</h3>
                    </div>
                    <button onClick={onClose} className="text-gray-400 hover:text-white text-2xl leading-none">&times;</button>
                </header>
                
                <div className="flex-1 p-6 overflow-y-auto">
                    <div className="mb-6">
                        <img 
                            src="https://images.unsplash.com/photo-1566576721346-d4a3b4eaeb55?w=800&q=80" 
                            alt="Map"
                            className="w-full h-48 object-cover rounded-lg border-2 border-gray-700"
                        />
                        <div className="mt-4 text-center">
                            {/* Updated Restaurant Name */}
                            <p className="font-semibold text-gray-200 text-lg">Bánh mì Việt Hương Hoa</p>
                            <p className="text-cyan-300">{RESTAURANT_ADDRESS}</p>
                        </div>
                    </div>
                    
                    {!directionsResult && (
                         <div className="text-center">
                            <button 
                                onClick={handleGetDirections} 
                                disabled={isLoading}
                                className="w-full sm:w-auto flex justify-center items-center gap-2 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold py-3 px-6 rounded-lg shadow-lg shadow-cyan-500/20 transition-all duration-300 disabled:from-gray-500 disabled:to-gray-600 disabled:shadow-none"
                            >
                                {isLoading ? (
                                    <>
                                        <SpinnerIcon className="-ml-1 mr-2 h-5 w-5 text-white" />
                                        ...
                                    </>
                                ) : (
                                    <>
                                        <LocationMarkerIcon className="w-5 h-5" />
                                        {language === 'vi' ? 'Chỉ đường' : 'Get Directions'}
                                    </>
                                )}
                            </button>
                        </div>
                    )}
                    
                    {error && <div className="mt-4 text-center bg-red-500/20 border border-red-500 text-red-300 p-3 rounded-lg">{error}</div>}

                    {directionsResult && (
                        <div className="mt-6 animate-fade-in">
                            <h4 className="text-lg font-bold text-cyan-400 mb-3">{language === 'vi' ? 'Hướng dẫn:' : 'Directions:'}</h4>
                            <div className="prose prose-sm prose-invert bg-gray-800/50 p-4 rounded-lg border border-gray-700 max-w-none">
                                <ol className="list-decimal list-inside space-y-2">
                                    {directionsResult.directionsText.split('\n').filter(line => line.trim() !== '').map((step, index) => (
                                        <li key={index}>{step.replace(/^\d+\.\s*/, '')}</li>
                                    ))}
                                </ol>
                            </div>
                            {directionsResult.mapUrl && (
                                <a 
                                    href={directionsResult.mapUrl} 
                                    target="_blank" 
                                    rel="noopener noreferrer"
                                    className="mt-4 w-full block text-center bg-green-600 hover:bg-green-500 text-white font-bold py-3 px-4 rounded-lg transition-colors"
                                >
                                    {language === 'vi' ? 'Mở trong Google Maps' : 'Open in Google Maps'}
                                </a>
                            )}
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};
