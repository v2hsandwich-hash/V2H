
import React, { useState, useEffect, useRef } from 'react';
import { ChatMessage, MenuItemType, Language } from '../types';
import { getChatbotResponse, connectLive, createAudioBlob } from '../services/geminiService';
import { SparklesIcon, SpinnerIcon, MicrophoneIcon } from './Icons';
import { LiveServerMessage } from '@google/genai';
import { decode, decodeAudioData } from '../utils/audioUtils';

interface ChatbotProps {
    onClose: () => void;
    menuItems: Record<string, MenuItemType[]>;
    language: Language;
}

export const Chatbot: React.FC<ChatbotProps> = ({ onClose, menuItems, language }) => {
    const initialMsg = language === 'vi' ? 'Chào bạn! Tôi là trợ lý AI của V2H.' : 
                       language === 'en' ? 'Hello! I am V2H AI Assistant.' :
                       language === 'zh' ? '你好！我是V2H人工智能助手。' :
                       language === 'ja' ? 'こんにちは！V2H AIアシスタントです。' :
                       language === 'ko' ? '안녕하세요! V2H AI 어시스턴트입니다.' :
                       'नमस्ते! मैं V2H AI सहायक हूँ।';

    const [messages, setMessages] = useState<ChatMessage[]>([
        { sender: 'bot', text: initialMsg }
    ]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    const [isRecording, setIsRecording] = useState(false);
    const [currentUserTranscription, setCurrentUserTranscription] = useState('');
    const [currentBotTranscription, setCurrentBotTranscription] = useState('');

    const sessionPromiseRef = useRef<Promise<any> | null>(null);
    const inputAudioContextRef = useRef<AudioContext | null>(null);
    const outputAudioContextRef = useRef<AudioContext | null>(null);
    const mediaStreamRef = useRef<MediaStream | null>(null);
    const scriptProcessorRef = useRef<ScriptProcessorNode | null>(null);
    const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
    const nextStartTimeRef = useRef(0);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    };

    useEffect(scrollToBottom, [messages, currentUserTranscription, currentBotTranscription]);

    const handleSendMessage = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!input.trim() || isLoading) return;

        const userMessage: ChatMessage = { sender: 'user', text: input };
        setMessages(prev => [...prev, userMessage]);
        setInput('');
        setIsLoading(true);

        try {
            const history = [...messages, userMessage];
            const botResponseText = await getChatbotResponse(input, history, menuItems, language);
            const botMessage: ChatMessage = { sender: 'bot', text: botResponseText };
            setMessages(prev => [...prev, botMessage]);
        } catch (error) {
            console.error("Chatbot error:", error);
            const errorMessage: ChatMessage = { sender: 'bot', text: 'Error. Please try again.' };
            setMessages(prev => [...prev, errorMessage]);
        } finally {
            setIsLoading(false);
        }
    };

    const stopRecording = async () => {
        if (sessionPromiseRef.current) {
            try {
                const session = await sessionPromiseRef.current;
                if (session && typeof session.close === 'function') {
                    session.close();
                }
            } catch (e) {
                console.warn("Session creation failed or already closed:", e);
            }
            sessionPromiseRef.current = null;
        }
        
        if (mediaStreamRef.current) {
            mediaStreamRef.current.getTracks().forEach(track => track.stop());
            mediaStreamRef.current = null;
        }
        
        if (scriptProcessorRef.current) {
            try {
                scriptProcessorRef.current.disconnect();
            } catch (e) { /* ignore */ }
            scriptProcessorRef.current = null;
        }
        
        if (inputAudioContextRef.current && inputAudioContextRef.current.state !== 'closed') {
            try {
                await inputAudioContextRef.current.close();
            } catch (e) { /* ignore */ }
        }
        
        if (outputAudioContextRef.current && outputAudioContextRef.current.state !== 'closed') {
            try {
                await outputAudioContextRef.current.close();
            } catch (e) { /* ignore */ }
        }
        
        setIsRecording(false);
        setCurrentUserTranscription('');
        setCurrentBotTranscription('');
    };

    const startRecording = async () => {
        try {
            if (isRecording) {
                await stopRecording();
                return;
            }

            setIsRecording(true);
            
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            mediaStreamRef.current = stream;

            inputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
            outputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
            
            sourcesRef.current = new Set();
            nextStartTimeRef.current = 0;
            
            // Ensure we handle the promise carefully
            sessionPromiseRef.current = connectLive({
                onopen: () => {
                    if (!inputAudioContextRef.current) return;
                    const source = inputAudioContextRef.current.createMediaStreamSource(stream);
                    const scriptProcessor = inputAudioContextRef.current.createScriptProcessor(4096, 1, 1);
                    scriptProcessorRef.current = scriptProcessor;

                    scriptProcessor.onaudioprocess = (audioProcessingEvent) => {
                        if (!sessionPromiseRef.current) return;
                        
                        const inputData = audioProcessingEvent.inputBuffer.getChannelData(0);
                        const pcmBlob = createAudioBlob(inputData);
                        
                        sessionPromiseRef.current.then((session) => {
                            try {
                                session.sendRealtimeInput({ media: pcmBlob });
                            } catch (e) {
                                console.warn("Error sending audio input:", e);
                            }
                        }).catch(() => {
                            // Ignore errors if session failed
                        });
                    };
                    source.connect(scriptProcessor);
                    scriptProcessor.connect(inputAudioContextRef.current.destination);
                },
                onmessage: async (message: LiveServerMessage) => {
                    if (message.serverContent?.outputTranscription) {
                        const text = message.serverContent.outputTranscription.text;
                        setCurrentBotTranscription(prev => prev + text);
                    } else if (message.serverContent?.inputTranscription) {
                        const text = message.serverContent.inputTranscription.text;
                        setCurrentUserTranscription(prev => prev + text);
                    }

                    if (message.serverContent?.turnComplete) {
                        const finalUserText = currentUserTranscription;
                        const finalBotText = currentBotTranscription;
                        
                        setMessages(prev => {
                            const newMessages = [...prev];
                            if (finalUserText.trim()) newMessages.push({ sender: 'user', text: finalUserText });
                            if (finalBotText.trim()) newMessages.push({ sender: 'bot', text: finalBotText });
                            return newMessages;
                        });

                        setCurrentUserTranscription('');
                        setCurrentBotTranscription('');
                    }

                    const base64Audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
                    if (base64Audio && outputAudioContextRef.current) {
                        const outputAudioContext = outputAudioContextRef.current;
                        nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outputAudioContext.currentTime);
                        try {
                            const audioBuffer = await decodeAudioData(decode(base64Audio), outputAudioContext, 24000, 1);
                            const sourceNode = outputAudioContext.createBufferSource();
                            sourceNode.buffer = audioBuffer;
                            sourceNode.connect(outputAudioContext.destination);
                            sourceNode.addEventListener('ended', () => { sourcesRef.current.delete(sourceNode); });
                            sourceNode.start(nextStartTimeRef.current);
                            nextStartTimeRef.current += audioBuffer.duration;
                            sourcesRef.current.add(sourceNode);
                        } catch (e) {
                            console.error("Audio decode error:", e);
                        }
                    }
                    
                    if (message.serverContent?.interrupted) {
                        for (const source of sourcesRef.current.values()) {
                          try { source.stop(); } catch(e) {}
                          sourcesRef.current.delete(source);
                        }
                        nextStartTimeRef.current = 0;
                    }
                },
                onerror: (e: ErrorEvent) => {
                    console.error('Live session error:', e);
                    setMessages(prev => [...prev, { sender: 'bot', text: 'Connection Error.' }]);
                    stopRecording();
                },
                onclose: (e: CloseEvent) => {
                    console.debug('Live session closed', e);
                    stopRecording();
                },
            }, language);
        } catch (err) {
            console.error("Failed to start recording:", err);
            setMessages(prev => [...prev, { sender: 'bot', text: 'Mic Error.' }]);
            setIsRecording(false);
        }
    };

    useEffect(() => {
        return () => {
            stopRecording();
        };
    }, []);

    return (
        <div className="fixed bottom-24 right-6 w-full max-w-sm h-[70vh] z-50 animate-fade-in-up">
            <div className="bg-gray-900/80 backdrop-blur-xl rounded-2xl shadow-2xl shadow-cyan-900/20 w-full h-full flex flex-col border border-cyan-500/30">
                <header className="p-4 rounded-t-2xl flex justify-between items-center border-b border-gray-700">
                    <div className="flex items-center gap-2">
                        <SparklesIcon className="w-6 h-6 text-cyan-400" />
                        <h3 className="font-bold text-white">V2H AI Assistant</h3>
                    </div>
                    <button onClick={onClose} className="text-gray-400 hover:text-white text-2xl leading-none">&times;</button>
                </header>
                <div className="flex-1 p-4 overflow-y-auto space-y-4">
                    {messages.map((msg, index) => (
                        <div key={index} className={`flex items-end gap-2 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                            {msg.sender === 'bot' && <SparklesIcon className="w-6 h-6 text-cyan-500 flex-shrink-0 mb-2" />}
                            <div className={`max-w-[80%] p-3 rounded-2xl ${msg.sender === 'user' ? 'bg-gradient-to-br from-cyan-600 to-blue-600 text-white rounded-br-none' : 'bg-gray-800/80 text-gray-200 rounded-bl-none'}`}>
                                <p className="text-sm">{msg.text}</p>
                            </div>
                        </div>
                    ))}
                    {isLoading && (
                         <div className="flex items-end gap-2 justify-start">
                             <SparklesIcon className="w-6 h-6 text-cyan-500 flex-shrink-0 mb-2" />
                            <div className="max-w-[80%] p-3 rounded-2xl bg-gray-800/80 text-gray-200 rounded-bl-none">
                                <SpinnerIcon className="w-5 h-5" />
                            </div>
                        </div>
                    )}
                    <div ref={messagesEndRef} />
                </div>
                <div className="p-4 border-t border-gray-700">
                    {isRecording && (
                        <div className="h-16 text-sm text-gray-300 overflow-y-auto mb-2 p-2 bg-gray-800/50 rounded-lg">
                            {currentUserTranscription && <div><span className="font-bold text-cyan-400">User: </span> {currentUserTranscription}</div>}
                            {currentBotTranscription && <div><span className="font-bold text-white">AI: </span> {currentBotTranscription}</div>}
                            {(!currentUserTranscription && !currentBotTranscription) && <div className="text-gray-500">Listening...</div>}
                        </div>
                    )}
                    <form onSubmit={handleSendMessage} className="flex items-center gap-2">
                        <input
                            type="text"
                            value={input}
                            onChange={e => setInput(e.target.value)}
                            placeholder={isRecording ? "..." : "..."}
                            className="w-full bg-gray-800 text-white p-3 rounded-lg border border-gray-600 focus:ring-2 focus:ring-cyan-500"
                            disabled={isLoading || isRecording}
                        />
                         <button
                            type="button"
                            onClick={isRecording ? stopRecording : startRecording}
                            className={`p-3 rounded-full transition-colors ${isRecording ? 'bg-red-500 text-white animate-pulse' : 'bg-cyan-600 text-white hover:bg-cyan-500'}`}
                        >
                            <MicrophoneIcon className="w-6 h-6" />
                        </button>
                    </form>
                </div>
            </div>
        </div>
    );
};
