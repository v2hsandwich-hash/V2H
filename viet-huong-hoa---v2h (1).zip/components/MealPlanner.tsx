
import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { AnalysisResult, WeeklyMealPlan, DayOfWeek, MealType, OrderItemType, DAYS_OF_WEEK, PLANNER_MEAL_TYPES, AlertLevel, MenuItemType, AIPlanResponse, NutritionInfo, UserData, Language } from '../types';
import { CalendarIcon, PlusIcon, TrashIcon, AlertIcon, SparklesIcon, SpinnerIcon, ShareIcon, ClockIcon } from './Icons';
import { MealSelectorModal } from './MealSelectorModal';
import { WeeklyNutritionSummary } from './WeeklyNutritionSummary';
import { generateMealPlan } from '../services/geminiService';
import { MEAL_TYPE_TRANSLATIONS, TRANSLATIONS, getMenuItemTranslation, DAY_TRANSLATIONS } from '../constants';

interface MealPlannerProps {
  analysis: AnalysisResult;
  onBack: () => void;
  onAddPlanToOrder: (plan: WeeklyMealPlan) => void;
  onAwardAchievement: (achievementId: string) => void;
  currentUser: UserData;
  menuItems: Record<string, MenuItemType[]>;
  language: Language;
}

interface MealSlotProps {
    meal: OrderItemType | null;
    onAdd: () => void;
    onRemove: () => void;
    alertLevel: AlertLevel | null;
    language: Language;
}

const MealSlot: React.FC<MealSlotProps> = ({ meal, onAdd, onRemove, alertLevel, language }) => {
    if (meal) {
        const alertClasses = {
            [AlertLevel.Red]: 'text-fuchsia-500',
            [AlertLevel.Yellow]: 'text-amber-500',
            [AlertLevel.Green]: '', // Not used
        };
        const { name } = getMenuItemTranslation(meal.menuItem, language);
        
        return (
            <div className="bg-gray-800/70 rounded-lg p-2 relative group h-full flex flex-col justify-center border border-transparent hover:border-cyan-500/50 transition-colors">
                 {alertLevel && (
                    <div className="absolute -top-1 -left-1" title={alertLevel === AlertLevel.Red ? "Bữa ăn này chứa rất nhiều calo so với mục tiêu hàng ngày" : "Bữa ăn này chứa nhiều calo so với mục tiêu hàng ngày"}>
                        <AlertIcon className={`w-5 h-5 ${alertClasses[alertLevel]}`} />
                    </div>
                )}
                <div className="flex items-center gap-2">
                    <img src={meal.menuItem.image} alt={name} className="w-10 h-10 object-cover rounded-lg flex-shrink-0" loading="lazy" />
                    <div className="flex-grow text-left overflow-hidden">
                        <p className="text-sm font-semibold text-white truncate" title={name}>{name}</p>
                        <p className="text-xs text-cyan-400 mt-1">{meal.totalNutrition.calories} kcal</p>
                    </div>
                </div>
                <button 
                    onClick={onRemove} 
                    className="absolute -top-2 -right-2 bg-red-600 text-white rounded-full p-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
                </button>
            </div>
        );
    }
    return (
        <button onClick={onAdd} className="w-full h-full border-2 border-dashed border-gray-600 rounded-lg flex flex-col justify-center items-center text-gray-500 hover:bg-gray-700/50 hover:border-gray-500 transition-colors">
            <PlusIcon className="w-5 h-5 mb-1" />
            <span className="text-xs">{TRANSLATIONS[language].add_dish}</span>
        </button>
    );
};

const DailyStat: React.FC<{ label: string; value: string; colorClass: string }> = ({ label, value, colorClass }) => (
    <div className="bg-gray-900/50 p-2 rounded">
        <p className="text-xs text-gray-400">{label}</p>
        <p className={`font-bold text-sm ${colorClass}`}>{value}</p>
    </div>
);

// --- NEW: Advanced Time Scheduler Components ---

const HOURS = Array.from({ length: 24 }, (_, i) => i.toString().padStart(2, '0'));
const MINUTES = Array.from({ length: 12 }, (_, i) => (i * 5).toString().padStart(2, '0'));

interface ScrollColumnProps {
    items: string[];
    selectedValue: string;
    onSelect: (val: string) => void;
    label: string;
}

// Extracted ScrollColumn to prevent re-mounting on every render/selection
const ScrollColumn: React.FC<ScrollColumnProps> = React.memo(({ items, selectedValue, onSelect, label }) => {
    const containerRef = useRef<HTMLDivElement>(null);

    // Scroll to initial value on mount
    useEffect(() => {
        if (containerRef.current) {
            const index = items.indexOf(selectedValue);
            if (index !== -1) {
                containerRef.current.scrollTop = index * 32;
            }
        }
    }, []);

    return (
        <div className="flex flex-col h-40 w-16 overflow-hidden relative group bg-gray-900/40 rounded-lg border border-gray-700">
            <div className="absolute inset-x-0 top-0 h-14 bg-gradient-to-b from-gray-900 via-gray-900/80 to-transparent z-10 pointer-events-none"></div>
            <div className="absolute inset-x-0 bottom-0 h-14 bg-gradient-to-t from-gray-900 via-gray-900/80 to-transparent z-10 pointer-events-none"></div>
            <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 h-8 border-y border-cyan-500/50 bg-cyan-500/10 z-0 pointer-events-none"></div>
            
            <div 
                ref={containerRef}
                className="overflow-y-auto snap-y snap-mandatory h-full no-scrollbar" 
                onScroll={(e) => {
                    const target = e.target as HTMLDivElement;
                    const itemHeight = 32; 
                    const index = Math.round(target.scrollTop / itemHeight);
                    if (items[index] && items[index] !== selectedValue) {
                         onSelect(items[index]);
                    }
                 }}
            >
                <div className="h-[64px] w-full flex-shrink-0"></div>
                {items.map((item) => (
                    <div 
                        key={item} 
                        onClick={() => {
                            if (containerRef.current) {
                                const index = items.indexOf(item);
                                containerRef.current.scrollTo({ top: index * 32, behavior: 'smooth' });
                            }
                            onSelect(item);
                        }}
                        className={`h-8 flex items-center justify-center snap-center cursor-pointer transition-all duration-200 select-none ${item === selectedValue ? 'text-cyan-300 font-bold text-lg scale-110' : 'text-gray-500 text-sm'}`}
                    >
                        {item}
                    </div>
                ))}
                <div className="h-[64px] w-full flex-shrink-0"></div>
            </div>
            <div className="absolute -top-2 w-full text-center text-[10px] text-gray-500 uppercase font-bold bg-gray-900 rounded-t-lg py-1 z-20">{label}</div>
        </div>
    );
});

// 1. Vertical Time Roller (Hours & Minutes)
const TimeRoller = () => {
    const [selectedHour, setSelectedHour] = useState('12');
    const [selectedMinute, setSelectedMinute] = useState('30');

    return (
        <div className="flex items-center gap-2 p-4 bg-gray-800/30 rounded-xl border border-gray-700/50 shadow-inner">
            <ScrollColumn label="Giờ" items={HOURS} selectedValue={selectedHour} onSelect={setSelectedHour} />
            <div className="text-2xl font-bold text-cyan-500 -mt-4">:</div>
            <ScrollColumn label="Phút" items={MINUTES} selectedValue={selectedMinute} onSelect={setSelectedMinute} />
        </div>
    );
};

// 2. Calendar View (Month/Year/Day)
interface CalendarViewProps {
    currentDayIndex: number;
    onChangeDay: (index: number) => void;
    language: Language;
}

const CalendarView: React.FC<CalendarViewProps> = ({ currentDayIndex, onChangeDay, language }) => {
    const [currentDate, setCurrentDate] = useState(new Date());
    const [selectedDate, setSelectedDate] = useState(new Date());

    const daysInMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0).getDate();
    const firstDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1).getDay(); // 0 = Sun, 1 = Mon...
    
    // Adjust for Monday start: 0->6, 1->0, ...
    const startDayOffset = firstDayOfMonth === 0 ? 6 : firstDayOfMonth - 1;

    const weekDays = ['T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN'];

    const handleDateClick = (day: number) => {
        const newDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), day);
        setSelectedDate(newDate);
        
        // Convert JS Date Day (0=Sun...6=Sat) to App DayIndex (0=Mon...6=Sun)
        const jsDay = newDate.getDay();
        const appDayIndex = jsDay === 0 ? 6 : jsDay - 1;
        onChangeDay(appDayIndex);
    };

    const changeMonth = (delta: number) => {
        setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + delta, 1));
    };

    return (
        <div className="flex-1 bg-gray-800/30 rounded-xl border border-gray-700/50 p-4 shadow-inner min-w-[300px]">
            {/* Month Header */}
            <div className="flex justify-between items-center mb-4">
                <button onClick={() => changeMonth(-1)} className="p-1 hover:bg-gray-700 rounded text-gray-400 hover:text-white">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
                </button>
                <h4 className="text-white font-bold">Tháng {currentDate.getMonth() + 1}, {currentDate.getFullYear()}</h4>
                <button onClick={() => changeMonth(1)} className="p-1 hover:bg-gray-700 rounded text-gray-400 hover:text-white">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>
                </button>
            </div>

            {/* Days Grid */}
            <div className="grid grid-cols-7 gap-1 text-center">
                {weekDays.map(d => (
                    <div key={d} className="text-xs text-gray-500 font-semibold mb-2">{d}</div>
                ))}
                {Array.from({ length: startDayOffset }).map((_, i) => (
                    <div key={`empty-${i}`} className="h-8"></div>
                ))}
                {Array.from({ length: daysInMonth }).map((_, i) => {
                    const day = i + 1;
                    const dateToCheck = new Date(currentDate.getFullYear(), currentDate.getMonth(), day);
                    const isSelected = dateToCheck.toDateString() === selectedDate.toDateString();
                    const isToday = dateToCheck.toDateString() === new Date().toDateString();

                    return (
                        <button 
                            key={day} 
                            onClick={() => handleDateClick(day)}
                            className={`h-8 w-8 mx-auto rounded-full flex items-center justify-center text-sm transition-all ${
                                isSelected 
                                    ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-500/30 font-bold' 
                                    : isToday 
                                        ? 'border border-cyan-500 text-cyan-400' 
                                        : 'text-gray-300 hover:bg-gray-700'
                            }`}
                        >
                            {day}
                        </button>
                    );
                })}
            </div>
        </div>
    );
};

const AdvancedTimeScheduler: React.FC<CalendarViewProps> = (props) => {
    return (
        <div className="bg-gray-950/80 backdrop-blur-md border border-cyan-900/50 rounded-2xl p-6 mb-8 shadow-2xl flex flex-col md:flex-row gap-6 items-start relative overflow-hidden">
             {/* Decorative Grid Background */}
             <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:14px_24px] pointer-events-none"></div>
             
             <div className="z-10 flex flex-col gap-2 items-center md:items-start">
                <h3 className="text-sm font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-2 mb-1">
                    <ClockIcon className="w-4 h-4" /> {TRANSLATIONS[props.language].time_setting}
                </h3>
                <TimeRoller />
             </div>

             <div className="hidden md:block w-px bg-gray-800 self-stretch mx-2"></div>

             <div className="z-10 flex-1 w-full">
                <h3 className="text-sm font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-2 mb-3">
                    <CalendarIcon className="w-4 h-4" /> {TRANSLATIONS[props.language].schedule}
                </h3>
                <CalendarView {...props} />
             </div>
        </div>
    );
};


export const MealPlanner: React.FC<MealPlannerProps> = ({ analysis, onBack, onAddPlanToOrder, onAwardAchievement, currentUser, menuItems, language }) => {
    const phone = currentUser.phone;
    const [plan, setPlan] = useState<WeeklyMealPlan>({});
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [modalContext, setModalContext] = useState<{ day: DayOfWeek; mealType: MealType } | null>(null);
    const [isGenerating, setIsGenerating] = useState(false);
    const [currentDayIndex, setCurrentDayIndex] = useState(() => {
        const day = new Date().getDay();
        return day === 0 ? 6 : day - 1; // Default to today
    });
    const [showCopiedTooltip, setShowCopiedTooltip] = useState(false);

    const t = TRANSLATIONS[language];
    const currentDay: DayOfWeek = DAYS_OF_WEEK[currentDayIndex];

    const dailyNutrition = useMemo(() => {
        const totals: NutritionInfo = { calories: 0, carbs: 0, protein: 0, fat: 0 };
        const dailyPlan = plan[currentDay];
        if (!dailyPlan) return totals;

        Object.values(dailyPlan).forEach(meal_unknown => {
            const meal = meal_unknown as OrderItemType | null;
            if (meal) {
                totals.calories += meal.totalNutrition.calories;
                totals.carbs += meal.totalNutrition.carbs;
                totals.protein += meal.totalNutrition.protein;
                totals.fat += meal.totalNutrition.fat;
            }
        });
        return totals;
    }, [plan, currentDay]);


    useEffect(() => {
        try {
            const allPlans = JSON.parse(localStorage.getItem('weeklyMealPlans') || '{}');
            const savedPlan = allPlans[phone];
            if (savedPlan) {
                setPlan(savedPlan);
            } else {
                setPlan({});
            }
        } catch (e) {
            console.error("Failed to load meal plan:", e);
        }
    }, [phone]);

    useEffect(() => {
        try {
            const allPlans = JSON.parse(localStorage.getItem('weeklyMealPlans') || '{}');
            allPlans[phone] = plan;
            localStorage.setItem('weeklyMealPlans', JSON.stringify(allPlans));
            
            const isPlanComplete = DAYS_OF_WEEK.every(day => {
                const dailyPlan = plan[day];
                return dailyPlan && Object.values(dailyPlan).some(meal => meal !== null);
            });

            if (isPlanComplete) {
                onAwardAchievement('master_planner');
            }

        } catch (e) {
            console.error("Failed to save meal plan:", e);
        }
    }, [plan, phone, onAwardAchievement]);

    const getMealAlertLevel = useCallback((meal: OrderItemType | null): AlertLevel | null => {
        if (!meal || !analysis) return null;

        const dailyCalorieGoal = analysis.energyNeeds.calories;
        const mealCalories = meal.totalNutrition.calories;
        const ratio = mealCalories / dailyCalorieGoal;

        if (ratio > 0.5) return AlertLevel.Red;
        if (ratio > 0.4) return AlertLevel.Yellow;

        return null;
    }, [analysis]);


    const handleOpenModal = (day: DayOfWeek, mealType: MealType) => {
        setModalContext({ day, mealType });
        setIsModalOpen(true);
    };

    const handleSelectMeal = (item: OrderItemType) => {
        if (!modalContext) return;
        const { day, mealType } = modalContext;
        setPlan(prevPlan => ({
            ...prevPlan,
            [day]: {
                ...prevPlan[day],
                [mealType]: item,
            }
        }));
        setIsModalOpen(false);
        setModalContext(null);
    };

    const handleRemoveMeal = (day: DayOfWeek, mealType: MealType) => {
         setPlan(prevPlan => ({
            ...prevPlan,
            [day]: {
                ...prevPlan[day],
                [mealType]: null,
            }
        }));
    };

    const handleClearPlan = () => {
        if (window.confirm('Bạn có chắc muốn xóa toàn bộ kế hoạch tuần này?')) {
            setPlan({});
        }
    };

    const handleSharePlan = () => {
        let summary = `Kế hoạch ăn uống của tôi tại V2H - Sandwich, Mealbox & Detox:\n\n`;
        let totalCalories = 0;
        let plannedDays = 0;

        DAYS_OF_WEEK.forEach(day => {
            const dailyPlan = plan[day];
            if(dailyPlan && Object.values(dailyPlan).some(m => m !== null)) {
                summary += `📅 ${day}:\n`;
                let dailyCalories = 0;
                PLANNER_MEAL_TYPES.forEach(mealType => {
                    const meal = dailyPlan[mealType];
                    if (meal) {
                        summary += `  - ${mealType}: ${meal.menuItem.name} (${meal.totalNutrition.calories} kcal)\n`;
                        dailyCalories += meal.totalNutrition.calories;
                    }
                });
                totalCalories += dailyCalories;
                plannedDays++;
            }
        });

        if (plannedDays > 0) {
            const avgCalories = Math.round(totalCalories / plannedDays);
            summary += `\n✨ Trung bình: ${avgCalories.toLocaleString()} kcal/ngày. Hãy cùng sống khỏe!`;
        } else {
            summary = "Tôi đang lên kế hoạch ăn uống tại V2H. Hãy tham gia cùng tôi!";
        }

        navigator.clipboard.writeText(summary).then(() => {
            setShowCopiedTooltip(true);
            setTimeout(() => setShowCopiedTooltip(false), 2000);
        });
    };

    const handleGeneratePlan = async () => {
        if (!window.confirm('AI sẽ tạo một kế hoạch ăn uống cho cả tuần. Kế hoạch hiện tại của bạn sẽ bị ghi đè. Bạn có muốn tiếp tục không?')) {
            return;
        }

        setIsGenerating(true);
        try {
            const aiPlan = await generateMealPlan(analysis, menuItems, language);

            // FIX: Explicitly cast Object.values result to resolve 'unknown' type error in reduce
            const allItems: MenuItemType[] = (Object.values(menuItems) as MenuItemType[][]).reduce<MenuItemType[]>((acc, val) => acc.concat(val), []);
            const menuMap = new Map<string, MenuItemType>(allItems.map(item => [item.id, item]));

            const newPlan: WeeklyMealPlan = {};
            
            for (const day of DAYS_OF_WEEK) {
                const dailyAiPlan = aiPlan[day];
                if (!dailyAiPlan) continue;

                newPlan[day] = {};
                
                for (const mealType of PLANNER_MEAL_TYPES) {
                    const aiMenuItem = dailyAiPlan[mealType];
                    const fullMenuItem = aiMenuItem ? menuMap.get(aiMenuItem.id) : null;

                    if (fullMenuItem) {
                        const newOrderItem: OrderItemType = {
                            id: `${fullMenuItem.id}-${Date.now()}-${day}-${mealType}`,
                            menuItem: fullMenuItem,
                            quantity: 1,
                            selectedOptions: [],
                            totalPrice: fullMenuItem.price,
                            totalNutrition: {
                                calories: fullMenuItem.calories,
                                carbs: fullMenuItem.carbs,
                                protein: fullMenuItem.protein,
                                fat: fullMenuItem.fat,
                            }
                        };
                        newPlan[day]![mealType as MealType] = newOrderItem;
                    } else {
                        newPlan[day]![mealType as MealType] = null;
                    }
                }
            }
            
            setPlan(newPlan);

        } catch (error) {
            console.error("Failed to generate meal plan:", error);
            alert((error as Error).message || "Đã xảy ra lỗi khi tạo kế hoạch.");
        } finally {
            setIsGenerating(false);
        }
    };


    return (
        <div className="animate-fade-in pb-28">
             <div className="flex flex-col sm:flex-row justify-between items-center mb-6">
                <h2 className="text-3xl font-bold text-cyan-300 flex items-center gap-3 mb-4 sm:mb-0">
                    <CalendarIcon className="w-8 h-8" />
                    {t.meal_planner}
                </h2>
                <div className="flex items-center gap-2 sm:gap-4">
                     <button 
                        onClick={handleGeneratePlan} 
                        disabled={isGenerating}
                        className="flex items-center justify-center gap-2 text-sm bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-semibold py-2 px-3 rounded-lg shadow-lg shadow-cyan-500/20 transition-all duration-300 disabled:from-gray-500 disabled:to-gray-600 disabled:shadow-none disabled:cursor-wait w-[180px]">
                        {isGenerating ? (
                             <>
                                <SpinnerIcon className="h-4 w-4 text-white" />
                                {t.generating}
                            </>
                        ) : (
                            <>
                                <SparklesIcon className="w-4 w-4" /> {t.auto_generate_ai}
                            </>
                        )}
                    </button>
                    <button onClick={onBack} className="bg-gray-700 hover:bg-gray-600 text-white font-semibold py-2 px-4 rounded-lg transition-colors">
                        {t.back}
                    </button>
                </div>
            </div>

            {/* NEW: Advanced Time Scheduler replacing old Wheel */}
            <AdvancedTimeScheduler currentDayIndex={currentDayIndex} onChangeDay={setCurrentDayIndex} language={language} />

            <div className="grid grid-cols-1 xl:grid-cols-4 gap-8">
                <div className="xl:col-span-3 bg-gray-900/60 backdrop-blur-xl p-6 rounded-2xl border border-cyan-500/20">
                    <div className="flex justify-between items-center mb-4">
                        <div className="flex items-center gap-2">
                            <ClockIcon className="w-5 h-5 text-cyan-400" />
                            <h3 className="font-bold text-white text-xl">{t.menu_schedule_today} {DAY_TRANSLATIONS[currentDay]?.[language] || currentDay}</h3>
                        </div>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center mb-6 p-3 bg-gray-900/40 rounded-lg">
                        <DailyStat label={t.energy} value={`${dailyNutrition.calories.toLocaleString()} kcal`} colorClass="text-cyan-300" />
                        <DailyStat label={t.carbs} value={`${dailyNutrition.carbs.toFixed(0)} g`} colorClass="text-blue-300" />
                        <DailyStat label={t.protein} value={`${dailyNutrition.protein.toFixed(0)} g`} colorClass="text-rose-300" />
                        <DailyStat label={t.fat} value={`${dailyNutrition.fat.toFixed(0)} g`} colorClass="text-amber-300" />
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
                        {PLANNER_MEAL_TYPES.map(mealType => {
                            const meal = plan[currentDay]?.[mealType] || null;
                            const alertLevel = getMealAlertLevel(meal);
                            return (
                                <div key={mealType} className="h-32">
                                    <p className="text-xs text-gray-400 text-center mb-1 h-4">{MEAL_TYPE_TRANSLATIONS[mealType][language]}</p>
                                    <MealSlot 
                                        meal={meal} 
                                        onAdd={() => handleOpenModal(currentDay, mealType)}
                                        onRemove={() => handleRemoveMeal(currentDay, mealType)}
                                        alertLevel={alertLevel}
                                        language={language}
                                    />
                                </div>
                            );
                        })}
                    </div>
                </div>


                <div className="xl:col-span-1">
                    <WeeklyNutritionSummary plan={plan} analysis={analysis} language={language} />
                     <button onClick={handleClearPlan} className="flex items-center gap-2 mx-auto text-sm text-red-500 hover:text-red-400 transition-colors font-semibold mt-6">
                        <TrashIcon className="w-4 h-4" /> {t.clear_plan}
                    </button>
                </div>
            </div>

            <div className="fixed bottom-0 left-0 right-0 bg-gray-900/80 backdrop-blur-sm border-t border-cyan-500/20 p-4 z-50">
                <div className="max-w-4xl mx-auto flex flex-col sm:flex-row justify-center items-center gap-4">
                    <button 
                        onClick={() => onAddPlanToOrder(plan)} 
                        className="flex items-center justify-center gap-2 text-lg bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-400 hover:to-green-500 text-white font-bold py-3 px-6 rounded-lg shadow-lg shadow-emerald-500/20 transition-all duration-300 w-full sm:w-auto">
                        <PlusIcon className="w-6 h-6" />
                        {t.add_plan_to_order}
                    </button>
                     <div className="relative">
                        <button 
                            onClick={handleSharePlan} 
                            className="flex items-center justify-center gap-2 text-lg bg-gray-700 hover:bg-gray-600 text-white font-bold py-3 px-6 rounded-lg shadow-lg transition-all duration-300 w-full sm:w-auto">
                            <ShareIcon className="w-6 h-6" />
                            {t.share}
                        </button>
                        {showCopiedTooltip && (
                            <div className="absolute bottom-full mb-2 left-1/2 -translate-x-1/2 bg-gray-900 text-white text-xs rounded py-1 px-2">
                                Đã sao chép vào clipboard!
                            </div>
                        )}
                    </div>
                </div>
            </div>

            {isModalOpen && (
                <MealSelectorModal
                    isOpen={isModalOpen}
                    onClose={() => setIsModalOpen(false)}
                    onSelectMeal={handleSelectMeal}
                    menuItems={menuItems}
                    analysis={analysis}
                    userData={currentUser}
                    language={language}
                />
            )}
        </div>
    );
};
