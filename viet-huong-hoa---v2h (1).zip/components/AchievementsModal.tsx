
import React from 'react';
import { Achievement, Language } from '../types';
import { ACHIEVEMENTS_LIST, TRANSLATIONS, getAchievementTranslation } from '../constants';

interface AchievementsModalProps {
    isOpen: boolean;
    onClose: () => void;
    earnedAchievements: string[];
    language: Language;
}

const AchievementItem: React.FC<{ achievement: Achievement; isEarned: boolean; language: Language }> = ({ achievement, isEarned, language }) => {
    const Icon = achievement.icon;
    const { name, description } = getAchievementTranslation(achievement.id, language);
    
    return (
        <div className={`flex items-center gap-4 p-4 rounded-lg transition-all border ${isEarned ? 'bg-gray-800/80 border-cyan-500/30' : 'bg-gray-800/50 border-gray-700/50'}`}>
            <div className={`flex-shrink-0 w-16 h-16 rounded-full flex items-center justify-center border-2 ${isEarned ? 'bg-cyan-900/50 border-cyan-500' : 'bg-gray-700 border-gray-600'}`}>
                <Icon className={`w-8 h-8 ${isEarned ? 'text-cyan-300' : 'text-gray-500'}`} />
            </div>
            <div>
                <h4 className={`font-bold ${isEarned ? 'text-white' : 'text-gray-400'}`}>{name}</h4>
                <p className={`text-sm ${isEarned ? 'text-gray-300' : 'text-gray-500'}`}>{description}</p>
            </div>
        </div>
    );
};

export const AchievementsModal: React.FC<AchievementsModalProps> = ({ isOpen, onClose, earnedAchievements, language }) => {
    if (!isOpen) return null;
    const t = TRANSLATIONS[language];

    return (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex justify-center items-center p-4" onClick={onClose}>
            <div 
                className="bg-gray-900/80 backdrop-blur-xl rounded-2xl shadow-lg w-full max-w-lg border border-cyan-500/20 animate-fade-in-up" 
                onClick={e => e.stopPropagation()}
            >
                <div className="p-6 border-b border-gray-700 text-center">
                    <h3 className="text-2xl font-bold text-cyan-300">{t.achievement_collection}</h3>
                    <p className="text-sm text-gray-400 mt-1">{t.achievement_desc}</p>
                </div>

                <div className="p-6 space-y-4 max-h-[60vh] overflow-y-auto">
                    {ACHIEVEMENTS_LIST.map(ach => (
                        <AchievementItem 
                            key={ach.id} 
                            achievement={ach} 
                            isEarned={earnedAchievements.includes(ach.id)}
                            language={language}
                        />
                    ))}
                </div>

                <div className="p-4 bg-gray-900/50 rounded-b-2xl border-t border-gray-700 text-right">
                    <button onClick={onClose} className="bg-gray-600 hover:bg-gray-500 text-white font-bold py-2 px-6 rounded-lg">
                        {t.close}
                    </button>
                </div>
            </div>
        </div>
    );
};
