
import React, { useMemo } from 'react';
import { AnalysisResult, WeeklyMealPlan, NutritionInfo, AlertLevel, Language } from '../types';
import { TRANSLATIONS } from '../constants';

interface WeeklyNutritionSummaryProps {
    plan: WeeklyMealPlan;
    analysis: AnalysisResult;
    language: Language;
}

const ProgressBar: React.FC<{ value: number; max: number; level: AlertLevel }> = ({ value, max, level }) => {
  const percentage = Math.min((value / max) * 100, 100);
  const colorClasses = {
    [AlertLevel.Green]: "bg-cyan-500",
    [AlertLevel.Yellow]: "bg-amber-500",
    [AlertLevel.Red]: "bg-fuchsia-500",
  };
  return (
    <div className="w-full bg-gray-700/50 rounded-full h-2.5">
      <div className={`${colorClasses[level]} h-2.5 rounded-full`} style={{ width: `${percentage}%` }}></div>
    </div>
  );
};


export const WeeklyNutritionSummary: React.FC<WeeklyNutritionSummaryProps> = ({ plan, analysis, language }) => {
    const t = TRANSLATIONS[language];
    
    const dailyAverage = useMemo(() => {
        const weeklyTotals: NutritionInfo = { calories: 0, carbs: 0, protein: 0, fat: 0 };
        let plannedDays = 0;

        Object.values(plan).forEach(dailyPlan => {
            let isDayPlanned = false;
            Object.values(dailyPlan).forEach(meal => {
                if (meal) {
                    isDayPlanned = true;
                    weeklyTotals.calories += meal.totalNutrition.calories;
                    weeklyTotals.carbs += meal.totalNutrition.carbs;
                    weeklyTotals.protein += meal.totalNutrition.protein;
                    weeklyTotals.fat += meal.totalNutrition.fat;
                }
            });
            if (isDayPlanned) plannedDays++;
        });

        if (plannedDays === 0) return { calories: 0, carbs: 0, protein: 0, fat: 0 };
        
        return {
            calories: Math.round(weeklyTotals.calories / plannedDays),
            carbs: Math.round(weeklyTotals.carbs / plannedDays),
            protein: Math.round(weeklyTotals.protein / plannedDays),
            fat: Math.round(weeklyTotals.fat / plannedDays),
        };
    }, [plan]);

    const calorieGoal = analysis.energyNeeds.calories;
    const calorieRatio = dailyAverage.calories / calorieGoal;

    const totalMacros = dailyAverage.carbs + dailyAverage.protein + dailyAverage.fat;
    const carbPercent = dailyAverage.calories > 0 ? (dailyAverage.carbs * 4) / dailyAverage.calories * 100 : 0;
    const proteinPercent = dailyAverage.calories > 0 ? (dailyAverage.protein * 4) / dailyAverage.calories * 100 : 0;
    const fatPercent = dailyAverage.calories > 0 ? (dailyAverage.fat * 9) / dailyAverage.calories * 100 : 0;

    let alertLevel: AlertLevel = AlertLevel.Green;
    if (calorieRatio > 1.2 || calorieRatio < 0.8) {
        alertLevel = AlertLevel.Red;
    } else if (calorieRatio > 1.1 || calorieRatio < 0.9) {
        alertLevel = AlertLevel.Yellow;
    }

    const containerClasses = {
        [AlertLevel.Green]: "border-cyan-500/20",
        [AlertLevel.Yellow]: "border-amber-500/50",
        [AlertLevel.Red]: "border-fuchsia-500/80",
    };

    return (
        <div className={`sticky top-4 bg-gray-900/60 backdrop-blur-xl p-6 rounded-2xl border shadow-lg shadow-cyan-900/10 transition-colors duration-500 ${containerClasses[alertLevel]}`}>
            <h3 className="text-xl font-bold text-cyan-300 mb-4">{t.weekly_nutrition}</h3>
            <p className="text-xs text-gray-400 mb-4">{t.weekly_desc}</p>
            <div className="space-y-4">
                 <div>
                    <div className="flex justify-between items-baseline mb-1">
                        <span className="text-sm font-medium text-gray-300">{t.energy}</span>
                        <span className={`text-sm font-semibold`}>{dailyAverage.calories.toLocaleString()} / {calorieGoal.toLocaleString()} kcal</span>
                    </div>
                    <ProgressBar value={dailyAverage.calories} max={calorieGoal} level={alertLevel} />
                </div>
                 <div>
                    <p className="text-sm text-center font-medium text-gray-300 mb-2">{t.ratio_target}</p>
                    <div className="flex justify-between text-xs text-gray-400">
                        <span>{t.carbs} ({analysis.macroDistribution.carbs}%)</span>
                        <span>{t.protein} ({analysis.macroDistribution.protein}%)</span>
                        <span>{t.fat} ({analysis.macroDistribution.fat}%)</span>
                    </div>
                    <div className="w-full flex h-3 rounded-full overflow-hidden bg-gray-700/50 mt-1">
                        <div className="bg-blue-400" style={{width: `${carbPercent}%`}}></div>
                        <div className="bg-rose-400" style={{width: `${proteinPercent}%`}}></div>
                        <div className="bg-amber-300" style={{width: `${fatPercent}%`}}></div>
                    </div>
                </div>
                <div className="text-xs text-gray-400 pt-2 border-t border-gray-700/50">
                    <p className="flex justify-between"><span>{t.avg_carbs}:</span> <span className="font-semibold text-blue-300">{dailyAverage.carbs}g</span></p>
                    <p className="flex justify-between"><span>{t.avg_protein}:</span> <span className="font-semibold text-rose-300">{dailyAverage.protein}g</span></p>
                    <p className="flex justify-between"><span>{t.avg_fat}:</span> <span className="font-semibold text-amber-300">{dailyAverage.fat}g</span></p>
                </div>
            </div>
        </div>
    );
};
