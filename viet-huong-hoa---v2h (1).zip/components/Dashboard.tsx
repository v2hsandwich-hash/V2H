import React, { useState, useEffect } from 'react';
import { ChartDataPoint, DashboardData, MenuItemType, PastOrderType, Period } from '../types';
import { getDashboardData } from '../utils/dashboardUtils';
import { SpinnerIcon } from './Icons';

const KPICard: React.FC<{ title: string; value: string; description?: string, icon: React.ReactNode }> = ({ title, value, description, icon }) => (
    <div className="bg-gray-800/50 p-4 rounded-lg border border-gray-700 flex items-center gap-4">
        <div className="bg-gray-700/50 p-3 rounded-full">
            {icon}
        </div>
        <div>
            <p className="text-sm text-gray-400">{title}</p>
            <p className="text-2xl font-bold text-white">{value}</p>
            {description && <p className="text-xs text-gray-500">{description}</p>}
        </div>
    </div>
);

const BarChart: React.FC<{ data: ChartDataPoint[]; title: string }> = ({ data, title }) => {
    const maxValue = Math.max(...data.map(d => d.value), 0);
    return (
        <div className="bg-gray-800/50 p-4 rounded-lg border border-gray-700 h-full flex flex-col">
            <h3 className="text-lg font-semibold text-cyan-300 mb-4">{title}</h3>
            {maxValue > 0 ? (
                 <div className="flex-grow flex items-end gap-2 px-2">
                    {data.map((point, index) => (
                        <div key={index} className="flex-1 flex flex-col items-center gap-2 group">
                            <div className="relative w-full h-full flex items-end">
                                <div
                                    className="w-full bg-gradient-to-t from-cyan-600 to-blue-500 rounded-t-md transition-all duration-500 ease-out group-hover:from-cyan-500 group-hover:to-blue-400"
                                    style={{ height: `${(point.value / maxValue) * 100}%` }}
                                >
                                     <div className="absolute bottom-full mb-1 left-1/2 -translate-x-1/2 bg-gray-900 text-white text-xs rounded py-1 px-2 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                                        {point.value.toLocaleString()}đ
                                    </div>
                                </div>
                            </div>
                            <span className="text-xs text-gray-400 text-center">{point.label}</span>
                        </div>
                    ))}
                </div>
            ) : (
                <div className="flex-grow flex items-center justify-center">
                    <p className="text-gray-500">Không có dữ liệu</p>
                </div>
            )}
        </div>
    );
};

const DonutChart: React.FC<{ data: { name: string; value: number; color: string }[]; title: string; centerText?: string }> = ({ data, title, centerText }) => {
    const total = data.reduce((sum, item) => sum + item.value, 0);
    let cumulative = 0;

    const segments = data.map(item => {
        const percentage = total > 0 ? (item.value / total) * 100 : 0;
        const offset = cumulative;
        cumulative += percentage;
        return { ...item, percentage, offset };
    });

    return (
         <div className="bg-gray-800/50 p-4 rounded-lg border border-gray-700 h-full">
            <h3 className="text-lg font-semibold text-cyan-300 mb-4">{title}</h3>
            <div className="flex flex-col md:flex-row items-center gap-4">
                <div className="relative w-36 h-36 flex-shrink-0">
                    <svg viewBox="0 0 36 36" className="transform -rotate-90">
                        <circle cx="18" cy="18" r="15.915" fill="transparent" stroke="#374151" strokeWidth="3"></circle>
                        {segments.map((segment, index) => (
                           <circle
                                key={index}
                                cx="18"
                                cy="18"
                                r="15.915"
                                fill="transparent"
                                stroke={segment.color}
                                strokeWidth="3.5"
                                strokeDasharray={`${segment.percentage} ${100 - segment.percentage}`}
                                strokeDashoffset={-segment.offset}
                                className="transition-all duration-500 ease-out"
                            ></circle>
                        ))}
                    </svg>
                     {centerText && (
                        <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                            <span className="text-xl font-bold text-white">{centerText}</span>
                        </div>
                    )}
                </div>
                <div className="w-full space-y-2">
                    {data.map((item, index) => (
                        <div key={index} className="flex justify-between items-center text-sm">
                            <div className="flex items-center gap-2">
                                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }}></div>
                                <span className="text-gray-300">{item.name}</span>
                            </div>
                            <span className="font-semibold text-white">{item.value.toLocaleString()}đ</span>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    )
};

export const Dashboard: React.FC = () => {
    const [period, setPeriod] = useState<Period>('day');
    const [data, setData] = useState<DashboardData | null>(null);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const fetchData = () => {
            setIsLoading(true);
            try {
                const allOrders: PastOrderType[] = JSON.parse(localStorage.getItem('orderHistories') || '{}')['all_orders'] || [];
                const allMenus: Record<string, MenuItemType[]> = JSON.parse(localStorage.getItem('v2h_menu_items') || '{}');
                const dashboardData = getDashboardData(allOrders, allMenus, period);
                setData(dashboardData);
            } catch (error) {
                console.error("Failed to load dashboard data:", error);
            } finally {
                setIsLoading(false);
            }
        };
        fetchData();
    }, [period]);

    if (isLoading) {
        return <div className="flex justify-center items-center h-64"><SpinnerIcon className="w-8 h-8 text-cyan-400" /></div>;
    }

    if (!data) {
        return <div className="text-center text-gray-500">Không thể tải dữ liệu.</div>;
    }

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <h2 className="text-xl font-bold text-white">Tổng quan</h2>
                <div className="flex gap-1 bg-gray-800/50 p-1 rounded-lg border border-gray-700">
                    {(['day', 'week', 'month'] as Period[]).map(p => (
                        <button key={p} onClick={() => setPeriod(p)} className={`px-3 py-1 text-sm rounded-md transition-colors ${period === p ? 'bg-cyan-600 text-white' : 'text-gray-400 hover:bg-gray-700'}`}>
                           {p === 'day' ? 'Hôm nay' : p === 'week' ? 'Tuần này' : 'Tháng này'}
                        </button>
                    ))}
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <KPICard title="Doanh thu" value={`${data.totalRevenue.toLocaleString()}đ`} icon={<div className="text-cyan-400 text-2xl">💰</div>} />
                <KPICard title="Lợi nhuận ròng" value={`${data.netProfit.toLocaleString()}đ`} icon={<div className="text-emerald-400 text-2xl">📈</div>} />
                <KPICard title="Khách hàng quay lại" value={`${data.returningCustomerRate.toFixed(0)}%`} icon={<div className="text-indigo-400 text-2xl">👥</div>} />
                <KPICard title="Món bán chạy nhất" value={data.bestSeller?.name || 'N/A'} description={`Đã bán: ${data.bestSeller?.quantity || 0}`} icon={<div className="text-amber-400 text-2xl">🔥</div>} />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                     <BarChart data={data.revenueChartData} title="Doanh thu" />
                </div>
                <div className="space-y-6">
                    <DonutChart 
                        data={[
                            { name: 'Lợi nhuận', value: data.profitAnalysis.revenue - data.profitAnalysis.cost, color: '#2dd4bf' },
                            { name: 'Chi phí', value: data.profitAnalysis.cost, color: '#fb923c' },
                        ]}
                        title="Phân tích Lợi nhuận"
                        centerText={`${(total => total > 0 ? (((total - data.profitAnalysis.cost) / total) * 100).toFixed(0) : 0)(data.profitAnalysis.revenue)}%`}
                    />
                    <DonutChart 
                        data={data.revenueByCategory.map((c, i) => ({ ...c, color: ['#38bdf8', '#818cf8', '#f472b6', '#a78bfa', '#e879f9'][i % 5] }))}
                        title="Phân loại Doanh thu"
                    />
                </div>
            </div>

            <div className="bg-gray-800/50 p-4 rounded-lg border border-gray-700">
                <h3 className="text-lg font-semibold text-cyan-300 mb-4">Món ăn Phổ biến nhất</h3>
                <div className="space-y-3">
                    {data.topProducts.map((product, index) => (
                        <div key={product.id} className="flex items-center gap-4 bg-gray-700/50 p-2 rounded-md">
                             <div className="w-8 text-center text-lg font-bold text-gray-400">{index + 1}</div>
                            <img src={product.image} alt={product.name} className="w-12 h-12 rounded-md object-cover"/>
                            <p className="flex-grow font-medium text-white">{product.name}</p>
                            <p className="text-gray-300"><span className="font-bold">{product.quantity}</span> đã bán</p>
                        </div>
                    ))}
                     {data.topProducts.length === 0 && <p className="text-center text-gray-500 py-4">Không có dữ liệu bán hàng.</p>}
                </div>
            </div>
        </div>
    );
};