
import React, { useState, useMemo, useEffect, useRef, useCallback } from 'react';
import { MenuPackage, MenuItemType, Language } from '../types';
import { BoxIcon } from './Icons';
import { getMenuItemTranslation, getPackageTranslation } from '../constants';

interface PackageHologramModalProps {
    pkg: MenuPackage;
    onClose: () => void;
    onConfirm: (pkg: MenuPackage) => void;
    menuItems: Record<string, MenuItemType[]>;
    language: Language;
}

const InfoCard: React.FC<{ item: MenuItemType, language: Language }> = ({ item, language }) => {
    const { name, description } = getMenuItemTranslation(item, language);
    return (
        <div className="p-3 md:p-4 bg-gray-800/60 backdrop-blur-md border border-gray-600/50 rounded-xl animate-fade-in w-full shadow-lg transition-all">
            <div className="flex justify-between items-start mb-1 md:mb-2">
                <h3 className="text-base md:text-lg font-bold text-cyan-300 truncate pr-2" title={name}>{name}</h3>
                <span className="text-[10px] md:text-xs font-mono bg-black/40 px-1.5 py-0.5 rounded text-gray-300 border border-gray-700 whitespace-nowrap">{item.calories} kcal</span>
            </div>
            <p className="text-[10px] md:text-xs text-gray-300 mb-2 md:mb-3 leading-relaxed line-clamp-3 md:line-clamp-none">{description}</p>
            <div className="grid grid-cols-3 gap-2 text-xs border-t border-gray-700/50 pt-2 md:pt-3">
                <div className="text-center bg-blue-900/20 rounded py-1 border border-blue-500/20"><span className="block text-blue-300 font-bold">{item.carbs}g</span> <span className="text-[9px] md:text-[10px] text-gray-500">Carbs</span></div>
                <div className="text-center bg-rose-900/20 rounded py-1 border border-rose-500/20"><span className="block text-rose-300 font-bold">{item.protein}g</span> <span className="text-[9px] md:text-[10px] text-gray-500">Protein</span></div>
                <div className="text-center bg-amber-900/20 rounded py-1 border border-amber-500/20"><span className="block text-amber-300 font-bold">{item.fat}g</span> <span className="text-[9px] md:text-[10px] text-gray-500">Fat</span></div>
            </div>
        </div>
    );
};

export const PackageHologramModal: React.FC<PackageHologramModalProps> = ({ pkg, onClose, onConfirm, menuItems, language }) => {
    const [activeIndex, setActiveIndex] = useState(0);
    const [isPaused, setIsPaused] = useState(false);
    const orbitRef = useRef<HTMLDivElement>(null);

    // FIX: Explicitly cast Object.values result to resolve 'unknown' type error in reduce
    const allMenuItems = useMemo(() => (Object.values(menuItems) as MenuItemType[][]).reduce<MenuItemType[]>((acc, val) => acc.concat(val), []), [menuItems]);
    const includedItems = useMemo(() => 
        pkg.itemIds.map(id => allMenuItems.find(item => item.id === id)).filter((i): i is MenuItemType => !!i), 
    [pkg.itemIds, allMenuItems]);

    const radius = 240; // Increased radius for better visibility
    const angleStep = includedItems.length > 0 ? 360 / includedItems.length : 0;

    const { name: pkgName } = getPackageTranslation(pkg, language);

    const handleConfirm = useCallback(() => {
        onConfirm(pkg);
    }, [onConfirm, pkg]);

    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => {
            if (e.key === 'ArrowRight') {
                setActiveIndex(prev => (prev + 1) % includedItems.length);
            } else if (e.key === 'ArrowLeft') {
                setActiveIndex(prev => (prev - 1 + includedItems.length) % includedItems.length);
            } else if (e.key === 'Enter') {
                handleConfirm();
            } else if (e.key === 'Escape') {
                onClose();
            }
        };

        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, [includedItems.length, onClose, handleConfirm]);

     useEffect(() => {
        if (orbitRef.current) {
            orbitRef.current.style.animationPlayState = isPaused ? 'paused' : 'running';
        }
    }, [isPaused]);
    
    const activeItem = includedItems[activeIndex];

    return (
        <div role="dialog" aria-modal="true" aria-labelledby="hologram-title" className="fixed inset-0 bg-black/90 z-50 flex flex-col items-center justify-center p-0 md:p-4 hologram-modal overflow-hidden backdrop-blur-sm">
            <button onClick={onClose} className="absolute top-4 right-4 text-gray-400 hover:text-white text-3xl md:text-4xl leading-none z-50 transition-colors bg-black/30 rounded-full p-2 w-10 h-10 flex items-center justify-center border border-gray-600">&times;</button>

            <div className="w-full max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-0 md:gap-8 h-full md:h-auto md:min-h-[600px] relative">
                
                {/* Left Panel (Mobile: Top): Hologram Display */}
                <div className="w-full md:w-3/5 h-[40vh] md:h-full flex flex-col items-center justify-center relative order-1 perspective-container mt-8 md:mt-0 flex-shrink-0">
                    <div 
                        className="relative w-full h-full flex items-center justify-center hologram-orbit"
                        ref={orbitRef}
                        style={{ transform: `rotateY(${-activeIndex * angleStep}deg)` }}
                        onMouseEnter={() => setIsPaused(true)}
                        onMouseLeave={() => setIsPaused(false)}
                    >
                        {includedItems.map((item, index) => {
                            const angle = angleStep * index;
                            const isActive = index === activeIndex;
                            const { name: itemName } = getMenuItemTranslation(item, language);

                            return (
                                <div
                                    key={item.id}
                                    className="hologram-item-wrapper w-32 h-32 md:w-64 md:h-64 -mt-16 -ml-16 md:-mt-32 md:-ml-32"
                                    style={{ transform: `rotateY(${angle}deg) translateZ(${radius}px)` }}
                                >
                                    <div className="relative w-full h-full group">
                                        <img
                                            src={item.image}
                                            alt={itemName}
                                            onClick={() => setActiveIndex(index)}
                                            onMouseEnter={() => setActiveIndex(index)}
                                            className={`w-full h-full object-cover rounded-full cursor-pointer hologram-item border-2 md:border-4 transition-all duration-500 ${isActive ? 'border-cyan-400 scale-110 shadow-[0_0_50px_rgba(34,211,238,0.6)] z-20' : 'border-gray-700 scale-90 opacity-50 grayscale hover:grayscale-0 hover:opacity-100'}`}
                                            style={{ transform: `rotateY(${-angle}deg)` }}
                                        />
                                        {/* Floating Label for non-active items */}
                                        {!isActive && (
                                            <div 
                                                className="absolute -bottom-8 left-1/2 -translate-x-1/2 bg-black/70 text-white text-[10px] px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none hidden md:block"
                                                style={{ transform: `rotateY(${-angle}deg)` }}
                                            >
                                                {itemName}
                                            </div>
                                        )}
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                    
                    {/* Hologram Base */}
                    <div className="hologram-base mt-10 md:mt-20 scale-100 md:scale-150 opacity-40 blur-sm"></div>

                    {/* Navigation Controls (positioned under hologram) */}
                    <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex items-center gap-6 z-40 bg-gray-900/80 backdrop-blur-md px-4 md:px-6 py-1.5 md:py-2 rounded-full border border-cyan-500/30 shadow-lg transform scale-90 md:scale-100">
                        <button onClick={() => setActiveIndex(prev => (prev - 1 + includedItems.length) % includedItems.length)} className="p-2 rounded-full hover:bg-cyan-500/20 text-cyan-400 transition-colors">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 md:h-6 md:w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
                        </button>
                        <span className="text-xs md:text-sm font-mono text-white font-bold min-w-[3rem] text-center">{activeIndex + 1} / {includedItems.length}</span>
                        <button onClick={() => setActiveIndex(prev => (prev + 1) % includedItems.length)} className="p-2 rounded-full hover:bg-cyan-500/20 text-cyan-400 transition-colors">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 md:h-6 md:w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>
                        </button>
                    </div>
                </div>

                {/* Right Panel (Mobile: Bottom): Information & Actions */}
                <div className="w-full md:w-2/5 z-30 flex-1 overflow-y-auto px-4 pb-6 md:px-0 md:overflow-visible order-2 bg-gradient-to-t from-black via-gray-900/90 to-transparent md:bg-none">
                    <div className="bg-gray-900/80 p-4 md:p-6 rounded-3xl border border-gray-700/50 backdrop-blur-xl shadow-2xl h-full flex flex-col justify-between">
                        <div>
                            <div className="border-b border-gray-700/50 pb-3 md:pb-4 mb-3 md:mb-4">
                                <div className="flex items-center gap-2 md:gap-3 mb-1 md:mb-2">
                                    <span className="px-2 py-0.5 md:px-3 md:py-1 rounded-full text-[10px] md:text-xs font-bold bg-purple-900/60 text-purple-300 border border-purple-500/40">{pkg.category}</span>
                                    <span className="text-[10px] md:text-xs text-gray-400 italic">Combo {includedItems.length} món</span>
                                </div>
                                <h2 className="text-2xl md:text-4xl font-black text-white leading-tight mb-1">{pkgName}</h2>
                            </div>

                            <div className="mb-4 md:mb-6">
                                <p className="text-[10px] md:text-sm text-gray-400 font-bold mb-2 uppercase tracking-wider">Đang xem:</p>
                                {activeItem ? <InfoCard item={activeItem} language={language} /> : <div className="h-24 md:h-32 flex items-center justify-center text-gray-500 text-sm italic">Chọn món để xem chi tiết</div>}
                            </div>

                            <div className="bg-gray-800/40 rounded-xl p-3 md:p-4 mb-4 md:mb-6 border border-gray-700/30">
                                <h4 className="text-[10px] md:text-xs font-bold text-gray-400 uppercase mb-2 md:mb-3 flex items-center gap-2">
                                    <BoxIcon className="w-3 h-3 md:w-4 md:h-4"/> Tổng dinh dưỡng gói
                                </h4>
                                <div className="flex justify-between items-center text-xs md:text-sm">
                                    <div className="text-center">
                                        <span className="block text-lg md:text-xl font-bold text-white">{pkg.totalNutrition.calories}</span>
                                        <span className="text-[9px] md:text-[10px] text-gray-500 uppercase">kcal</span>
                                    </div>
                                    <div className="w-px h-6 md:h-8 bg-gray-700"></div>
                                    <div className="text-center">
                                        <span className="block text-base md:text-lg font-bold text-blue-400">{pkg.totalNutrition.carbs}g</span>
                                        <span className="text-[9px] md:text-[10px] text-gray-500 uppercase">Carb</span>
                                    </div>
                                    <div className="text-center">
                                        <span className="block text-base md:text-lg font-bold text-rose-400">{pkg.totalNutrition.protein}g</span>
                                        <span className="text-[9px] md:text-[10px] text-gray-500 uppercase">Pro</span>
                                    </div>
                                    <div className="text-center">
                                        <span className="block text-base md:text-lg font-bold text-amber-400">{pkg.totalNutrition.fat}g</span>
                                        <span className="text-[9px] md:text-[10px] text-gray-500 uppercase">Fat</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="flex flex-col gap-2 md:gap-3 mt-auto">
                            <div className="flex justify-between items-end mb-1">
                                <span className="text-gray-500 line-through text-sm md:text-lg">{pkg.originalPrice.toLocaleString()}đ</span>
                                <div className="text-right">
                                    <span className="text-[10px] md:text-xs text-purple-400 font-bold bg-purple-900/30 px-2 py-0.5 rounded mr-2">TIẾT KIỆM {Math.round((1 - pkg.price/pkg.originalPrice)*100)}%</span>
                                    <span className="text-2xl md:text-4xl font-bold text-white">{pkg.price.toLocaleString()}đ</span>
                                </div>
                            </div>
                            <button 
                                onClick={handleConfirm}
                                className="w-full flex items-center justify-center gap-2 md:gap-3 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold py-3 md:py-4 px-6 md:px-8 rounded-xl shadow-lg shadow-purple-900/40 transition-all hover:scale-[1.02] active:scale-95 group text-sm md:text-base"
                            >
                                <BoxIcon className="w-5 h-5 md:w-6 md:h-6 group-hover:animate-bounce" />
                                Thêm Gói Này Vào Đơn
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};
