
import React, { useState, useEffect, useRef } from 'react';
import { Promotion, Language } from '../types';
import { SparklesIcon } from './Icons';

interface PromotionModalProps {
    promotion: Promotion;
    onClose: () => void;
    onConfirm: (promotion: Promotion) => void;
    language: Language;
}

const formatTime = (seconds: number) => {
    const h = Math.floor(seconds / 3600).toString().padStart(2, '0');
    const m = Math.floor((seconds % 3600) / 60).toString().padStart(2, '0');
    const s = (seconds % 60).toString().padStart(2, '0');
    return `${h}:${m}:${s}`;
};

export const PromotionModal: React.FC<PromotionModalProps> = ({ promotion, onClose, onConfirm, language }) => {
    const [timeLeft, setTimeLeft] = useState(promotion.expiresInSeconds || 0);
    const modalRef = useRef<HTMLDivElement>(null);

    const textEnd = language === 'vi' ? 'Ưu đãi kết thúc sau' : language === 'en' ? 'Offer ends in' : 'Offer ends in';
    const textLater = language === 'vi' ? 'Để sau' : language === 'en' ? 'Later' : 'Later';

    useEffect(() => {
        if (promotion.expiresInSeconds) {
            const interval = setInterval(() => {
                setTimeLeft(prev => {
                    if (prev <= 1) {
                        clearInterval(interval);
                        onClose(); // Auto-close when timer ends
                        return 0;
                    }
                    return prev - 1;
                });
            }, 1000);
            return () => clearInterval(interval);
        }
    }, [promotion.expiresInSeconds, onClose]);

    useEffect(() => {
        const handleKeyDown = (event: KeyboardEvent) => {
            if (event.key === 'Escape') onClose();
        };
        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, [onClose]);

    return (
        <div 
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex justify-center items-center p-4" 
            onClick={onClose}
            role="dialog"
            aria-modal="true"
            aria-labelledby="promotion-title"
        >
            <div 
                ref={modalRef}
                className="bg-gradient-to-br from-gray-900 via-purple-900/40 to-gray-900 rounded-2xl shadow-2xl shadow-purple-500/20 w-full max-w-md border border-purple-500/30 animate-fade-in-up relative overflow-hidden" 
                onClick={e => e.stopPropagation()}
            >
                {promotion.image && (
                    <div className="relative">
                        <img src={promotion.image} alt={promotion.title} className="w-full h-48 object-cover opacity-60" />
                        <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-gray-900/70 to-transparent"></div>
                    </div>
                )}
                <div className="p-8 text-center relative -mt-20">
                    <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-indigo-600 rounded-full flex items-center justify-center mx-auto mb-4 border-4 border-gray-900">
                        <SparklesIcon className="w-8 h-8 text-white"/>
                    </div>
                    <h2 id="promotion-title" className="text-3xl font-bold text-white mb-2">{promotion.title}</h2>
                    <p className="text-gray-300 mb-6">{promotion.description}</p>
                    
                    {promotion.expiresInSeconds && (
                        <div className="mb-6 bg-gray-800/50 border border-gray-700 rounded-lg py-2">
                            <p className="text-sm text-purple-300">{textEnd}</p>
                            <p className="text-3xl font-mono font-bold text-white tracking-wider">{formatTime(timeLeft)}</p>
                        </div>
                    )}
                    
                    <div className="flex flex-col gap-3">
                        <button 
                            onClick={() => onConfirm(promotion)}
                            className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold py-3 px-8 rounded-lg shadow-lg shadow-purple-500/30 transition-all text-lg"
                        >
                            {promotion.cta}
                        </button>
                        <button 
                            onClick={onClose}
                            className="w-full bg-transparent hover:bg-gray-800/50 text-gray-400 font-semibold py-2 px-6 rounded-lg transition-colors"
                        >
                            {textLater}
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};
