
import React, { useMemo } from 'react';
import { UserData, LeaderboardUser, Language } from '../types';
import { MOCK_LEADERBOARD_DATA, TRANSLATIONS } from '../constants';
import { UsersIcon, MedalIcon } from './Icons';

interface LeaderboardProps {
  currentUser: UserData;
  onBack: () => void;
  language: Language;
}

const getRankColor = (rank: number) => {
    if (rank === 1) return 'bg-gradient-to-br from-yellow-400 to-amber-500 text-black';
    if (rank === 2) return 'bg-gradient-to-br from-slate-300 to-slate-400 text-black';
    if (rank === 3) return 'bg-gradient-to-br from-amber-600 to-yellow-700 text-white';
    return 'bg-gray-700 text-gray-200';
};

export const Leaderboard: React.FC<LeaderboardProps> = ({ currentUser, onBack, language }) => {
    const t = TRANSLATIONS[language];

    const rankedUsers = useMemo(() => {
        const allUsers = [
            ...MOCK_LEADERBOARD_DATA,
            {
                name: currentUser.fullName,
                avatar: currentUser.avatar || `https://i.pravatar.cc/150?u=${currentUser.phone}`,
                points: currentUser.loyaltyPoints,
            }
        ];
        
        const uniqueUsers = Array.from(new Map(allUsers.map(u => [u.name, u])).values());

        return uniqueUsers
            .sort((a, b) => b.points - a.points)
            .map((user, index) => ({ ...user, rank: index + 1 }));

    }, [currentUser]);

    return (
        <div className="max-w-4xl mx-auto p-6 sm:p-8 bg-gray-900/60 backdrop-blur-xl rounded-2xl shadow-lg border border-cyan-500/20 animate-fade-in">
            <div className="flex justify-between items-center mb-6 pb-4 border-b border-gray-700">
                <h2 className="text-2xl sm:text-3xl font-bold text-cyan-300 flex items-center gap-3">
                    <UsersIcon className="w-7 h-7 sm:w-8 sm:h-8" />
                    {t.member_leaderboard}
                </h2>
                <button onClick={onBack} className="bg-gray-700 hover:bg-gray-600 text-white font-semibold py-2 px-4 rounded-lg transition-colors">
                    {t.back}
                </button>
            </div>

            <p className="text-center text-gray-400 text-sm mb-6">{t.leaderboard_desc}</p>

            <div className="space-y-3 max-h-[60vh] overflow-y-auto pr-2">
                {rankedUsers.map((user) => {
                    const isCurrentUser = user.name === currentUser.fullName;
                    return (
                        <div key={user.rank} className={`flex items-center gap-4 p-3 rounded-lg border transition-transform duration-200 ${isCurrentUser ? 'bg-cyan-900/50 border-cyan-500 scale-105 shadow-lg shadow-cyan-900/30' : 'bg-gray-800/70 border-gray-700'}`}>
                            <div className={`w-10 h-10 flex-shrink-0 flex items-center justify-center font-bold text-lg rounded-full ${getRankColor(user.rank)}`}>
                                {user.rank}
                            </div>
                            <img src={user.avatar} alt={user.name} className="w-12 h-12 rounded-full object-cover border-2 border-gray-600"/>
                            <div className="flex-grow">
                                <p className={`font-bold ${isCurrentUser ? 'text-white' : 'text-gray-200'}`}>{user.name}</p>
                            </div>
                            <div className="flex items-center gap-2 text-yellow-400">
                                <MedalIcon className="w-5 h-5" />
                                <span className="font-bold text-lg">{user.points.toLocaleString()}</span>
                            </div>
                        </div>
                    );
                })}
            </div>
        </div>
    );
};
