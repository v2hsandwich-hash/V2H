
import React, { useState } from 'react';
import { UserData, LabValues, NutritionGoal, Language } from '../types';
import { NORMAL_LAB_RANGES, NUTRITION_GOAL_TRANSLATIONS, TRANSLATIONS } from '../constants';
import { SparklesIcon, SpinnerIcon, PhoneIcon, IdentificationIcon, CalendarIcon, UserIcon, GoalIcon, WeightIcon, HeightIcon, MenuIcon, AlertIcon, ChartIcon, LockClosedIcon } from './Icons';
import { unlockAudioContext } from '../utils/audioUtils';

interface UserInfoFormProps {
  onSubmit: (data: UserData) => void;
  isLoading: boolean;
  onSkip: () => void;
  language: Language;
}

const initialLabValues: LabValues = {
  glucose: '', hba1c: '', uricAcid: '', ure: '', creatinine: '',
  cholesterol: '', triglyceride: '', systolicBP: '', diastolicBP: '',
  albumin: '', protein: ''
};

const initialUserData: UserData = {
  fullName: '', phone: '', birthYear: '', gender: 'male',
  weight: '', height: '', nutritionGoal: 'eat_clean', labValues: initialLabValues,
  loyaltyPoints: 0, loyaltyTier: 'Đồng', achievements: [], medicalConditions: ''
};

export const UserInfoForm: React.FC<UserInfoFormProps> = ({ onSubmit, isLoading, onSkip, language }) => {
  const [formData, setFormData] = useState<UserData>(initialUserData);
  const t = TRANSLATIONS[language];

  const GOAL_BUTTONS: { key: NutritionGoal; label: string; icon: React.FC<{className?: string}> }[] = [
    { key: 'gym', label: NUTRITION_GOAL_TRANSLATIONS['gym'][language], icon: WeightIcon },
    { key: 'obese', label: NUTRITION_GOAL_TRANSLATIONS['obese'][language], icon: ChartIcon },
    { key: 'eat_clean', label: NUTRITION_GOAL_TRANSLATIONS['eat_clean'][language], icon: SparklesIcon },
    { key: 'medical', label: NUTRITION_GOAL_TRANSLATIONS['medical'][language], icon: AlertIcon },
  ];

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleGoalSelect = (goal: NutritionGoal) => {
      setFormData(prev => ({ ...prev, nutritionGoal: goal }));
  };

  const handleLabChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      labValues: { ...prev.labValues, [name]: value }
    }));
  };
  
  const handlePhoneBlur = (e: React.FocusEvent<HTMLInputElement>) => {
    const phone = e.target.value;
    if (!phone) return;

    try {
      const allUsersData = JSON.parse(localStorage.getItem('allUsersData') || '{}');
      if (allUsersData[phone]) {
        setFormData(allUsersData[phone]);
      } else {
        // New user, reset form but keep phone number
        setFormData({ ...initialUserData, phone });
      }
    } catch (error) {
      console.error("Failed to parse user data from localStorage", error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    // Enable audio playback for mobile browsers
    await unlockAudioContext();
    onSubmit(formData);
  };

  const renderInput = (name: keyof LabValues, label: string) => (
    <div className="relative group">
      <input
        type="number"
        id={name}
        name={name}
        placeholder=" "
        value={formData.labValues[name]}
        onChange={handleLabChange}
        className="block px-2.5 pb-2.5 pt-4 w-full text-sm text-white bg-black/30 rounded-lg border border-gray-600 appearance-none focus:outline-none focus:ring-0 focus:border-cyan-500 peer transition-colors"
      />
      <label htmlFor={name} className="absolute text-sm text-gray-400 duration-300 transform -translate-y-4 scale-75 top-2 z-10 origin-[0] bg-transparent px-2 peer-focus:px-2 peer-focus:text-cyan-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:-translate-y-1/2 peer-placeholder-shown:top-1/2 peer-focus:top-2 peer-focus:scale-75 peer-focus:-translate-y-4 left-1">
        {label}
      </label>
      <span className="absolute top-1/2 -translate-y-1/2 right-3 text-[10px] text-gray-600 group-hover:text-gray-400 transition-colors pointer-events-none">
        {NORMAL_LAB_RANGES[name as keyof typeof NORMAL_LAB_RANGES]}
      </span>
    </div>
  );

  return (
    <div className="max-w-4xl mx-auto p-8 bg-gray-900/40 backdrop-blur-2xl rounded-3xl shadow-[0_0_50px_rgba(0,0,0,0.5)] border border-white/10 animate-fade-in relative overflow-hidden">
      {/* Decorative Elements */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2 pointer-events-none"></div>
      <div className="absolute bottom-0 left-0 w-64 h-64 bg-purple-500/10 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2 pointer-events-none"></div>

      <div className="relative z-10 text-center mb-8">
          <div className="inline-block p-3 rounded-full bg-gradient-to-br from-cyan-500/20 to-blue-500/20 border border-cyan-500/30 mb-3 shadow-[0_0_15px_rgba(6,182,212,0.3)]">
            <IdentificationIcon className="w-8 h-8 text-cyan-300" />
          </div>
          <h2 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-200 to-white">{t.personal_info}</h2>
          <p className="text-sm text-gray-400 mt-2">Dữ liệu được mã hóa và chỉ dùng để phân tích dinh dưỡng.</p>
      </div>
      
      <form onSubmit={handleSubmit} className="space-y-8 relative z-10">
        <div className={`grid grid-cols-1 ${formData.nutritionGoal === 'medical' ? 'md:grid-cols-2' : ''} gap-8`}>
          <div className="space-y-6">
            <div className="bg-black/30 p-6 rounded-2xl border border-gray-700/50 backdrop-blur-sm">
                <h3 className="text-sm font-bold text-cyan-400 uppercase tracking-widest mb-4 flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full"></span> {t.basic_info}
                </h3>
                <div className="space-y-5">
                    <div className="relative group">
                        <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                            <PhoneIcon className="w-5 h-5 text-gray-500 group-focus-within:text-cyan-400 transition-colors" />
                        </div>
                        <input type="tel" name="phone" placeholder=" " value={formData.phone} onChange={handleChange} onBlur={handlePhoneBlur} required 
                            className="block px-2.5 pb-2.5 pt-4 pl-10 w-full text-sm text-white bg-gray-800/50 rounded-lg border border-gray-700 appearance-none focus:outline-none focus:ring-0 focus:border-cyan-500 focus:bg-gray-800 transition-all peer" />
                        <label className="absolute text-sm text-gray-400 duration-300 transform -translate-y-4 scale-75 top-2 z-10 origin-[0] left-10 peer-focus:text-cyan-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:-translate-y-1/2 peer-placeholder-shown:top-1/2 peer-focus:top-2 peer-focus:scale-75 peer-focus:-translate-y-4">
                            {t.phone_id}
                        </label>
                    </div>
                    
                    <div className="relative group">
                        <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                            <UserIcon className="w-5 h-5 text-gray-500 group-focus-within:text-cyan-400 transition-colors" />
                        </div>
                        <input type="text" name="fullName" placeholder=" " value={formData.fullName} onChange={handleChange} required 
                            className="block px-2.5 pb-2.5 pt-4 pl-10 w-full text-sm text-white bg-gray-800/50 rounded-lg border border-gray-700 appearance-none focus:outline-none focus:ring-0 focus:border-cyan-500 focus:bg-gray-800 transition-all peer" />
                        <label className="absolute text-sm text-gray-400 duration-300 transform -translate-y-4 scale-75 top-2 z-10 origin-[0] left-10 peer-focus:text-cyan-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:-translate-y-1/2 peer-placeholder-shown:top-1/2 peer-focus:top-2 peer-focus:scale-75 peer-focus:-translate-y-4">
                            {t.full_name}
                        </label>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                         <div className="relative group">
                            <input type="number" name="birthYear" placeholder=" " value={formData.birthYear} onChange={handleChange} required 
                                className="block px-2.5 pb-2.5 pt-4 w-full text-sm text-white bg-gray-800/50 rounded-lg border border-gray-700 appearance-none focus:outline-none focus:ring-0 focus:border-cyan-500 focus:bg-gray-800 transition-all peer" />
                            <label className="absolute text-sm text-gray-400 duration-300 transform -translate-y-4 scale-75 top-2 z-10 origin-[0] left-2.5 peer-focus:text-cyan-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:-translate-y-1/2 peer-placeholder-shown:top-1/2 peer-focus:top-2 peer-focus:scale-75 peer-focus:-translate-y-4">
                                {t.birth_year}
                            </label>
                        </div>
                        <div className="relative">
                            <select name="gender" value={formData.gender} onChange={handleChange} className="block px-2.5 pb-2.5 pt-4 w-full text-sm text-white bg-gray-800/50 rounded-lg border border-gray-700 appearance-none focus:outline-none focus:ring-0 focus:border-cyan-500 focus:bg-gray-800 transition-all">
                                <option value="male">{t.male}</option>
                                <option value="female">{t.female}</option>
                                <option value="other">{t.other}</option>
                            </select>
                            <label className="absolute text-sm text-gray-400 duration-300 transform -translate-y-4 scale-75 top-2 z-10 origin-[0] left-2.5">
                                Giới tính
                            </label>
                        </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                        <div className="relative group">
                            <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                                <WeightIcon className="w-5 h-5 text-gray-500 group-focus-within:text-cyan-400 transition-colors" />
                            </div>
                            <input type="number" name="weight" placeholder=" " value={formData.weight} onChange={handleChange} required 
                                className="block px-2.5 pb-2.5 pt-4 pl-10 w-full text-sm text-white bg-gray-800/50 rounded-lg border border-gray-700 appearance-none focus:outline-none focus:ring-0 focus:border-cyan-500 focus:bg-gray-800 transition-all peer" />
                            <label className="absolute text-sm text-gray-400 duration-300 transform -translate-y-4 scale-75 top-2 z-10 origin-[0] left-10 peer-focus:text-cyan-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:-translate-y-1/2 peer-placeholder-shown:top-1/2 peer-focus:top-2 peer-focus:scale-75 peer-focus:-translate-y-4">
                                {t.weight}
                            </label>
                        </div>
                        <div className="relative group">
                            <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                                <HeightIcon className="w-5 h-5 text-gray-500 group-focus-within:text-cyan-400 transition-colors" />
                            </div>
                            <input type="number" name="height" placeholder=" " value={formData.height} onChange={handleChange} required 
                                className="block px-2.5 pb-2.5 pt-4 pl-10 w-full text-sm text-white bg-gray-800/50 rounded-lg border border-gray-700 appearance-none focus:outline-none focus:ring-0 focus:border-cyan-500 focus:bg-gray-800 transition-all peer" />
                            <label className="absolute text-sm text-gray-400 duration-300 transform -translate-y-4 scale-75 top-2 z-10 origin-[0] left-10 peer-focus:text-cyan-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:-translate-y-1/2 peer-placeholder-shown:top-1/2 peer-focus:top-2 peer-focus:scale-75 peer-focus:-translate-y-4">
                                {t.height}
                            </label>
                        </div>
                    </div>
                </div>
            </div>
            
            <div className="space-y-3">
                <label className="block text-sm font-bold text-cyan-400 uppercase tracking-widest flex items-center gap-2 mb-2">
                    <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full"></span> {t.nutrition_goal}
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {GOAL_BUTTONS.map((option) => {
                        const isSelected = formData.nutritionGoal === option.key;
                        const Icon = option.icon;
                        return (
                            <button
                                key={option.key}
                                type="button"
                                onClick={() => handleGoalSelect(option.key)}
                                className={`flex items-center gap-4 p-4 rounded-xl text-left border transition-all duration-300 group relative overflow-hidden ${
                                    isSelected 
                                        ? 'bg-cyan-900/30 border-cyan-500 text-white shadow-[0_0_20px_rgba(6,182,212,0.2)]' 
                                        : 'bg-black/40 border-gray-800 text-gray-400 hover:border-gray-600 hover:bg-gray-800/50'
                                }`}
                            >
                                <div className={`p-3 rounded-full flex-shrink-0 transition-colors ${isSelected ? 'bg-cyan-500 text-black' : 'bg-gray-800 text-gray-500 group-hover:bg-gray-700 group-hover:text-gray-300'}`}>
                                    <Icon className="w-5 h-5" />
                                </div>
                                <span className={`text-sm font-medium ${isSelected ? 'text-cyan-100' : ''}`}>
                                    {option.label}
                                </span>
                                {isSelected && <div className="absolute inset-0 border-2 border-cyan-500/50 rounded-xl animate-pulse"></div>}
                            </button>
                        );
                    })}
                </div>
                
                {formData.nutritionGoal === 'medical' && (
                    <div className="animate-fade-in-up pt-2">
                        <label className="block text-sm font-bold text-cyan-400 mb-2 pl-1">
                            {t.enter_pathology}
                        </label>
                        <textarea
                            name="medicalConditions"
                            value={formData.medicalConditions}
                            onChange={handleChange}
                            rows={3}
                            placeholder={t.medical_conditions_placeholder}
                            className="w-full bg-black/30 border border-cyan-500/30 rounded-xl p-4 focus:outline-none focus:ring-1 focus:ring-cyan-400 text-sm text-white placeholder-gray-600 transition-all focus:bg-black/50"
                        />
                    </div>
                )}
            </div>
          </div>

          {formData.nutritionGoal === 'medical' && (
            <div className="bg-black/30 p-6 rounded-2xl border border-gray-700/50 backdrop-blur-sm animate-fade-in h-fit">
                <h3 className="text-sm font-bold text-cyan-400 uppercase tracking-widest mb-4 flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full"></span> {t.lab_results}
                </h3>
                <div className="space-y-4 text-sm">
                    {renderInput('glucose', 'Glucose (mg/dL)')}
                    {renderInput('hba1c', 'HbA1c (%)')}
                    {renderInput('uricAcid', 'Acid Uric (mg/dL)')}
                    {renderInput('ure', 'Ure (mg/dL)')}
                    {renderInput('creatinine', 'Creatinine (mg/dL)')}
                    {renderInput('albumin', 'Albumin (g/dL)')}
                    {renderInput('protein', 'Protein (g/dL)')}
                    {renderInput('cholesterol', 'Cholesterol (mg/dL)')}
                    {renderInput('triglyceride', 'Triglyceride (mg/dL)')}
                    
                    <div className="grid grid-cols-2 gap-4 pt-2">
                        <div className="relative group">
                            <input type="number" name="systolicBP" placeholder=" " value={formData.labValues.systolicBP} onChange={handleLabChange}
                                className="block px-2.5 pb-2.5 pt-4 w-full text-sm text-white bg-black/30 rounded-lg border border-gray-600 appearance-none focus:outline-none focus:ring-0 focus:border-cyan-500 peer" />
                            <label className="absolute text-sm text-gray-400 duration-300 transform -translate-y-4 scale-75 top-2 z-10 origin-[0] left-2.5 peer-focus:text-cyan-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:-translate-y-1/2 peer-placeholder-shown:top-1/2 peer-focus:top-2 peer-focus:scale-75 peer-focus:-translate-y-4">{t.systolic}</label>
                        </div>
                        <div className="relative group">
                            <input type="number" name="diastolicBP" placeholder=" " value={formData.labValues.diastolicBP} onChange={handleLabChange}
                                className="block px-2.5 pb-2.5 pt-4 w-full text-sm text-white bg-black/30 rounded-lg border border-gray-600 appearance-none focus:outline-none focus:ring-0 focus:border-cyan-500 peer" />
                            <label className="absolute text-sm text-gray-400 duration-300 transform -translate-y-4 scale-75 top-2 z-10 origin-[0] left-2.5 peer-focus:text-cyan-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:-translate-y-1/2 peer-placeholder-shown:top-1/2 peer-focus:top-2 peer-focus:scale-75 peer-focus:-translate-y-4">{t.diastolic}</label>
                        </div>
                    </div>
                </div>
            </div>
          )}
        </div>
        
        <div className="space-y-4 pt-4 border-t border-gray-800/50">
            <div className="flex items-center justify-center gap-2 text-xs text-emerald-400 bg-emerald-900/10 p-2 rounded-lg border border-emerald-500/20 max-w-fit mx-auto">
                <LockClosedIcon className="w-3 h-3" />
                Dữ liệu được bảo mật tuyệt đối và lưu trữ trong hồ sơ dinh dưỡng cá nhân của bạn
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <button 
                    type="button" 
                    onClick={onSkip}
                    className="w-full flex justify-center items-center gap-2 bg-gray-800 hover:bg-gray-700 text-gray-300 font-bold py-4 px-6 rounded-xl transition-all duration-300 border border-gray-700 hover:border-gray-500"
                >
                    <MenuIcon className="w-5 h-5" />
                    {t.view_menu}
                </button>
                <button type="submit" disabled={isLoading} className="w-full flex justify-center items-center gap-2 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold py-4 px-6 rounded-xl shadow-[0_0_20px_rgba(6,182,212,0.3)] transition-all duration-300 disabled:from-gray-800 disabled:to-gray-800 disabled:text-gray-500 disabled:shadow-none hover:scale-[1.02] active:scale-95 group">
                {isLoading ? (
                    <>
                    <SpinnerIcon className="-ml-1 mr-3 h-5 w-5 text-white" />
                    {t.analyzing}
                    </>
                ) : (
                    <>
                    <SparklesIcon className="w-5 h-5 group-hover:animate-spin" />
                    {t.analyze_nutrition}
                    </>
                )}
                </button>
            </div>
        </div>
      </form>
    </div>
  );
};
