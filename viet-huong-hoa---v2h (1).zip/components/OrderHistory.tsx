
import React, { useState, useEffect, useMemo } from 'react';
import { PastOrderType, RatingMap, CommunityRatingMap, UserData, Language } from '../types';
import { HistoryIcon, TrashIcon } from './Icons';
import { StarRating } from './StarRating'; 
import { MOCK_COMMUNITY_RATINGS, TRANSLATIONS, getMenuItemTranslation } from '../constants';

interface OrderHistoryProps {
  onBack: () => void;
  currentUser: UserData;
  language: Language;
}

// Helper function to safely parse JSON from localStorage for a specific user
const getFromStorage = <T,>(key: string, phone: string, fallback: T): T => {
    try {
        const stored = localStorage.getItem(key);
        const allData = stored ? JSON.parse(stored) : {};
        return allData[phone] || fallback;
    } catch (e) {
        console.error(`Failed to parse ${key} for user ${phone} from storage:`, e);
        return fallback;
    }
};

export const OrderHistory: React.FC<OrderHistoryProps> = ({ onBack, currentUser, language }) => {
  const phone = currentUser.phone;
  const [history, setHistory] = useState<PastOrderType[]>([]);
  const [userRatings, setUserRatings] = useState<RatingMap>({});
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const t = TRANSLATIONS[language];

  useEffect(() => {
    const storedHistory = getFromStorage<PastOrderType[]>('orderHistories', phone, []);
    setHistory(storedHistory.sort((a, b) => b.id - a.id));
    
    const storedRatings = getFromStorage<RatingMap>('userRatingsCollection', phone, {});
    setUserRatings(storedRatings);
  }, [phone]);

  const handleRateItem = (itemId: string, newRating: number) => {
    const oldRating = userRatings[itemId] || 0;

    const updatedUserRatings = { ...userRatings, [itemId]: newRating };
    setUserRatings(updatedUserRatings);

    try {
        const allUserRatings = JSON.parse(localStorage.getItem('userRatingsCollection') || '{}');
        allUserRatings[phone] = updatedUserRatings;
        localStorage.setItem('userRatingsCollection', JSON.stringify(allUserRatings));

        const communityRatings = JSON.parse(localStorage.getItem('communityRatings') || '{}');
        const itemRating = communityRatings[itemId] || { totalRating: 0, count: 0 };

        if (oldRating === 0) {
            itemRating.totalRating += newRating;
            itemRating.count += 1;
        } else {
            itemRating.totalRating = itemRating.totalRating - oldRating + newRating;
        }

        const updatedCommunityRatings = { ...communityRatings, [itemId]: itemRating };
        localStorage.setItem('communityRatings', JSON.stringify(updatedCommunityRatings));
    } catch (e) {
        console.error("Failed to save ratings:", e);
        setUserRatings(userRatings); // Revert on failure
    }
  };
  
  const filteredHistory = useMemo(() => {
    return history.filter(order => {
        const orderDate = order.date.substring(0, 10);
        const isAfterStartDate = startDate ? orderDate >= startDate : true;
        const isBeforeEndDate = endDate ? orderDate <= endDate : true;
        return isAfterStartDate && isBeforeEndDate;
    });
  }, [history, startDate, endDate]);

  const handleClearHistory = () => {
    if (window.confirm('Bạn có chắc chắn muốn xóa toàn bộ lịch sử đặt món của bạn?')) {
        try {
            const allHistories = JSON.parse(localStorage.getItem('orderHistories') || '{}');
            delete allHistories[phone];
            localStorage.setItem('orderHistories', JSON.stringify(allHistories));
            setHistory([]);
        } catch (e) {
            console.error("Failed to clear history:", e);
        }
    }
  };

  const handleClearFilters = () => {
    setStartDate('');
    setEndDate('');
  };

  return (
    <div className="max-w-4xl mx-auto p-6 sm:p-8 bg-gray-900/60 backdrop-blur-xl rounded-2xl shadow-lg border border-cyan-500/20 animate-fade-in">
      <div className="flex justify-between items-center mb-6 pb-4 border-b border-gray-700">
        <h2 className="text-2xl sm:text-3xl font-bold text-cyan-300 flex items-center gap-3">
            <HistoryIcon className="w-7 h-7 sm:w-8 sm:h-8" />
            {t.history_and_rating}
        </h2>
        <button onClick={onBack} className="bg-gray-700 hover:bg-gray-600 text-white font-semibold py-2 px-4 rounded-lg transition-colors">
            {t.back}
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6 p-4 bg-gray-900/50 rounded-lg border border-gray-700">
        <div>
            <label htmlFor="startDate" className="block text-sm font-medium text-cyan-200 mb-1">{t.from_date}</label>
            <input 
                type="date" 
                id="startDate" 
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full bg-gray-800 p-2 rounded-md border border-gray-600 focus:ring-2 focus:ring-cyan-500 sm:text-sm text-white"
            />
        </div>
        <div>
            <label htmlFor="endDate" className="block text-sm font-medium text-cyan-200 mb-1">{t.to_date}</label>
            <input 
                type="date" 
                id="endDate" 
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full bg-gray-800 p-2 rounded-md border border-gray-600 focus:ring-2 focus:ring-cyan-500 sm:text-sm text-white"
            />
        </div>
        <div className="flex items-end">
             <button 
                onClick={handleClearFilters} 
                className="w-full bg-gray-700 hover:bg-gray-600 text-white font-semibold py-2 px-4 rounded-lg transition-colors text-sm"
            >
                {t.clear_filter}
            </button>
        </div>
      </div>

      {filteredHistory.length === 0 ? (
        <p className="text-center text-gray-400 py-10">
            {history.length > 0 ? 'Không tìm thấy đơn hàng nào trong khoảng thời gian đã chọn.' : t.no_orders}
        </p>
      ) : (
        <div className="space-y-6 max-h-[60vh] overflow-y-auto pr-3">
          {filteredHistory.map(order => (
            <div key={order.id} className="bg-gray-800/70 p-4 rounded-lg border border-gray-700">
              <div className="flex justify-between items-center mb-3 border-b border-gray-700 pb-3">
                 <div>
                    <p className="font-semibold text-white">{t.order_id}{order.id}</p>
                    <p className="text-sm text-gray-400">{new Date(order.date).toLocaleString(language === 'vi' ? 'vi-VN' : 'en-US')}</p>
                 </div>
                 <p className="text-lg font-bold text-cyan-400">{order.totalPrice.toLocaleString()}đ</p>
              </div>
              <ul className="space-y-4 text-sm">
                {order.items.map(item => {
                  const { name } = getMenuItemTranslation(item.menuItem, language);
                  return (
                    <li key={item.id}>
                      <div className="flex justify-between items-start">
                        <div className="flex-grow pr-4">
                          <span className="text-gray-200 font-medium">{name}</span>
                          <span className="text-gray-400"> x{item.quantity}</span>
                           {item.selectedOptions.length > 0 && (
                              <div className="text-xs text-gray-500 mt-1 pl-3 border-l-2 border-gray-600">
                                {item.selectedOptions.map(opt => {
                                  const customization = item.menuItem.customizations?.find(c => c.id === opt.customizationId);
                                  const option = customization?.options.find(o => o.id === opt.optionId);
                                  return <div key={opt.optionId}>+ {option?.name}</div>;
                                })}
                              </div>
                           )}
                        </div>
                        <span className="text-white font-semibold">{item.totalPrice.toLocaleString()}đ</span>
                      </div>
                      <div className="mt-2 flex items-center gap-2">
                          <span className="text-xs text-gray-400">{t.your_rating}</span>
                          <StarRating 
                              rating={userRatings[item.menuItem.id] || 0} 
                              onRate={(r) => handleRateItem(item.menuItem.id, r)} 
                              size="w-4 h-4"
                          />
                      </div>
                    </li>
                  );
                })}
              </ul>
            </div>
          ))}
        </div>
      )}
      
      {history.length > 0 && (
          <div className="mt-6 text-center">
              <button onClick={handleClearHistory} className="text-red-400 hover:text-red-300 text-sm flex items-center justify-center gap-2 mx-auto transition-colors">
                  <TrashIcon className="w-4 h-4" />
                  {t.clear_history}
              </button>
          </div>
      )}
    </div>
  );
};
