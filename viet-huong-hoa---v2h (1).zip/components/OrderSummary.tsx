
import React from 'react';
import { OrderItemType, Language } from '../types';
import { TrashIcon } from './Icons';
import { TRANSLATIONS, getMenuItemTranslation } from '../constants';

interface OrderSummaryProps {
  selectedItems: OrderItemType[];
  onRemoveItem: (id: string) => void;
  onPlaceOrder: () => void;
  language: Language;
}

export const OrderSummary: React.FC<OrderSummaryProps> = ({ selectedItems, onRemoveItem, onPlaceOrder, language }) => {
  const t = TRANSLATIONS[language];
  const totalPrice = selectedItems.reduce((sum, item) => sum + item.totalPrice, 0);

  return (
    <div className="bg-gray-900/60 backdrop-blur-xl p-6 rounded-2xl border border-cyan-500/20 shadow-lg shadow-cyan-900/10 sticky top-8">
      <h3 className="text-xl font-bold text-cyan-300 mb-4">{t.order_summary}</h3>
      
      {selectedItems.length === 0 ? (
        <div className="text-center py-8 text-gray-500">
          <p>{t.empty_cart}</p>
          <p className="text-sm mt-1">{t.empty_cart_hint}</p>
        </div>
      ) : (
        <>
          <div className="space-y-4 max-h-[300px] overflow-y-auto pr-2 custom-scrollbar mb-4">
            {selectedItems.map((item) => {
              const { name } = getMenuItemTranslation(item.menuItem, language);
              return (
                <div key={item.id} className="flex justify-between items-start bg-gray-800/40 p-3 rounded-lg border border-gray-700/50 group hover:bg-gray-800/60 transition-colors">
                  <div className="flex-grow pr-2">
                    <div className="flex justify-between">
                      <span className="font-medium text-white text-sm">{name}</span>
                      <span className="text-xs text-gray-400 ml-2 whitespace-nowrap">x{item.quantity}</span>
                    </div>
                    {item.selectedOptions.length > 0 && (
                      <div className="text-xs text-gray-500 mt-1 pl-2 border-l-2 border-gray-700">
                          {item.selectedOptions.map((opt, idx) => {
                              const customization = item.menuItem.customizations?.find(c => c.id === opt.customizationId);
                              const option = customization?.options.find(o => o.id === opt.optionId);
                              return option ? <div key={idx}>+ {option.name}</div> : null;
                          })}
                      </div>
                    )}
                    <div className="flex justify-between items-center mt-2">
                       <span className="text-cyan-400 font-bold text-sm">{item.totalPrice.toLocaleString()}đ</span>
                    </div>
                  </div>
                  <button 
                      onClick={() => onRemoveItem(item.id)} 
                      className="text-gray-500 hover:text-red-400 p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                      title={t.remove}
                  >
                    <TrashIcon className="w-4 h-4" />
                  </button>
                </div>
              );
            })}
          </div>
          
          <div className="border-t border-gray-700 pt-4 space-y-4">
            <div className="flex justify-between items-center text-lg">
              <span className="font-semibold text-gray-300">{t.total}:</span>
              <span className="font-bold text-cyan-400 text-xl">{totalPrice.toLocaleString()}đ</span>
            </div>
            <button 
              onClick={onPlaceOrder}
              className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold py-3 px-4 rounded-lg shadow-lg shadow-cyan-500/20 transition-all duration-300 transform hover:-translate-y-0.5 active:translate-y-0"
            >
              {t.proceed_order}
            </button>
          </div>
        </>
      )}
    </div>
  );
};
