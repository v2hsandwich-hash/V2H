
import React, { useState, useMemo, useEffect, useRef } from 'react';
import { MenuItemType, OrderItemType, AnalysisResult, UserData, RecommendationLevel, CommunityRatingMap, Language } from '../types';
import { CustomizationModal } from './CustomizationModal';
import { MENU_CATEGORIES, MENU_SUBCATEGORIES, MOCK_COMMUNITY_RATINGS, getMenuItemTranslation, TRANSLATIONS } from '../constants';
import { StarIcon } from './Icons';

// --- Copied from Menu.tsx for self-containment ---
const ThumbsUpIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 20 20" fill="currentColor">
        <path d="M1 8.25a1.25 1.25 0 112.5 0v7.5a1.25 1.25 0 11-2.5 0v-7.5zM18.868 9.523c.142.26.21.554.21.854V15.5a2.25 2.25 0 01-2.25 2.25h-6.172a5.502 5.502 0 01-4.729-2.731l-1.635-3.447c-.34-.716-.183-1.58.38-2.115l3.24-2.923c.534-.482 1.32-.482 1.854 0l1.64 1.64c.287.287.713.364 1.096.176l2.12-1.06c.717-.358 1.543.18 1.543.992v1.516z" />
    </svg>
);
const CheckCircleIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 20 20" fill="currentColor">
      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.857-9.809a.75.75 0 00-1.214-.882l-3.483 4.79-1.88-1.88a.75.75 0 10-1.06 1.061l2.5 2.5a.75.75 0 001.137-.089l4-5.5z" clipRule="evenodd" />
    </svg>
);
const EyeIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 20 20" fill="currentColor">
        <path d="M10 12.5a2.5 2.5 0 100-5 2.5 2.5 0 000 5z" />
        <path fillRule="evenodd" d="M.664 10.59a1.651 1.651 0 010-1.18l3.75-3.75a1.65 1.65 0 012.332 0l1.25 1.25a.67.67 0 00.946 0l.94-1.594a1.65 1.65 0 012.332 0l3.75 3.75a1.65 1.65 0 010 1.18l-3.75 3.75a1.65 1.65 0 01-2.332 0l-1.25-1.25a.67.67 0 00-.946 0l-.94 1.594a1.65 1.65 0 01-2.332 0l-3.75-3.75z" clipRule="evenodd" />
    </svg>
);
const ExclamationTriangleIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 20 20" fill="currentColor">
        <path fillRule="evenodd" d="M8.485 2.495c.673-1.167 2.357-1.167 3.03 0l6.28 10.875c.673 1.167-.17 2.625-1.516 2.625H3.72c-1.347 0-2.189-1.458-1.515-2.625L8.485 2.495zM10 5a.75.75 0 01.75.75v3.5a.75.75 0 01-1.5 0v-3.5A.75.75 0 0110 5zm0 9a1 1 0 100-2 1 1 0 000 2z" clipRule="evenodd" />
    </svg>
);

const getRecommendationLevel = (item: MenuItemType, analysis: AnalysisResult, userData: UserData): RecommendationLevel => {
    const dailyCalories = analysis.energyNeeds?.calories || 2000;
    const { bmi, healthAnalysis, foodsToAvoid } = analysis;
    const { nutritionGoal } = userData;
    const lowerCaseItemName = (item.name || '').toLowerCase();

    if (foodsToAvoid?.some(food => {
        const lowerFood = (food || '').toLowerCase();
        if (lowerFood.includes('đồ ngọt') && (lowerCaseItemName.includes('chè') || lowerCaseItemName.includes('latte'))) return true;
        if (lowerFood.includes('chất béo') && item.fat > 25) return true;
        if (lowerFood.includes('thịt đỏ') && lowerCaseItemName.includes('bò')) return true;
        return lowerCaseItemName.includes(lowerFood);
    })) {
        return RecommendationLevel.Limit;
    }

    const lowerHealthAnalysis = (healthAnalysis || '').toLowerCase();
    if ((lowerHealthAnalysis.includes('tiểu đường') || lowerHealthAnalysis.includes('glucose cao')) && item.carbs > 60) return RecommendationLevel.Limit;
    if ((lowerHealthAnalysis.includes('gout') || lowerHealthAnalysis.includes('acid uric')) && item.protein > 35 && (lowerCaseItemName.includes('bò') || lowerCaseItemName.includes('hải sản'))) return RecommendationLevel.Limit;
    if ((lowerHealthAnalysis.includes('cholesterol') || lowerHealthAnalysis.includes('tim mạch') || lowerHealthAnalysis.includes('mỡ máu')) && item.fat > 25) return RecommendationLevel.Limit;

    if (nutritionGoal === 'obese' || (bmi?.category || '').toLowerCase().includes('béo phì')) {
        if (item.calories > dailyCalories * 0.40) return RecommendationLevel.Limit;
    }
    if (nutritionGoal === 'eat_clean' && (lowerCaseItemName.includes('hamburger') || item.fat > 20)) return RecommendationLevel.Limit;

    if (nutritionGoal === 'gym' && item.protein > 30) return RecommendationLevel.GoodForYou;
    if (nutritionGoal === 'eat_clean' && (lowerCaseItemName.includes('salad') || lowerCaseItemName.includes('nước ép'))) return RecommendationLevel.GoodForYou;
    if (nutritionGoal === 'underweight' && item.calories > dailyCalories * 0.30 && item.protein > 20) return RecommendationLevel.GoodForYou;
    if ((nutritionGoal === 'obese' || (bmi?.category || '').toLowerCase().includes('béo phì')) && item.calories < dailyCalories * 0.20 && item.protein > 20) return RecommendationLevel.GoodForYou;
    if (item.calories < dailyCalories * 0.20 && item.protein > 25 && item.fat < 15) return RecommendationLevel.GoodForYou;

    if (item.calories > dailyCalories * 0.35) return RecommendationLevel.Consider;
    if (item.carbs > 80 || item.fat > 30) return RecommendationLevel.Consider;

    return RecommendationLevel.Suitable;
};

const RECOMMENDATION_STYLES: Record<RecommendationLevel, { text: string; className: string; icon: React.FC<{className?: string}> }> = {
    [RecommendationLevel.GoodForYou]: { text: 'Phù hợp', className: 'bg-emerald-500/80 border-emerald-400/50 shadow-[0_0_10px_rgba(16,185,129,0.4)]', icon: ThumbsUpIcon },
    [RecommendationLevel.Suitable]: { text: 'Phù hợp', className: 'bg-cyan-600/80 border-cyan-500/50 shadow-[0_0_10px_rgba(6,182,212,0.4)]', icon: CheckCircleIcon },
    [RecommendationLevel.Consider]: { text: 'Lưu ý', className: 'bg-amber-500/80 border-amber-400/50 shadow-[0_0_10px_rgba(245,158,11,0.4)]', icon: EyeIcon },
    [RecommendationLevel.Limit]: { text: 'Hạn chế', className: 'bg-fuchsia-600/80 border-fuchsia-500/50 shadow-[0_0_10px_rgba(192,38,211,0.4)]', icon: ExclamationTriangleIcon },
};

interface MealSelectorModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSelectMeal: (item: OrderItemType) => void;
    menuItems: Record<string, MenuItemType[]>;
    analysis: AnalysisResult;
    userData: UserData;
    language: Language;
}

interface MenuItemProps {
  item: MenuItemType;
  onSelect: (item: MenuItemType) => void;
  analysis: AnalysisResult;
  userData: UserData;
  averageRating: number;
  ratingCount: number;
  language: Language;
}

// --- Local MenuItem (Replica of Menu.tsx MenuItem but with 'Select' button) ---
const MenuItem: React.FC<MenuItemProps> = ({ item, onSelect, analysis, userData, averageRating, ratingCount, language }) => {
  const { name, description } = getMenuItemTranslation(item, language);
  
  const recommendation = useMemo(() => {
      const level = getRecommendationLevel(item, analysis, userData);
      return RECOMMENDATION_STYLES[level];
  }, [item, analysis, userData]);

  const dietaryLabels = useMemo(() => {
      const labs = [];
      const t = TRANSLATIONS[language];
      if (item.carbs <= 30) labs.push({ text: t.low_carb, className: 'bg-blue-600/90 text-white' });
      if (item.protein <= 15) labs.push({ text: t.low_protein, className: 'bg-rose-600/90 text-white' });
      if (item.fat <= 10) labs.push({ text: t.low_fat, className: 'bg-amber-600/90 text-white' });
      return labs;
  }, [item, language]);

  const RecommendationIcon = recommendation.icon;
  
  const cardRef = useRef<HTMLDivElement>(null);
  const [rotate, setRotate] = useState({ x: 0, y: 0 });

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
      if (!cardRef.current) return;
      const rect = cardRef.current.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      const centerX = rect.width / 2;
      const centerY = rect.height / 2;
      const rotateX = ((y - centerY) / centerY) * -5; 
      const rotateY = ((x - centerX) / centerX) * 5;
      setRotate({ x: rotateX, y: rotateY });
  };

  const handleMouseLeave = () => {
      setRotate({ x: 0, y: 0 });
  };

  return (
    <div 
        ref={cardRef}
        onMouseMove={handleMouseMove}
        onMouseLeave={handleMouseLeave}
        className="relative group h-full transition-all duration-200 ease-out"
        style={{
            transform: `perspective(1000px) rotateX(${rotate.x}deg) rotateY(${rotate.y}deg) scale3d(1, 1, 1)`,
            transition: 'transform 0.1s ease-out'
        }}
    >
      <div className="bg-gray-900/40 backdrop-blur-md rounded-xl border border-cyan-500/20 flex flex-col justify-between h-full overflow-hidden shadow-lg hover:shadow-cyan-500/20 hover:border-cyan-500/50 transition-all duration-300">
        <div>
          <div className="relative overflow-hidden">
            <img src={item.image} alt={name} className="w-full h-32 object-cover transition-transform duration-700 group-hover:scale-110" loading="lazy" />
            <div className="absolute inset-0 bg-gradient-to-tr from-white/0 via-white/10 to-white/0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" style={{ backgroundSize: '200% 200%' }}></div>
             {recommendation && (
                <div aria-label={`Khuyến nghị: ${recommendation.text}`} className={`absolute top-2 left-2 text-white text-[10px] font-bold py-0.5 px-2 rounded-full border backdrop-blur-md flex items-center gap-1 z-10 ${recommendation.className}`}>
                    <RecommendationIcon className="w-3 h-3" />
                    <span>{recommendation.text}</span>
                </div>
            )}
            
            <div className="absolute bottom-2 left-2 flex flex-col gap-1 z-10">
                {dietaryLabels.map((label, idx) => (
                    <span key={idx} className={`text-[8px] font-bold px-1.5 py-0.5 rounded backdrop-blur-md border border-white/10 shadow-sm ${label.className}`}>
                        {label.text}
                    </span>
                ))}
            </div>

            <div className="absolute bottom-2 right-2 bg-black/80 backdrop-blur-md border border-white/10 text-cyan-300 font-bold text-xs py-0.5 px-2 rounded-md shadow-lg z-10">
              {item.price.toLocaleString()}đ
            </div>
          </div>
          
          <div className="p-3">
            <h4 className="text-sm font-bold text-white truncate mb-1 group-hover:text-cyan-300 transition-colors" title={name}>{name}</h4>
            <div className="flex items-center gap-1 mb-1.5 h-4">
                {ratingCount > 0 ? (
                    <>
                        <StarIcon className="w-3 h-3 text-yellow-400 fill-yellow-400" />
                        <span className="text-xs font-bold text-white">{averageRating.toFixed(1)}</span>
                    </>
                ) : null}
            </div>
            <p className="text-[10px] text-gray-400 mb-2 h-8 overflow-hidden leading-relaxed line-clamp-2">{description}</p>
            <div className="flex justify-around text-center text-[10px] mb-2 border-y border-gray-700/50 py-2 bg-gray-800/20 rounded-lg">
              <div>
                <p className="font-bold text-cyan-300">{item.calories}</p>
                <p className="text-gray-500 uppercase tracking-wider text-[8px]">kcal</p>
              </div>
              <div>
                <p className="font-bold text-blue-300">{item.carbs}</p>
                <p className="text-gray-500 uppercase tracking-wider text-[8px]">C</p>
              </div>
              <div>
                <p className="font-bold text-rose-300">{item.protein}</p>
                <p className="text-gray-500 uppercase tracking-wider text-[8px]">P</p>
              </div>
              <div>
                <p className="font-bold text-amber-300">{item.fat}</p>
                <p className="text-gray-500 uppercase tracking-wider text-[8px]">F</p>
              </div>
            </div>
          </div>
        </div>
        <div className="p-3 pt-0 mt-auto">
            <button 
                onClick={() => onSelect(item)} 
                className="w-full bg-gradient-to-r from-cyan-600 to-blue-600 text-white px-2 py-2 text-xs rounded-lg hover:from-cyan-500 hover:to-blue-500 transition-all font-bold shadow-lg shadow-cyan-900/30 hover:shadow-cyan-500/40 active:scale-95"
            >
                Chọn món này
            </button>
        </div>
      </div>
    </div>
  );
};

export const MealSelectorModal: React.FC<MealSelectorModalProps> = ({ isOpen, onClose, onSelectMeal, menuItems, analysis, userData, language }) => {
    const [activeCategory, setActiveCategory] = useState<string>(MENU_CATEGORIES.COFFEE);
    const [activeSubCategory, setActiveSubCategory] = useState<string | null>(MENU_SUBCATEGORIES[MENU_CATEGORIES.COFFEE][0]);
    const [customizingItem, setCustomizingItem] = useState<MenuItemType | null>(null);
    const [communityRatings, setCommunityRatings] = useState<CommunityRatingMap>({});

    useEffect(() => {
        try {
            const storedRatings = localStorage.getItem('communityRatings');
            if (storedRatings) {
                setCommunityRatings(JSON.parse(storedRatings));
            } else {
                setCommunityRatings(MOCK_COMMUNITY_RATINGS);
            }
        } catch (e) {
            console.error("Failed to load community ratings:", e);
            setCommunityRatings(MOCK_COMMUNITY_RATINGS);
        }
    }, []);

    useEffect(() => {
        const subs = MENU_SUBCATEGORIES[activeCategory];
        if (subs && subs.length > 0) {
            setActiveSubCategory(subs[0]);
        } else {
            setActiveSubCategory(null);
        }
    }, [activeCategory]);

    // FIX: Explicitly cast Object.values result to resolve 'unknown' type error in reduce
    const allItems = useMemo(() => (Object.values(menuItems) as MenuItemType[][]).reduce<MenuItemType[]>((acc, val) => acc.concat(val), []), [menuItems]);

    const filteredItems = useMemo(() => {
        // 1. Filter by Category
        let items = allItems.filter(item => item.category === activeCategory);
        if (activeSubCategory) {
            items = items.filter(item => item.subcategory === activeSubCategory);
        }
        
        // Remove Duplicates based on ID
        const unique = new Map();
        items.forEach(i => unique.set(i.id, i));
        return Array.from(unique.values());
    }, [allItems, activeCategory, activeSubCategory]);

    const handleSelectItem = (item: MenuItemType) => {
        if (item.customizations && item.customizations.length > 0) {
            setCustomizingItem(item);
        } else {
            const defaultOrderItem: OrderItemType = {
                id: `${item.id}-${Date.now()}`,
                menuItem: item,
                quantity: 1,
                selectedOptions: [],
                totalPrice: item.price,
                totalNutrition: {
                    calories: item.calories,
                    carbs: item.carbs,
                    protein: item.protein,
                    fat: item.fat,
                }
            };
            onSelectMeal(defaultOrderItem);
        }
    };
    
    const handleConfirmCustomization = (orderItem: OrderItemType) => {
        onSelectMeal(orderItem);
        setCustomizingItem(null);
    };

    if (!isOpen) return null;

    return (
        <>
            <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex justify-center items-center p-4" onClick={onClose}>
                <div 
                    className="bg-gray-900/95 backdrop-blur-xl rounded-2xl shadow-lg w-full max-w-6xl h-[90vh] flex flex-col border border-cyan-500/20 animate-fade-in-up overflow-hidden relative" 
                    onClick={e => e.stopPropagation()}>
                    
                    {/* Header with Close Button (X) */}
                    <button 
                        onClick={onClose} 
                        className="absolute top-4 right-4 text-gray-400 hover:text-white z-50 p-2 bg-black/20 rounded-full hover:bg-red-500/80 transition-all"
                        title="Đóng"
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                        </svg>
                    </button>

                    <div className="p-4 border-b border-gray-700 bg-gray-900/50 flex items-center justify-between">
                        <h3 className="text-xl font-bold text-cyan-300">Chọn món ăn</h3>
                    </div>

                    {/* Category Tabs - Compact Design */}
                    <div className="bg-[#02040a]/60 backdrop-blur-md py-2 px-4 border-b border-gray-800/50 shadow-lg">
                        <div className="flex flex-wrap gap-1.5 pb-1 overflow-x-auto no-scrollbar">
                            {Object.values(MENU_CATEGORIES).filter(cat => cat !== 'Combo').map(cat => (
                                <button
                                    key={cat}
                                    onClick={() => setActiveCategory(cat)}
                                    className={`px-3 py-1.5 rounded-full whitespace-nowrap transition-all font-bold text-[10px] uppercase tracking-wide flex-shrink-0 border ${
                                        activeCategory === cat 
                                            ? 'bg-cyan-600 text-white border-cyan-500 shadow-[0_0_10px_rgba(6,182,212,0.4)]' 
                                            : 'bg-gray-800/50 text-gray-400 border-gray-700 hover:bg-gray-700 hover:text-white'
                                    }`}
                                >
                                    {cat}
                                </button>
                            ))}
                        </div>
                        <div className="flex flex-wrap gap-1.5 min-h-[30px] items-center mt-1">
                            {MENU_SUBCATEGORIES[activeCategory]?.map(sub => (
                                <button
                                    key={sub}
                                    onClick={() => setActiveSubCategory(sub)}
                                    className={`px-2.5 py-1 rounded-md text-[10px] transition-all border ${
                                        activeSubCategory === sub
                                            ? 'bg-cyan-900/80 text-cyan-300 border-cyan-500/50 shadow-sm'
                                            : 'text-gray-400 border-transparent hover:text-white hover:bg-gray-800/50'
                                    }`}
                                >
                                    {sub}
                                </button>
                            ))}
                        </div>
                    </div>

                    {/* Items Grid - Expanded Space */}
                    <div className="p-4 overflow-y-auto bg-gray-900/30 flex-1 custom-scrollbar">
                        {filteredItems.length > 0 ? (
                            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
                                {filteredItems.map(item => (
                                    <div key={item.id} className="h-[320px]">
                                        <MenuItem 
                                            item={item} 
                                            onSelect={handleSelectItem}
                                            analysis={analysis}
                                            userData={userData}
                                            averageRating={communityRatings[item.id]?.totalRating / communityRatings[item.id]?.count || 0}
                                            ratingCount={communityRatings[item.id]?.count || 0}
                                            language={language}
                                        />
                                    </div>
                                ))}
                            </div>
                        ) : (
                            <div className="h-full flex flex-col items-center justify-center text-gray-500">
                                <p>Không tìm thấy món ăn nào trong danh mục này.</p>
                            </div>
                        )}
                    </div>
                </div>
            </div>
            {customizingItem && (
                <CustomizationModal 
                    item={customizingItem}
                    onConfirm={handleConfirmCustomization}
                    onClose={() => setCustomizingItem(null)}
                    language={language}
                />
            )}
        </>
    );
};
