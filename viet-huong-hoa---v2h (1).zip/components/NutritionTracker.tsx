
import React from 'react';
import { OrderItemType, AnalysisResult, AlertLevel, NutritionInfo, Language } from '../types';
import { AlertIcon } from './Icons';
import { TRANSLATIONS } from '../constants';

interface NutritionTrackerProps {
  analysis: AnalysisResult;
  selectedItems: OrderItemType[];
  language: Language;
}

const getAlertInfo = (level: AlertLevel): { color: string; text: string; } => {
  switch (level) {
    case AlertLevel.Green:
      return { color: "text-green-400", text: "Nhu cầu dinh dưỡng được cân đối." };
    case AlertLevel.Yellow:
      return { color: "text-amber-400", text: "Vượt nhẹ mức dinh dưỡng khuyến nghị." };
    case AlertLevel.Red:
      return { color: "text-fuchsia-400", text: "Vượt mức dinh dưỡng cao, mất cân đối nghiêm trọng." };
    default:
      return { color: "text-gray-400", text: "" };
  }
};

const ProgressBar: React.FC<{ value: number; max: number; level: AlertLevel }> = ({ value, max, level }) => {
  const percentage = max > 0 ? Math.min((value / max) * 100, 100) : 0;
  const colorClasses = {
    [AlertLevel.Green]: "bg-cyan-500",
    [AlertLevel.Yellow]: "bg-amber-500",
    [AlertLevel.Red]: "bg-fuchsia-500",
  };
  return (
    <div className="w-full bg-gray-700/50 rounded-full h-2.5">
      <div className={`${colorClasses[level]} h-2.5 rounded-full`} style={{ width: `${percentage}%` }}></div>
    </div>
  );
};

export const NutritionTracker: React.FC<NutritionTrackerProps> = ({ analysis, selectedItems, language }) => {
  const t = TRANSLATIONS[language];
  const totals: NutritionInfo = selectedItems.reduce((acc, item) => ({
    calories: acc.calories + item.totalNutrition.calories,
    carbs: acc.carbs + item.totalNutrition.carbs,
    protein: acc.protein + item.totalNutrition.protein,
    fat: acc.fat + item.totalNutrition.fat,
  }), { calories: 0, carbs: 0, protein: 0, fat: 0 });

  const calorieGoal = analysis.energyNeeds.calories;
  const calorieRatio = totals.calories / calorieGoal;
  
  // Calculate macro goals in grams
  const carbGoalGrams = Math.round((calorieGoal * (analysis.macroDistribution.carbs / 100)) / 4);
  const proteinGoalGrams = Math.round((calorieGoal * (analysis.macroDistribution.protein / 100)) / 4);
  const fatGoalGrams = Math.round((calorieGoal * (analysis.macroDistribution.fat / 100)) / 9);

  let alertLevel: AlertLevel = AlertLevel.Green;
  if (calorieRatio > 1.3) {
    alertLevel = AlertLevel.Red;
  } else if (calorieRatio > 1.1) {
    alertLevel = AlertLevel.Yellow;
  }

  const alertInfo = getAlertInfo(alertLevel);

  const containerClasses = {
    [AlertLevel.Green]: "border-cyan-500/20",
    [AlertLevel.Yellow]: "border-amber-500/50",
    [AlertLevel.Red]: "border-fuchsia-500/80 animate-pulse-red",
  };
  
  const getMacroLevel = (current: number, goal: number): AlertLevel => {
    if (goal === 0) return AlertLevel.Green;
    const ratio = current / goal;
    if (ratio > 1.3) return AlertLevel.Red;
    if (ratio > 1.1) return AlertLevel.Yellow;
    return AlertLevel.Green;
  };

  return (
    <div className={`bg-gray-900/60 backdrop-blur-xl p-6 rounded-2xl border shadow-lg shadow-cyan-900/10 transition-colors duration-500 ${containerClasses[alertLevel]}`}>
      <h3 className="text-xl font-bold text-cyan-300 mb-4">{t.nutrition_tracking}</h3>
      <div className="space-y-4">
        <div>
          <div className="flex justify-between items-baseline mb-1">
            <span className="text-sm font-medium text-gray-300">{t.energy}</span>
            <span className={`text-sm font-semibold ${alertInfo.color}`}>{totals.calories.toLocaleString()} / {calorieGoal.toLocaleString()} kcal</span>
          </div>
          <ProgressBar value={totals.calories} max={calorieGoal} level={alertLevel} />
        </div>

        <div className="space-y-3 pt-3 border-t border-gray-700/50">
           <p className="text-sm font-medium text-gray-300 -mb-1">{t.macronutrients}</p>
            <div>
              <div className="flex justify-between items-baseline text-xs mb-1">
                <span className="font-medium text-blue-300">{t.carbs}</span>
                <span className="text-gray-300">{totals.carbs.toFixed(0)}g / {carbGoalGrams}g</span>
              </div>
              <ProgressBar value={totals.carbs} max={carbGoalGrams} level={getMacroLevel(totals.carbs, carbGoalGrams)} />
            </div>
             <div>
              <div className="flex justify-between items-baseline text-xs mb-1">
                <span className="font-medium text-rose-300">{t.protein}</span>
                <span className="text-gray-300">{totals.protein.toFixed(0)}g / {proteinGoalGrams}g</span>
              </div>
              <ProgressBar value={totals.protein} max={proteinGoalGrams} level={getMacroLevel(totals.protein, proteinGoalGrams)} />
            </div>
             <div>
              <div className="flex justify-between items-baseline text-xs mb-1">
                <span className="font-medium text-amber-300">{t.fat}</span>
                <span className="text-gray-300">{totals.fat.toFixed(0)}g / {fatGoalGrams}g</span>
              </div>
              <ProgressBar value={totals.fat} max={fatGoalGrams} level={getMacroLevel(totals.fat, fatGoalGrams)} />
            </div>
        </div>

        {alertLevel !== AlertLevel.Green && (
            <div className={`p-3 rounded-lg flex items-center gap-3 text-sm border ${alertLevel === AlertLevel.Red ? 'bg-fuchsia-900/50 border-fuchsia-500/50' : 'bg-amber-900/50 border-amber-500/50'}`}>
                <AlertIcon className={`w-8 h-8 flex-shrink-0 ${alertInfo.color}`} />
                <span className={alertInfo.color}>{alertInfo.text}</span>
            </div>
        )}
      </div>
    </div>
  );
};
