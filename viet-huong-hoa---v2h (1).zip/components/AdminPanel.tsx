import React, { useState, useEffect, useMemo } from 'react';
import { MenuItemType, MealType } from '../types';
import { PlusIcon, PencilSquareIcon, TrashIcon, CogIcon, MicrophoneIcon, SpinnerIcon } from './Icons';
import { Dashboard } from './Dashboard';

interface AdminPanelProps {
    menuItems: Record<string, MenuItemType[]>;
    setMenuItems: React.Dispatch<React.SetStateAction<Record<string, MenuItemType[]>>>;
    onBack: () => void;
}

const ProductFormModal: React.FC<{
    item: MenuItemType | null;
    onClose: () => void;
    onSave: (item: MenuItemType, mealType: MealType) => void;
    menuItems: Record<string, MenuItemType[]>;
}> = ({ item, onClose, onSave, menuItems }) => {
    const initialMealType = useMemo(() => {
        if (item) {
            for (const type in menuItems) {
                if (menuItems[type].some(i => i.id === item.id)) {
                    return type as MealType;
                }
            }
        }
        return MealType.Lunch;
    }, [item, menuItems]);

    const [formData, setFormData] = useState<Omit<MenuItemType, 'id' | 'customizations'>>({
        name: '', description: '', price: 0, image: '', calories: 0, carbs: 0,
        protein: 0, fat: 0, stock: 100, ingredientCost: 0
    });
    const [mealType, setMealType] = useState<MealType>(initialMealType);
    const [profitMargin, setProfitMargin] = useState(70);
    const [isListening, setIsListening] = useState(false);
    const [listeningField, setListeningField] = useState<'name' | 'description' | null>(null);

    useEffect(() => {
        if (item) {
            setFormData({
                name: item.name,
                description: item.description,
                price: item.price,
                image: item.image,
                calories: item.calories,
                carbs: item.carbs,
                protein: item.protein,
                fat: item.fat,
                stock: item.stock ?? 100,
                ingredientCost: item.ingredientCost ?? item.price * 0.3,
            });
            setMealType(initialMealType);
        }
    }, [item, initialMealType]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: name === 'price' || name.startsWith('ingredient') || name.startsWith('stock') || name.startsWith('calories') || name.startsWith('carbs') || name.startsWith('protein') || name.startsWith('fat') ? parseFloat(value) || 0 : value }));
    };

    const handleSave = (e: React.FormEvent) => {
        e.preventDefault();
        const savedItem: MenuItemType = {
            ...formData,
            id: item?.id || `custom-${Date.now()}`,
            customizations: item?.customizations || [],
        };
        onSave(savedItem, mealType);
    };

    const suggestedPrice = useMemo(() => {
        if (!formData.ingredientCost || profitMargin >= 100) return 0;
        return Math.ceil((formData.ingredientCost / (1 - profitMargin / 100)) / 1000) * 1000;
    }, [formData.ingredientCost, profitMargin]);

    const handleVoiceInput = (field: 'name' | 'description') => {
        if (isListening) return;

        // FIX: Cast window to `any` to access vendor-prefixed or non-standard SpeechRecognition API.
        const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
        if (!SpeechRecognition) {
            alert("Trình duyệt của bạn không hỗ trợ nhận dạng giọng nói.");
            return;
        }

        const recognition = new SpeechRecognition();
        recognition.lang = 'vi-VN';
        recognition.interimResults = false;

        recognition.onstart = () => {
            setIsListening(true);
            setListeningField(field);
        };

        recognition.onresult = (event: any) => {
            const transcript = event.results[0][0].transcript;
            setFormData(prev => ({ ...prev, [field]: transcript }));
        };

        recognition.onerror = (event: any) => {
            console.error("Speech recognition error", event.error);
        };

        recognition.onend = () => {
            setIsListening(false);
            setListeningField(null);
        };

        recognition.start();
    };

    return (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex justify-center items-center p-4" onClick={onClose}>
            <div className="bg-gray-900/80 rounded-2xl shadow-lg w-full max-w-4xl h-[90vh] flex flex-col border border-cyan-500/20 animate-fade-in-up" onClick={e => e.stopPropagation()}>
                <header className="p-4 border-b border-gray-700">
                    <h3 className="text-xl font-bold text-cyan-300 text-center">{item ? 'Chỉnh sửa món ăn' : 'Thêm món ăn mới'}</h3>
                </header>
                <form onSubmit={handleSave} className="flex-1 overflow-y-auto p-6 space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {/* Column 1: Basic & Pricing Info */}
                        <div className="space-y-4">
                            <h4 className="font-semibold text-cyan-400 border-b border-cyan-500/20 pb-1">Thông tin cơ bản</h4>
                            <div>
                                <label className="block text-sm font-medium text-gray-300 mb-1">Loại bữa ăn</label>
                                <select name="mealType" value={mealType} onChange={(e) => setMealType(e.target.value as MealType)} className="w-full bg-gray-800 p-2 rounded-md border border-gray-600 focus:ring-2 focus:ring-cyan-500">
                                    {Object.entries(MealType).map(([key, value]) => <option key={key} value={value}>{value}</option>)}
                                </select>
                            </div>
                            <div className="relative">
                                <label className="block text-sm font-medium text-gray-300 mb-1">Tên món ăn</label>
                                <input type="text" name="name" value={formData.name} onChange={handleChange} required className="w-full bg-gray-800 p-2 rounded-md border border-gray-600 focus:ring-2 focus:ring-cyan-500 pr-10" />
                                <button type="button" onClick={() => handleVoiceInput('name')} className="absolute right-2 top-8 text-gray-400 hover:text-cyan-400" disabled={isListening}>
                                    {isListening && listeningField === 'name' ? <SpinnerIcon className="w-5 h-5"/> : <MicrophoneIcon className="w-5 h-5"/>}
                                </button>
                            </div>
                            <div className="relative">
                                <label className="block text-sm font-medium text-gray-300 mb-1">Mô tả</label>
                                <textarea name="description" value={formData.description} onChange={handleChange} rows={3} className="w-full bg-gray-800 p-2 rounded-md border border-gray-600 focus:ring-2 focus:ring-cyan-500 pr-10" />
                                <button type="button" onClick={() => handleVoiceInput('description')} className="absolute right-2 top-8 text-gray-400 hover:text-cyan-400" disabled={isListening}>
                                    {isListening && listeningField === 'description' ? <SpinnerIcon className="w-5 h-5"/> : <MicrophoneIcon className="w-5 h-5"/>}
                                </button>
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-300 mb-1">URL Hình ảnh</label>
                                <input type="text" name="image" value={formData.image} onChange={handleChange} required className="w-full bg-gray-800 p-2 rounded-md border border-gray-600 focus:ring-2 focus:ring-cyan-500" />
                            </div>
                             <h4 className="font-semibold text-cyan-400 border-b border-cyan-500/20 pb-1 pt-4">Tồn kho & Định giá</h4>
                             <div>
                                <label className="block text-sm font-medium text-gray-300 mb-1">Số lượng tồn kho</label>
                                <input type="number" name="stock" value={formData.stock} onChange={handleChange} required className="w-full bg-gray-800 p-2 rounded-md border border-gray-600 focus:ring-2 focus:ring-cyan-500" />
                            </div>
                             <div>
                                <label className="block text-sm font-medium text-gray-300 mb-1">Chi phí nguyên liệu (đ)</label>
                                <input type="number" name="ingredientCost" value={formData.ingredientCost} onChange={handleChange} required className="w-full bg-gray-800 p-2 rounded-md border border-gray-600 focus:ring-2 focus:ring-cyan-500" />
                            </div>
                            <div>
                                <label className="flex justify-between items-center text-sm font-medium text-gray-300 mb-1">
                                    <span>Lợi nhuận mục tiêu</span>
                                    <span className="text-cyan-300">{profitMargin}%</span>
                                </label>
                                <input type="range" min="1" max="99" value={profitMargin} onChange={e => setProfitMargin(Number(e.target.value))} className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer slider-thumb" />
                            </div>
                             <div>
                                <label className="block text-sm font-medium text-gray-300 mb-1">Giá bán (đ)</label>
                                <input type="number" name="price" value={formData.price} onChange={handleChange} required className="w-full bg-gray-800 p-2 rounded-md border border-gray-600 focus:ring-2 focus:ring-cyan-500" />
                                {suggestedPrice > 0 && <p className="text-xs text-cyan-400 mt-1">Gợi ý từ AI: {suggestedPrice.toLocaleString()}đ</p>}
                            </div>
                        </div>

                        {/* Column 2: Nutrition Info */}
                        <div className="space-y-4">
                             <h4 className="font-semibold text-cyan-400 border-b border-cyan-500/20 pb-1">Thông tin dinh dưỡng</h4>
                             <div>
                                <label className="block text-sm font-medium text-gray-300 mb-1">Calories (kcal)</label>
                                <input type="number" name="calories" value={formData.calories} onChange={handleChange} required className="w-full bg-gray-800 p-2 rounded-md border border-gray-600 focus:ring-2 focus:ring-cyan-500" />
                            </div>
                             <div>
                                <label className="block text-sm font-medium text-gray-300 mb-1">Đường bột (g)</label>
                                <input type="number" name="carbs" value={formData.carbs} onChange={handleChange} required className="w-full bg-gray-800 p-2 rounded-md border border-gray-600 focus:ring-2 focus:ring-cyan-500" />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-300 mb-1">Chất đạm (g)</label>
                                <input type="number" name="protein" value={formData.protein} onChange={handleChange} required className="w-full bg-gray-800 p-2 rounded-md border border-gray-600 focus:ring-2 focus:ring-cyan-500" />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-300 mb-1">Chất béo (g)</label>
                                <input type="number" name="fat" value={formData.fat} onChange={handleChange} required className="w-full bg-gray-800 p-2 rounded-md border border-gray-600 focus:ring-2 focus:ring-cyan-500" />
                            </div>
                        </div>
                    </div>
                </form>
                <footer className="p-4 mt-auto border-t border-gray-700 flex justify-end gap-4">
                    <button onClick={onClose} className="bg-gray-600 hover:bg-gray-500 text-white font-bold py-2 px-6 rounded-lg">Hủy</button>
                    <button type="submit" onClick={handleSave} className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold py-2 px-6 rounded-lg shadow-lg shadow-cyan-500/20">Lưu thay đổi</button>
                </footer>
            </div>
        </div>
    );
};

const ProductManagementView: React.FC<AdminPanelProps> = ({ menuItems, setMenuItems, onBack }) => {
    const [modalOpen, setModalOpen] = useState(false);
    const [currentItem, setCurrentItem] = useState<MenuItemType | null>(null);

    const handleOpenModal = (item: MenuItemType | null) => {
        setCurrentItem(item);
        setModalOpen(true);
    };

    const handleCloseModal = () => {
        setModalOpen(false);
        setCurrentItem(null);
    };

    const handleSaveItem = (itemData: MenuItemType, mealType: MealType) => {
        setMenuItems(prev => {
            const newMenu = { ...prev };
            Object.keys(newMenu).forEach(type => {
                newMenu[type as MealType] = newMenu[type as MealType].filter(i => i.id !== itemData.id);
            });
            const categoryItems = newMenu[mealType] ? [...newMenu[mealType]] : [];
            const existingIndex = categoryItems.findIndex(i => i.id === itemData.id);
            if (existingIndex > -1) {
                categoryItems[existingIndex] = itemData;
            } else {
                categoryItems.push(itemData);
            }
            newMenu[mealType] = categoryItems;
            return newMenu;
        });
        handleCloseModal();
    };

    const handleDeleteItem = (itemToDelete: MenuItemType) => {
        if (window.confirm(`Bạn có chắc chắn muốn xóa món "${itemToDelete.name}"?`)) {
            setMenuItems(prev => {
                const newMenu = { ...prev };
                for (const mealType in newMenu) {
                    newMenu[mealType as MealType] = newMenu[mealType as MealType].filter(item => item.id !== itemToDelete.id);
                }
                return newMenu;
            });
        }
    };

    return (
        <>
            <div className="flex justify-between items-center mb-6">
                 <div></div> {/* Spacer */}
                 <div className="flex gap-4">
                     <button onClick={() => handleOpenModal(null)} className="flex items-center gap-2 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-semibold py-2 px-4 rounded-lg shadow-lg shadow-cyan-500/20">
                         <PlusIcon className="w-5 h-5" /> Thêm món mới
                     </button>
                 </div>
            </div>
            <div className="space-y-6">
                {Object.keys(menuItems).map((mealType) => {
                    const items = menuItems[mealType as keyof typeof menuItems];
                    return (
                        <div key={mealType} className="bg-gray-900/60 p-4 rounded-lg border border-gray-700/50">
                            <h3 className="text-xl font-semibold text-cyan-400 mb-4">{mealType}</h3>
                            <div className="space-y-2">
                                {items.map(item => (
                                    <div key={item.id} className="flex items-center gap-4 bg-gray-800/50 p-2 rounded-md">
                                        <img src={item.image} alt={item.name} className="w-12 h-12 object-cover rounded-md flex-shrink-0" />
                                        <div className="flex-grow">
                                            <p className="font-semibold text-white">{item.name}</p>
                                            <p className="text-sm text-gray-400">{item.price.toLocaleString()}đ</p>
                                        </div>
                                        <div className="w-24 text-center">
                                            <p className={`font-bold ${item.stock && item.stock <= 10 ? 'text-red-400' : 'text-gray-300'}`}>{item.stock ?? 'N/A'}</p>
                                            <p className="text-xs text-gray-500">Tồn kho</p>
                                        </div>
                                        <div className="flex gap-2">
                                            <button onClick={() => handleOpenModal(item)} className="p-2 text-gray-400 hover:text-cyan-400"><PencilSquareIcon className="w-5 h-5" /></button>
                                            <button onClick={() => handleDeleteItem(item)} className="p-2 text-gray-400 hover:text-red-400"><TrashIcon className="w-5 h-5" /></button>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    );
                })}
            </div>
            {modalOpen && <ProductFormModal item={currentItem} onClose={handleCloseModal} onSave={handleSaveItem} menuItems={menuItems} />}
        </>
    );
};

export const AdminPanel: React.FC<AdminPanelProps> = (props) => {
    const [activeTab, setActiveTab] = useState<'dashboard' | 'products'>('dashboard');

    return (
        <div className="animate-fade-in">
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-3xl font-bold text-cyan-300 flex items-center gap-3">
                    <CogIcon className="w-8 h-8" />
                    Bảng điều khiển
                </h2>
                 <button onClick={props.onBack} className="bg-gray-700 hover:bg-gray-600 text-white font-semibold py-2 px-4 rounded-lg">
                    Quay lại
                </button>
            </div>

            <div className="mb-6 flex border-b border-gray-700">
                <button 
                    onClick={() => setActiveTab('dashboard')}
                    className={`px-4 py-2 text-sm font-semibold transition-colors ${activeTab === 'dashboard' ? 'text-cyan-400 border-b-2 border-cyan-400' : 'text-gray-400 hover:text-white'}`}
                >
                    Thống kê
                </button>
                <button 
                    onClick={() => setActiveTab('products')}
                    className={`px-4 py-2 text-sm font-semibold transition-colors ${activeTab === 'products' ? 'text-cyan-400 border-b-2 border-cyan-400' : 'text-gray-400 hover:text-white'}`}
                >
                    Quản lý sản phẩm
                </button>
            </div>

            {activeTab === 'dashboard' ? <Dashboard /> : <ProductManagementView {...props} />}
        </div>
    );
};