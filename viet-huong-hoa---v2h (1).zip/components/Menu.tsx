
import React, { useState, useMemo, useEffect, useRef } from 'react';
import { MenuItemType, OrderItemType, NutritionInfo, AnalysisResult, RecommendationLevel, UserData, CommunityRatingMap, MenuPackage, MenuPackageCategory, Language } from '../types';
import { MOCK_COMMUNITY_RATINGS, MENU_PACKAGES, MENU_PACKAGE_CATEGORIES, MENU_CATEGORIES, MENU_SUBCATEGORIES, CATEGORY_TRANSLATIONS, TRANSLATIONS, getMenuItemTranslation, getPackageTranslation } from '../constants';
import { CustomizationModal } from './CustomizationModal';
import { AddToPlanModal } from './AddToPlanModal';
import { StarIcon, BoxIcon, PlusIcon } from './Icons';
import { PackageHologramModal } from './PackageHologramModal';

// --- START: Recommendation Icons ---
const ThumbsUpIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 20 20" fill="currentColor">
        <path d="M1 8.25a1.25 1.25 0 112.5 0v7.5a1.25 1.25 0 11-2.5 0v-7.5zM18.868 9.523c.142.26.21.554.21.854V15.5a2.25 2.25 0 01-2.25 2.25h-6.172a5.502 5.502 0 01-4.729-2.731l-1.635-3.447c-.34-.716-.183-1.58.38-2.115l3.24-2.923c.534-.482 1.32-.482 1.854 0l1.64 1.64c.287.287.713.364 1.096.176l2.12-1.06c.717-.358 1.543.18 1.543.992v1.516z" />
    </svg>
);
const CheckCircleIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 20 20" fill="currentColor">
      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.857-9.809a.75.75 0 00-1.214-.882l-3.483 4.79-1.88-1.88a.75.75 0 10-1.06 1.061l2.5 2.5a.75.75 0 001.137-.089l4-5.5z" clipRule="evenodd" />
    </svg>
);
const EyeIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 20 20" fill="currentColor">
        <path d="M10 12.5a2.5 2.5 0 100-5 2.5 2.5 0 000 5z" />
        <path fillRule="evenodd" d="M.664 10.59a1.651 1.651 0 010-1.18l3.75-3.75a1.65 1.65 0 012.332 0l1.25 1.25a.67.67 0 00.946 0l.94-1.594a1.65 1.65 0 012.332 0l3.75 3.75a1.65 1.65 0 010 1.18l-3.75 3.75a1.65 1.65 0 01-2.332 0l-1.25-1.25a.67.67 0 00-.946 0l-.94 1.594a1.65 1.65 0 01-2.332 0l-3.75-3.75z" clipRule="evenodd" />
    </svg>
);
const ExclamationTriangleIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 20 20" fill="currentColor">
        <path fillRule="evenodd" d="M8.485 2.495c.673-1.167 2.357-1.167 3.03 0l6.28 10.875c.673 1.167-.17 2.625-1.516 2.625H3.72c-1.347 0-2.189-1.458-1.515-2.625L8.485 2.495zM10 5a.75.75 0 01.75.75v3.5a.75.75 0 01-1.5 0v-3.5A.75.75 0 0110 5zm0 9a1 1 0 100-2 1 1 0 000 2z" clipRule="evenodd" />
    </svg>
);
// --- END: Recommendation Icons ---


const getRecommendationLevel = (item: MenuItemType, analysis: AnalysisResult, userData: UserData): RecommendationLevel => {
    const dailyCalories = analysis.energyNeeds?.calories || 2000;
    const { bmi, healthAnalysis, foodsToAvoid } = analysis;
    const { nutritionGoal } = userData;
    const lowerCaseItemName = (item.name || '').toLowerCase();

    // --- RULE 1: LIMIT (RED) --- Highest Priority
    if (foodsToAvoid?.some(food => {
        const lowerFood = (food || '').toLowerCase();
        if (lowerFood.includes('đồ ngọt') && (lowerCaseItemName.includes('chè') || lowerCaseItemName.includes('latte'))) return true;
        if (lowerFood.includes('chất béo') && item.fat > 25) return true;
        if (lowerFood.includes('thịt đỏ') && lowerCaseItemName.includes('bò')) return true;
        return lowerCaseItemName.includes(lowerFood);
    })) {
        return RecommendationLevel.Limit;
    }

    const lowerHealthAnalysis = (healthAnalysis || '').toLowerCase();
    if ((lowerHealthAnalysis.includes('tiểu đường') || lowerHealthAnalysis.includes('glucose cao')) && item.carbs > 60) {
        return RecommendationLevel.Limit;
    }
    if ((lowerHealthAnalysis.includes('gout') || lowerHealthAnalysis.includes('acid uric')) && item.protein > 35 && (lowerCaseItemName.includes('bò') || lowerCaseItemName.includes('hải sản'))) {
        return RecommendationLevel.Limit;
    }
    if ((lowerHealthAnalysis.includes('cholesterol') || lowerHealthAnalysis.includes('tim mạch') || lowerHealthAnalysis.includes('mỡ máu')) && item.fat > 25) {
        return RecommendationLevel.Limit;
    }

    if (nutritionGoal === 'obese' || (bmi?.category || '').toLowerCase().includes('béo phì')) {
        if (item.calories > dailyCalories * 0.40) return RecommendationLevel.Limit;
    }
    if (nutritionGoal === 'eat_clean' && (lowerCaseItemName.includes('hamburger') || item.fat > 20)) {
        return RecommendationLevel.Limit;
    }

    // --- RULE 2: GOOD FOR YOU (EMERALD) ---
    if (nutritionGoal === 'gym' && item.protein > 30) {
        return RecommendationLevel.GoodForYou;
    }
    if (nutritionGoal === 'eat_clean' && (lowerCaseItemName.includes('salad') || lowerCaseItemName.includes('nước ép'))) {
        return RecommendationLevel.GoodForYou;
    }
    if (nutritionGoal === 'underweight' && item.calories > dailyCalories * 0.30 && item.protein > 20) {
        return RecommendationLevel.GoodForYou;
    }
    if ((nutritionGoal === 'obese' || (bmi?.category || '').toLowerCase().includes('béo phì')) && item.calories < dailyCalories * 0.20 && item.protein > 20) {
        return RecommendationLevel.GoodForYou;
    }
    if (item.calories < dailyCalories * 0.20 && item.protein > 25 && item.fat < 15) {
        return RecommendationLevel.GoodForYou;
    }

    // --- RULE 3: CONSIDER (YELLOW) ---
    if (item.calories > dailyCalories * 0.35) {
        return RecommendationLevel.Consider;
    }
    if (item.carbs > 80 || item.fat > 30) {
        return RecommendationLevel.Consider;
    }

    // --- RULE 4: SUITABLE (GREEN) --- Default fallback
    return RecommendationLevel.Suitable;
};

const RECOMMENDATION_STYLES: Record<RecommendationLevel, { textKey: string; className: string; icon: React.FC<{className?: string}> }> = {
    [RecommendationLevel.GoodForYou]: { textKey: 'Good', className: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/50 shadow-[0_0_15px_rgba(16,185,129,0.2)]', icon: ThumbsUpIcon },
    [RecommendationLevel.Suitable]: { textKey: 'OK', className: 'bg-cyan-600/20 text-cyan-400 border-cyan-500/50 shadow-[0_0_15px_rgba(6,182,212,0.2)]', icon: CheckCircleIcon },
    [RecommendationLevel.Consider]: { textKey: 'Note', className: 'bg-amber-500/20 text-amber-400 border-amber-400/50 shadow-[0_0_15px_rgba(245,158,11,0.2)]', icon: EyeIcon },
    [RecommendationLevel.Limit]: { textKey: 'Limit', className: 'bg-fuchsia-600/20 text-fuchsia-400 border-fuchsia-500/50 shadow-[0_0_15px_rgba(192,38,211,0.2)]', icon: ExclamationTriangleIcon },
};


interface MenuItemProps {
  item: MenuItemType;
  onSelect: (item: MenuItemType) => void;
  onAddToPlan: (item: MenuItemType) => void;
  analysis: AnalysisResult;
  userData: UserData;
  averageRating: number;
  ratingCount: number;
  language: Language;
}

const MenuItem: React.FC<MenuItemProps> = ({ item, onSelect, onAddToPlan, analysis, userData, averageRating, ratingCount, language }) => {
  const { name, description } = getMenuItemTranslation(item, language);

  const recommendation = useMemo(() => {
      const level = getRecommendationLevel(item, analysis, userData);
      return RECOMMENDATION_STYLES[level];
  }, [item, analysis, userData]);

  const dietaryLabels = useMemo(() => {
      const labs = [];
      const t = TRANSLATIONS[language];
      if (item.carbs <= 30) labs.push({ text: t.low_carb, className: 'text-blue-300 border-blue-500/30 bg-blue-900/20' });
      if (item.protein <= 15) labs.push({ text: t.low_protein, className: 'text-rose-300 border-rose-500/30 bg-rose-900/20' });
      if (item.fat <= 10) labs.push({ text: t.low_fat, className: 'text-amber-300 border-amber-500/30 bg-amber-900/20' });
      return labs;
  }, [item, language]);

  const RecommendationIcon = recommendation.icon;
  
  // 3D Tilt Logic
  const cardRef = useRef<HTMLDivElement>(null);
  const [rotate, setRotate] = useState({ x: 0, y: 0 });

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
      if (!cardRef.current) return;
      const rect = cardRef.current.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      const centerX = rect.width / 2;
      const centerY = rect.height / 2;
      
      // Calculate rotation (max 10 degrees for nice effect)
      const rotateX = ((y - centerY) / centerY) * -10; 
      const rotateY = ((x - centerX) / centerX) * 10;

      setRotate({ x: rotateX, y: rotateY });
  };

  const handleMouseLeave = () => {
      setRotate({ x: 0, y: 0 });
  };

  return (
    <div 
        ref={cardRef}
        onMouseMove={handleMouseMove}
        onMouseLeave={handleMouseLeave}
        className="relative group h-full transition-all duration-300 ease-out z-0 hover:z-20"
        style={{
            transform: `perspective(1000px) rotateX(${rotate.x}deg) rotateY(${rotate.y}deg) scale3d(1, 1, 1)`,
            transition: 'transform 0.1s ease-out'
        }}
    >
      {/* Glow Backdrop */}
      <div className="absolute -inset-0.5 bg-gradient-to-br from-cyan-500/30 to-purple-600/30 rounded-2xl opacity-0 group-hover:opacity-100 blur-lg transition duration-500"></div>

      {/* Main Card Content */}
      <div className="bg-black/60 backdrop-blur-xl rounded-2xl border border-gray-800/60 flex flex-col justify-between h-full overflow-hidden relative shadow-lg group-hover:border-cyan-500/40 transition-colors duration-300">
        
        {/* Holographic Sheen */}
        <div className="absolute inset-0 bg-gradient-to-tr from-white/0 via-white/5 to-white/0 skew-x-12 translate-x-[-150%] group-hover:animate-[shimmer_1.5s_infinite] pointer-events-none z-10"></div>

        <div>
          <div className="relative overflow-hidden aspect-[4/3]">
            <img src={item.image} alt={name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" loading="lazy" />
            
            <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-transparent opacity-80"></div>

             {recommendation && (
                <div aria-label={`Khuyến nghị: ${recommendation.textKey}`} className={`absolute top-2 left-2 text-[10px] font-bold py-1 px-2.5 rounded-full border backdrop-blur-md flex items-center gap-1.5 z-20 ${recommendation.className}`}>
                    <RecommendationIcon className="w-3.5 h-3.5" />
                    <span>{recommendation.textKey === 'Good' ? 'Tốt' : recommendation.textKey === 'OK' ? 'Phù hợp' : recommendation.textKey === 'Note' ? 'Lưu ý' : 'Hạn chế'}</span>
                </div>
            )}
            
            <div className="absolute bottom-2 left-2 flex flex-wrap gap-1 z-20 max-w-[70%]">
                {dietaryLabels.map((label, idx) => (
                    <span key={idx} className={`text-[9px] font-bold px-1.5 py-0.5 rounded border backdrop-blur-sm ${label.className}`}>
                        {label.text}
                    </span>
                ))}
            </div>

            <div className="absolute bottom-2 right-2 z-20">
                 <span className="text-cyan-300 font-bold text-sm bg-black/50 backdrop-blur-md border border-cyan-500/30 px-2 py-1 rounded-lg shadow-lg">
                    {item.price.toLocaleString()}đ
                 </span>
            </div>
          </div>
          
          <div className="p-4 relative">
            <h4 className="text-base font-bold text-white truncate mb-1.5 group-hover:text-cyan-300 transition-colors tracking-tight" title={name}>{name}</h4>
            
            <div className="flex items-center gap-1 mb-2 h-4">
                {ratingCount > 0 ? (
                    <>
                        <StarIcon className="w-3.5 h-3.5 text-yellow-400 fill-yellow-400" />
                        <span className="text-xs font-bold text-gray-300">{averageRating.toFixed(1)} <span className="text-gray-600">({ratingCount})</span></span>
                    </>
                ) : <span className="text-xs text-gray-600 italic">Chưa có đánh giá</span>}
            </div>

            <p className="text-[11px] text-gray-400 mb-3 h-8 overflow-hidden leading-relaxed line-clamp-2">{description}</p>
            
            <div className="flex justify-between items-center text-center text-[10px] bg-gray-900/50 rounded-lg p-2 border border-gray-800">
              <div>
                <p className="font-bold text-cyan-300 text-xs">{item.calories}</p>
                <p className="text-gray-500 uppercase tracking-wider text-[9px]">kcal</p>
              </div>
              <div className="h-6 w-px bg-gray-700"></div>
              <div>
                <p className="font-bold text-blue-300 text-xs">{item.carbs}g</p>
                <p className="text-gray-500 uppercase tracking-wider text-[9px]">Carb</p>
              </div>
              <div className="h-6 w-px bg-gray-700"></div>
              <div>
                <p className="font-bold text-rose-300 text-xs">{item.protein}g</p>
                <p className="text-gray-500 uppercase tracking-wider text-[9px]">Pro</p>
              </div>
              <div className="h-6 w-px bg-gray-700"></div>
              <div>
                <p className="font-bold text-amber-300 text-xs">{item.fat}g</p>
                <p className="text-gray-500 uppercase tracking-wider text-[9px]">Fat</p>
              </div>
            </div>
          </div>
        </div>
        
        <div className="p-4 pt-0 mt-auto flex gap-2">
            <button 
              onClick={() => onSelect(item)} 
              aria-label={`Thêm ${name} vào đơn hàng`} 
              className="flex-grow flex items-center justify-center gap-2 bg-white text-black px-3 py-2.5 text-xs rounded-xl hover:bg-cyan-300 transition-all font-bold shadow-lg active:scale-95 group/btn relative overflow-hidden"
            >
                <span className="relative z-10 flex items-center gap-1 uppercase tracking-wide">
                    {TRANSLATIONS[language].add} <PlusIcon className="w-3.5 h-3.5" />
                </span>
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/50 to-transparent translate-x-[-150%] group-hover/btn:animate-[shimmer_1s_infinite]"></div>
            </button>
            
            <button 
              onClick={() => onAddToPlan(item)} 
              aria-label={`Thêm ${name} vào kế hoạch tuần`} 
              className="flex-shrink-0 bg-gray-800 border border-gray-700 text-gray-300 p-2.5 rounded-xl hover:bg-cyan-900/30 hover:border-cyan-500/50 hover:text-cyan-300 transition-all active:scale-95" 
              title="Lên lịch"
            >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
            </button>
        </div>
      </div>
    </div>
  );
}

const PackageCard: React.FC<{ pkg: MenuPackage; onAdd: (pkg: MenuPackage) => void; menuItems: Record<string, MenuItemType[]>, language: Language }> = ({ pkg, onAdd, menuItems, language }) => {
    // FIX: Explicitly cast Object.values result to resolve 'unknown' type error in reduce
    const allMenuItems = useMemo(() => (Object.values(menuItems) as MenuItemType[][]).reduce<MenuItemType[]>((acc, val) => acc.concat(val), []), [menuItems]);
    const includedItems = useMemo(() => pkg.itemIds.map(id => allMenuItems.find(item => item.id === id)).filter((i): i is MenuItemType => !!i), [pkg.itemIds, allMenuItems]);
    
    const { name, description } = getPackageTranslation(pkg, language);

    return (
        <div className="bg-gray-900/40 backdrop-blur-md rounded-2xl border border-purple-500/30 flex flex-col justify-between h-full overflow-hidden transition-all duration-300 ease-in-out hover:-translate-y-1 hover:shadow-[0_0_25px_rgba(168,85,247,0.2)] group relative hover:border-purple-500/60">
            {/* Glow Effect */}
            <div className="absolute inset-0 bg-purple-600/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"></div>
            
            <div>
                <div className="relative overflow-hidden h-40">
                    <img src={pkg.image} alt={name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" loading="lazy" />
                    <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-transparent to-transparent opacity-90"></div>
                    
                    <div className="absolute top-2 left-2 text-white text-[10px] font-bold py-1 px-2.5 rounded-full border backdrop-blur-md bg-purple-600/80 border-purple-400/50 flex items-center gap-1 shadow-lg shadow-purple-900/50 z-20">
                        <BoxIcon className="w-3 h-3" />
                        <span>{pkg.category}</span>
                    </div>
                </div>
                <div className="p-4 relative">
                    <h4 className="text-base font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-300 via-white to-indigo-300 truncate mb-1.5" title={name}>{name}</h4>
                    <p className="text-[11px] text-gray-400 mb-3 h-8 overflow-hidden line-clamp-2 leading-relaxed">{description}</p>
                    
                    <div className="text-center text-[10px] my-2 border border-purple-500/20 bg-purple-900/10 rounded-xl py-2">
                        <p className="font-bold text-purple-300 mb-1 text-xs">{pkg.totalNutrition.calories.toLocaleString()} kcal</p>
                        <div className="flex justify-around px-2 text-[9px] opacity-80">
                            <p><span className="text-blue-300 font-bold">{pkg.totalNutrition.carbs}g</span> C</p>
                            <p><span className="text-rose-300 font-bold">{pkg.totalNutrition.protein}g</span> P</p>
                            <p><span className="text-amber-300 font-bold">{pkg.totalNutrition.fat}g</span> F</p>
                        </div>
                    </div>
                </div>
            </div>
            <div className="p-4 pt-0 mt-auto">
                <div className="flex justify-between items-end mb-3">
                    <span className="text-gray-500 line-through text-xs font-mono">{pkg.originalPrice.toLocaleString()}đ</span>
                    <span className="text-lg font-bold text-purple-300">{pkg.price.toLocaleString()}đ</span>
                </div>
                <button 
                    onClick={() => onAdd(pkg)} 
                    aria-label={`Xem chi tiết ${name}`} 
                    className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 text-white px-3 py-3 text-xs rounded-xl hover:from-purple-500 hover:to-indigo-500 transition-all font-bold shadow-lg shadow-purple-900/40 hover:shadow-purple-500/30 active:scale-95 flex items-center justify-center gap-2 uppercase tracking-wide group/btn"
                >
                    <BoxIcon className="w-3.5 h-3.5 group-hover/btn:animate-bounce" />
                    {TRANSLATIONS[language].details}
                </button>
            </div>
        </div>
    );
};


interface MenuProps {
  onAddItem: (item: OrderItemType) => void;
  analysis: AnalysisResult;
  userData: UserData;
  menuItems: Record<string, MenuItemType[]>;
  language: Language;
  onHologramToggle?: (isActive: boolean) => void;
}

export const Menu: React.FC<MenuProps> = ({ onAddItem, analysis, userData, menuItems, language, onHologramToggle }) => {
  const [activeCategory, setActiveCategory] = useState<string>(MENU_CATEGORIES.COFFEE);
  const [activeSubCategory, setActiveSubCategory] = useState<string | null>(MENU_SUBCATEGORIES[MENU_CATEGORIES.COFFEE][0]);
  
  const [customizingItem, setCustomizingItem] = useState<MenuItemType | null>(null);
  const [communityRatings, setCommunityRatings] = useState<CommunityRatingMap>({});
  
  const [planningFlowState, setPlanningFlowState] = useState<{
    step: 'idle' | 'customizing' | 'selecting_slot';
    item: MenuItemType | null;
    orderItem?: OrderItemType;
  }>({ step: 'idle', item: null });
  
  const [activePackageCategory, setActivePackageCategory] = useState<MenuPackageCategory | 'Tất cả'>('Tất cả');
  const [hologramPackage, setHologramPackage] = useState<MenuPackage | null>(null);

  useEffect(() => {
    try {
        const storedRatings = localStorage.getItem('communityRatings');
        if (storedRatings) {
            setCommunityRatings(JSON.parse(storedRatings));
        } else {
            setCommunityRatings(MOCK_COMMUNITY_RATINGS);
            localStorage.setItem('communityRatings', JSON.stringify(MOCK_COMMUNITY_RATINGS));
        }
    } catch (e) {
        console.error("Failed to load community ratings:", e);
        setCommunityRatings(MOCK_COMMUNITY_RATINGS);
    }
  }, []);

  useEffect(() => {
      // When main category changes, reset subcategory to the first one available
      if (activeCategory !== MENU_CATEGORIES.COMBO) {
          const subs = MENU_SUBCATEGORIES[activeCategory];
          if (subs && subs.length > 0) {
              setActiveSubCategory(subs[0]);
          } else {
              setActiveSubCategory(null);
          }
      }
  }, [activeCategory]);

  const displayedItems = useMemo(() => {
      if (activeCategory === MENU_CATEGORIES.COMBO) return [];

      // Flatten all items to search across the entire menu
      // FIX: Explicitly cast Object.values result to resolve 'unknown' type error in reduce
      const allItems = (Object.values(menuItems) as MenuItemType[][]).reduce<MenuItemType[]>((acc, val) => acc.concat(val), []);
      
      // Filter by Category and Subcategory
      const uniqueItemsMap = new Map();
      
      allItems.forEach(item => {
          if (item.category === activeCategory) {
              if (activeSubCategory && item.subcategory !== activeSubCategory) return;
              
              if (!uniqueItemsMap.has(item.id)) {
                  uniqueItemsMap.set(item.id, item);
              }
          }
      });

      return Array.from(uniqueItemsMap.values()) as MenuItemType[];
  }, [activeCategory, activeSubCategory, menuItems]);
  
  const displayedPackages = useMemo(() => {
    if (activePackageCategory === 'Tất cả') return MENU_PACKAGES;
    return MENU_PACKAGES.filter(pkg => pkg.category === activePackageCategory);
  }, [activePackageCategory]);

  const handleSelectItem = (item: MenuItemType) => {
    if (item.customizations && item.customizations.length > 0) {
      setCustomizingItem(item);
    } else {
      const defaultOrderItem: OrderItemType = {
        id: `${item.id}-${Date.now()}`,
        menuItem: item,
        quantity: 1,
        selectedOptions: [],
        totalPrice: item.price,
        totalNutrition: {
          calories: item.calories,
          carbs: item.carbs,
          protein: item.protein,
          fat: item.fat,
        }
      };
      onAddItem(defaultOrderItem);
    }
  };

  const handleConfirmAddItem = (orderItem: OrderItemType) => {
    onAddItem(orderItem);
    setCustomizingItem(null);
  };
  
  const handleShowHologram = (pkg: MenuPackage) => {
    setHologramPackage(pkg);
    onHologramToggle?.(true);
  };

  const handleConfirmHologram = (pkg: MenuPackage) => {
    // FIX: Explicitly cast Object.values result to resolve 'unknown' type error in reduce
    const allMenuItems = (Object.values(menuItems) as MenuItemType[][]).reduce<MenuItemType[]>((acc, val) => acc.concat(val), []);
    const menuMap = new Map(allMenuItems.map(i => [i.id, i]));

    pkg.itemIds.forEach(itemId => {
        const menuItem = menuMap.get(itemId);
        if (menuItem) {
            const orderItem: OrderItemType = {
                id: `${menuItem.id}-${pkg.id}-${Date.now()}`,
                menuItem: menuItem,
                quantity: 1,
                selectedOptions: [],
                totalPrice: menuItem.price,
                totalNutrition: {
                    calories: menuItem.calories,
                    carbs: menuItem.carbs,
                    protein: menuItem.protein,
                    fat: menuItem.fat
                }
            };
            onAddItem(orderItem);
        }
    });
    setHologramPackage(null);
    onHologramToggle?.(false);
  };

  const handleCloseHologram = () => {
      setHologramPackage(null);
      onHologramToggle?.(false);
  }

  const handleAddToPlan = (item: MenuItemType) => {
    if (item.customizations && item.customizations.length > 0) {
        setPlanningFlowState({ step: 'customizing', item: item });
    } else {
        const defaultOrderItem: OrderItemType = {
            id: `${item.id}-${Date.now()}`,
            menuItem: item,
            quantity: 1,
            selectedOptions: [],
            totalPrice: item.price,
            totalNutrition: { calories: item.calories, carbs: item.carbs, protein: item.protein, fat: item.fat }
        };
        setPlanningFlowState({ step: 'selecting_slot', item: item, orderItem: defaultOrderItem });
    }
  };

  const handleCustomizationForPlanComplete = (orderItem: OrderItemType) => {
      setPlanningFlowState(prev => ({
          ...prev,
          step: 'selecting_slot',
          orderItem: orderItem,
      }));
  };

  const handleClosePlanModals = () => {
      setPlanningFlowState({ step: 'idle', item: null, orderItem: undefined });
  };

  const isPackageView = activeCategory === MENU_CATEGORIES.COMBO;

  return (
    <div className="animate-fade-in relative">
      {/* Categories Bar - Floating Glass Dock */}
      <div className="sticky top-2 z-40 mb-6 mx-auto max-w-4xl">
          <div className="bg-black/60 backdrop-blur-xl rounded-full p-2 border border-gray-700/50 shadow-2xl flex flex-col gap-2">
                {/* Category Tabs */}
                <div className="flex flex-wrap justify-center gap-1.5 overflow-x-auto no-scrollbar py-1">
                    {Object.values(MENU_CATEGORIES).map(cat => (
                    <button
                        key={cat}
                        onClick={() => setActiveCategory(cat)}
                        className={`px-5 py-2 rounded-full whitespace-nowrap transition-all font-bold text-xs uppercase tracking-wider relative overflow-hidden group ${
                        activeCategory === cat 
                            ? 'text-white shadow-[0_0_15px_rgba(6,182,212,0.5)]' 
                            : 'text-gray-400 hover:text-white hover:bg-white/10'
                        }`}
                    >
                        <span className="relative z-10">{CATEGORY_TRANSLATIONS[cat][language] || cat}</span>
                        {activeCategory === cat && (
                            <div className="absolute inset-0 bg-gradient-to-r from-cyan-600 to-blue-600 rounded-full"></div>
                        )}
                    </button>
                    ))}
                </div>

                {/* Subcategory Tabs (if applicable) - Mini Dock */}
                {(!isPackageView && MENU_SUBCATEGORIES[activeCategory]?.length > 0) || isPackageView ? (
                    <div className="flex flex-wrap justify-center gap-2 items-center pb-1 border-t border-gray-800/50 pt-2 mx-4">
                        {!isPackageView ? MENU_SUBCATEGORIES[activeCategory].map(sub => (
                            <button
                                key={sub}
                                onClick={() => setActiveSubCategory(sub)}
                                className={`px-3 py-1 rounded-lg text-[10px] font-semibold transition-all border ${
                                    activeSubCategory === sub
                                        ? 'bg-cyan-900/40 text-cyan-300 border-cyan-500/50 shadow-sm'
                                        : 'text-gray-500 border-transparent hover:text-gray-300 hover:bg-gray-800/50'
                                }`}
                            >
                                {CATEGORY_TRANSLATIONS[sub] ? CATEGORY_TRANSLATIONS[sub][language] : sub}
                            </button>
                        )) : (
                            <>
                                <button onClick={() => setActivePackageCategory('Tất cả')} className={`px-3 py-1 text-[10px] font-semibold rounded-lg transition-all border ${activePackageCategory === 'Tất cả' ? 'bg-purple-900/40 border-purple-500/50 text-purple-300' : 'bg-transparent border-transparent text-gray-500 hover:text-purple-300'}`}>{TRANSLATIONS[language].all}</button>
                                {Object.keys(MENU_PACKAGE_CATEGORIES).map(cat => (
                                    <button key={cat} onClick={() => setActivePackageCategory(cat as MenuPackageCategory)} className={`px-3 py-1 text-[10px] font-semibold rounded-lg transition-all border ${activePackageCategory === cat ? 'bg-purple-900/40 border-purple-500/50 text-purple-300' : 'bg-transparent border-transparent text-gray-500 hover:text-purple-300'}`}>{cat}</button>
                                ))}
                            </>
                        )}
                    </div>
                ) : null}
          </div>
      </div>

      {/* Grid Content - Modern Grid with optimized spacing */}
      {isPackageView ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 p-2">
              {displayedPackages.map(pkg => (
                  <PackageCard key={pkg.id} pkg={pkg} onAdd={handleShowHologram} menuItems={menuItems} language={language} />
              ))}
          </div>
      ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 p-2">
            {displayedItems.map((item) => (
              <div key={item.id} className="h-[340px]">
                <MenuItem 
                    item={item} 
                    onSelect={handleSelectItem} 
                    onAddToPlan={handleAddToPlan}
                    analysis={analysis}
                    userData={userData}
                    averageRating={communityRatings[item.id]?.totalRating / communityRatings[item.id]?.count || 0}
                    ratingCount={communityRatings[item.id]?.count || 0}
                    language={language}
                />
              </div>
            ))}
          </div>
      )}

      {customizingItem && (
        <CustomizationModal 
          item={customizingItem} 
          onClose={() => setCustomizingItem(null)} 
          onConfirm={handleConfirmAddItem} 
          language={language}
        />
      )}

      {/* Planning Flow Modals */}
      {planningFlowState.item && planningFlowState.step === 'customizing' && (
          <CustomizationModal
              item={planningFlowState.item}
              onClose={handleClosePlanModals}
              onConfirm={handleCustomizationForPlanComplete}
              language={language}
          />
      )}
      
      {planningFlowState.orderItem && planningFlowState.step === 'selecting_slot' && (
          <AddToPlanModal
              orderItem={planningFlowState.orderItem}
              onClose={handleClosePlanModals}
          />
      )}
      
      {hologramPackage && (
          <PackageHologramModal 
            pkg={hologramPackage} 
            onClose={handleCloseHologram} 
            onConfirm={handleConfirmHologram}
            menuItems={menuItems}
            language={language}
          />
      )}
    </div>
  );
};
