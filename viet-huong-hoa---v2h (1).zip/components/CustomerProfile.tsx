
import React, { useState, useMemo } from 'react';
import { UserData, PastOrderType, MenuItemType, Language, LabValues } from '../types';
import { NUTRITION_GOAL_TRANSLATIONS, TRANSLATIONS } from '../constants';
import { ChartIcon, AlertIcon, WeightIcon, HeightIcon, UserIcon, CalendarIcon } from './Icons';

interface CustomerProfileProps {
    userData: UserData;
    orderHistory: PastOrderType[];
    onBack: () => void;
    language: Language;
}

interface HealthMetricHistory {
    dateLabel: string; 
    fullDate: Date; 
    value: number; 
    relatedIntake: number; 
}

interface Snapshot {
    date: string;
    labValues: LabValues;
}

const parseLab = (val: string | undefined | null) => {
    if (!val) return 0;
    const parsed = parseFloat(val);
    return isNaN(parsed) ? 0 : parsed;
};

const generateHealthData = (
    currentLabValue: number, 
    type: 'glucose' | 'hba1c' | 'uricAcid' | 'cholesterol' | 'triglyceride' | 'protein' | 'albumin' | 'ure' | 'creatinine', 
    orderHistory: PastOrderType[], 
    snapshots: Snapshot[],
    monthsBack: number = 5
): HealthMetricHistory[] => {
    const history: HealthMetricHistory[] = [];
    const today = new Date();
    
    for (let i = monthsBack; i >= 0; i--) {
        const targetDate = new Date(today.getFullYear(), today.getMonth() - i, 1);
        const monthLabel = `T${targetDate.getMonth() + 1}`;
        
        let realIntake = 0;
        orderHistory.forEach(order => {
            const orderDate = new Date(order.date);
            if (orderDate.getMonth() === targetDate.getMonth() && orderDate.getFullYear() === targetDate.getFullYear()) {
                order.items.forEach(item => {
                    const nutrition = item.totalNutrition; 
                    if (type === 'glucose' || type === 'hba1c') realIntake += nutrition.carbs;
                    else if (type === 'cholesterol' || type === 'triglyceride') realIntake += nutrition.fat;
                    else realIntake += nutrition.protein;
                });
            }
        });

        // Try to find a real snapshot for this month
        const foundSnapshot = snapshots.find(s => {
            const d = new Date(s.date);
            return d.getMonth() === targetDate.getMonth() && d.getFullYear() === targetDate.getFullYear();
        });

        let metricVal: number;

        if (foundSnapshot) {
            // Use real historical data
            metricVal = parseLab(foundSnapshot.labValues[type]);
        } else if (i === 0) {
            // Current month always uses current value passed in
            metricVal = currentLabValue;
        } else {
            // Simulation for missing data (older months)
             const variance = (Math.random() - 0.5) * (currentLabValue * 0.15); 
             metricVal = currentLabValue + variance; 
        }

        let displayIntake = realIntake;
        // Only simulate intake if there's absolutely no data and it's a generated metric point
        if (realIntake === 0 && !foundSnapshot && i > 0) {
             if (type === 'glucose' || type === 'hba1c') {
                 displayIntake = metricVal > (type === 'hba1c' ? 6.5 : 100) ? 250 + Math.random() * 100 : 150 + Math.random() * 50;
             } else if (type === 'cholesterol' || type === 'triglyceride') {
                 displayIntake = metricVal > 200 ? 70 + Math.random() * 40 : 30 + Math.random() * 20;
             } else {
                 displayIntake = metricVal > 7 ? 80 + Math.random() * 40 : 40 + Math.random() * 30;
             }
             displayIntake = Math.floor(displayIntake * (3 + Math.random() * 3)); 
        }

        history.push({
            dateLabel: monthLabel,
            fullDate: targetDate,
            value: Math.max(0, parseFloat(metricVal.toFixed(type === 'hba1c' ? 2 : 1))), 
            relatedIntake: Math.floor(displayIntake)
        });
    }
    return history;
};

const MetricCard: React.FC<{ 
    label: string; 
    value: string | number; 
    unit: string; 
    status: 'normal' | 'warning' | 'danger'; 
    onClick: () => void; 
    isActive: boolean;
    activeColor: string;
}> = ({ label, value, unit, status, onClick, isActive, activeColor }) => {
    const baseClasses = "p-4 rounded-xl border cursor-pointer transition-all duration-300 flex flex-col justify-between relative overflow-hidden group";
    
    const statusColors = {
        normal: 'bg-gray-800/60 border-gray-700 text-white',
        warning: 'bg-amber-900/20 border-amber-500/50 text-amber-100',
        danger: 'bg-fuchsia-900/20 border-fuchsia-500/50 text-fuchsia-100'
    };

    return (
        <div 
            onClick={onClick}
            className={`${baseClasses} ${statusColors[status]} ${isActive ? `ring-2 shadow-lg` : 'hover:border-gray-500'}`}
            style={{ 
                borderColor: isActive ? activeColor : undefined,
                boxShadow: isActive ? `0 0 15px ${activeColor}40` : undefined
            }}
        >
            <div className="relative z-10">
                <p className="text-xs font-medium opacity-80 uppercase tracking-wider">{label}</p>
                <p className="text-2xl font-bold mt-2">{value} <span className="text-xs font-normal opacity-70">{unit}</span></p>
            </div>
            {isActive && (
                <div 
                    className="absolute -right-4 -bottom-4 w-20 h-20 rounded-full opacity-20 blur-xl"
                    style={{ backgroundColor: activeColor }}
                ></div>
            )}
        </div>
    );
};

const TrendChart: React.FC<{ 
    data: HealthMetricHistory[], 
    label: string, 
    intakeLabel: string, 
    safeRange: { min: number, max: number },
    selectedIndex: number,
    onPointClick: (index: number) => void,
    color: string,
    safeZoneLabel: string
}> = ({ data, label, intakeLabel, safeRange, selectedIndex, onPointClick, color, safeZoneLabel }) => {
    const width = 600;
    const height = 280;
    const padding = { top: 20, right: 40, bottom: 40, left: 50 };

    const maxMetric = Math.max(...data.map(d => d.value), safeRange.max * 1.2);
    const minMetric = Math.min(...data.map(d => d.value), safeRange.min * 0.8);
    
    const maxIntake = Math.max(...data.map(d => d.relatedIntake), 100);

    const xScale = (index: number) => padding.left + (index / (data.length - 1)) * (width - padding.left - padding.right);
    const yScaleMetric = (val: number) => height - padding.bottom - ((val - minMetric) / (maxMetric - minMetric)) * (height - padding.top - padding.bottom);
    const yScaleIntake = (val: number) => height - padding.bottom - (val / maxIntake) * (height - padding.top - padding.bottom) * 0.8; 

    const linePath = data.map((d, i) => `${xScale(i)},${yScaleMetric(d.value)}`).join(' L ');
    
    const safeYMax = yScaleMetric(safeRange.min);
    const safeYMin = yScaleMetric(safeRange.max);

    return (
        <div className="w-full overflow-x-auto select-none no-scrollbar">
            <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-auto min-w-[600px]">
                <defs>
                    <linearGradient id="barGradient" x1="0" x2="0" y1="0" y2="1">
                        <stop offset="0%" stopColor={color} stopOpacity="0.6" />
                        <stop offset="100%" stopColor={color} stopOpacity="0.1" />
                    </linearGradient>
                    <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
                        <feGaussianBlur stdDeviation="2" result="blur" />
                        <feComposite in="SourceGraphic" in2="blur" operator="over" />
                    </filter>
                </defs>

                <line x1={padding.left} y1={height - padding.bottom} x2={width - padding.right} y2={height - padding.bottom} stroke="#374151" strokeWidth="1" />
                <line x1={padding.left} y1={padding.top} x2={padding.left} y2={height - padding.bottom} stroke="#374151" strokeWidth="1" />
                <line x1={width - padding.right} y1={padding.top} x2={width - padding.right} y2={height - padding.bottom} stroke="#374151" strokeWidth="1" strokeDasharray="4 4"/>

                <rect 
                    x={padding.left} 
                    y={safeYMin} 
                    width={width - padding.left - padding.right} 
                    height={Math.abs(safeYMax - safeYMin)} 
                    fill="rgba(16, 185, 129, 0.05)" 
                />
                <text x={padding.left + 10} y={safeYMin + 15} fill="#10b981" fontSize="10" opacity="0.7">{safeZoneLabel}</text>

                {data.map((d, i) => {
                    const barHeight = height - padding.bottom - yScaleIntake(d.relatedIntake);
                    return (
                        <g key={`bar-${i}`} onClick={() => onPointClick(i)} className="cursor-pointer group">
                            <rect 
                                x={xScale(i) - 12} 
                                y={yScaleIntake(d.relatedIntake)} 
                                width={24} 
                                height={barHeight} 
                                fill="url(#barGradient)"
                                rx="2"
                                opacity={i === selectedIndex ? "1" : "0.5"}
                                className="transition-all duration-300 group-hover:opacity-80"
                            />
                            <text 
                                x={xScale(i)} 
                                y={yScaleIntake(d.relatedIntake) - 6} 
                                fill={color} 
                                fontSize="10" 
                                textAnchor="middle" 
                                fontWeight={i === selectedIndex ? "bold" : "normal"}
                            >
                                {d.relatedIntake}g
                            </text>
                        </g>
                    );
                })}

                <path d={`M ${linePath}`} fill="none" stroke={color} strokeWidth="3" strokeLinecap="round" filter="url(#glow)" />
                
                {data.map((d, i) => (
                    <g key={i} onClick={() => onPointClick(i)} className="cursor-pointer group">
                        <circle cx={xScale(i)} cy={yScaleMetric(d.value)} r="20" fill="transparent" />
                        <circle 
                            cx={xScale(i)} 
                            cy={yScaleMetric(d.value)} 
                            r={i === selectedIndex ? "7" : "5"} 
                            fill="#1f2937" 
                            stroke={color} 
                            strokeWidth={i === selectedIndex ? "3" : "2"} 
                            className="transition-all duration-300"
                        />
                        <circle 
                            cx={xScale(i)} 
                            cy={yScaleMetric(d.value)} 
                            r={i === selectedIndex ? "3" : "0"} 
                            fill={color}
                            className="transition-all duration-300"
                        />
                        <text 
                            x={xScale(i)} 
                            y={yScaleMetric(d.value) - 15} 
                            fill="white" 
                            fontSize="12" 
                            textAnchor="middle" 
                            fontWeight="bold"
                            className={i === selectedIndex ? "opacity-100" : "opacity-0 group-hover:opacity-100 transition-opacity"}
                        >
                            {d.value}
                        </text>
                        <text 
                            x={xScale(i)} 
                            y={height - 10} 
                            fill={i === selectedIndex ? "white" : "#9ca3af"} 
                            fontSize={i === selectedIndex ? "12" : "11"} 
                            fontWeight={i === selectedIndex ? "bold" : "normal"}
                            textAnchor="middle"
                        >
                            {d.dateLabel}
                        </text>
                    </g>
                ))}

                <text x={padding.left - 10} y={padding.top} fill="white" fontSize="11" fontWeight="bold" textAnchor="end" transform={`rotate(-90 ${padding.left - 10} ${padding.top})`}>{label}</text>
                <text x={width - padding.right + 15} y={padding.top} fill={color} fontSize="11" fontWeight="bold" textAnchor="start" transform={`rotate(-90 ${width - padding.right + 15} ${padding.top})`}>{intakeLabel}</text>
            </svg>
        </div>
    );
};

const DishHistoryItem: React.FC<{ item: MenuItemType, count: number, highlight: 'carbs' | 'protein' | 'fat' | 'none', color: string, t: any }> = ({ item, count, highlight, color, t }) => {
    return (
        <div className="flex items-center gap-3 bg-gray-800/40 p-3 rounded-xl border border-gray-700/50 hover:bg-gray-800/60 transition-colors group">
            <div className="relative">
                <img src={item.image} alt={item.name} className="w-14 h-14 rounded-lg object-cover" />
                <span className="absolute -top-2 -right-2 bg-gray-700 text-white text-xs font-bold px-1.5 py-0.5 rounded-full border border-gray-600">x{count}</span>
            </div>
            <div className="flex-grow min-w-0">
                <div className="flex justify-between items-start">
                    <p className="font-medium text-white text-sm truncate pr-2">{item.name}</p>
                    <p className="text-cyan-400 text-xs font-bold">{item.price.toLocaleString()}đ</p>
                </div>
                <div className="flex gap-3 text-xs mt-1.5 text-gray-400 bg-gray-900/30 p-1.5 rounded-md w-fit">
                    <span className={highlight === 'carbs' ? 'font-bold' : ''} style={{ color: highlight === 'carbs' ? color : undefined }}>{item.carbs}g {t.carbs}</span>
                    <div className="w-px bg-gray-700"></div>
                    <span className={highlight === 'protein' ? 'font-bold' : ''} style={{ color: highlight === 'protein' ? color : undefined }}>{item.protein}g {t.protein}</span>
                    <div className="w-px bg-gray-700"></div>
                    <span className={highlight === 'fat' ? 'font-bold' : ''} style={{ color: highlight === 'fat' ? color : undefined }}>{item.fat}g {t.fat}</span>
                </div>
            </div>
        </div>
    );
};

export const CustomerProfile: React.FC<CustomerProfileProps> = ({ userData, orderHistory, onBack, language }) => {
    const [activeMetric, setActiveMetric] = useState<'glucose' | 'hba1c' | 'uricAcid' | 'cholesterol' | 'triglyceride' | 'protein' | 'albumin' | 'ure' | 'creatinine'>('glucose');
    const [selectedPointIndex, setSelectedPointIndex] = useState<number>(5); 
    const t = TRANSLATIONS[language];

    // Load persisted snapshots
    const snapshots: Snapshot[] = useMemo(() => {
        try {
            const allSnapshots = JSON.parse(localStorage.getItem('healthSnapshots') || '{}');
            return allSnapshots[userData.phone] || [];
        } catch(e) { return []; }
    }, [userData.phone]);

    const lab = userData.labValues;
    const glucose = parseLab(lab.glucose);
    const hba1c = parseLab(lab.hba1c);
    const uricAcid = parseLab(lab.uricAcid);
    const cholesterol = parseLab(lab.cholesterol);
    const triglyceride = parseLab(lab.triglyceride);
    const protein = parseLab(lab.protein);
    const albumin = parseLab(lab.albumin);
    const ure = parseLab(lab.ure);
    const creatinine = parseLab(lab.creatinine);

    const getStatus = (val: number, high: number, veryHigh: number): 'normal' | 'warning' | 'danger' => {
        if (!val) return 'normal';
        if (val >= veryHigh) return 'danger';
        if (val >= high) return 'warning';
        return 'normal';
    };
    
    const getLowStatus = (val: number, low: number, veryLow: number): 'normal' | 'warning' | 'danger' => {
        if (!val) return 'normal';
        if (val <= veryLow) return 'danger';
        if (val <= low) return 'warning';
        return 'normal';
    };

    const chartData = useMemo(() => {
        let currentVal = 0;
        switch(activeMetric) {
            case 'glucose': currentVal = glucose || 90; break;
            case 'hba1c': currentVal = hba1c || 5.0; break;
            case 'uricAcid': currentVal = uricAcid || 5; break;
            case 'cholesterol': currentVal = cholesterol || 150; break;
            case 'triglyceride': currentVal = triglyceride || 100; break;
            case 'protein': currentVal = protein || 7; break;
            case 'albumin': currentVal = albumin || 4; break;
            case 'ure': currentVal = ure || 30; break;
            case 'creatinine': currentVal = creatinine || 0.9; break;
        }

        return generateHealthData(
            currentVal,
            activeMetric, 
            orderHistory,
            snapshots
        );
    }, [activeMetric, glucose, hba1c, uricAcid, cholesterol, triglyceride, protein, albumin, ure, creatinine, orderHistory, snapshots]);

    const selectedMonthDishes = useMemo(() => {
        if (!chartData[selectedPointIndex]) return [];
        
        const targetDate = chartData[selectedPointIndex].fullDate;
        const targetMonth = targetDate.getMonth();
        const targetYear = targetDate.getFullYear();

        const dishesMap = new Map<string, { item: MenuItemType, count: number }>();

        orderHistory.forEach(order => {
            const orderDate = new Date(order.date);
            if (orderDate.getMonth() === targetMonth && orderDate.getFullYear() === targetYear) {
                order.items.forEach(orderItem => {
                    const existing = dishesMap.get(orderItem.menuItem.id);
                    if (existing) {
                        existing.count += orderItem.quantity;
                    } else {
                        dishesMap.set(orderItem.menuItem.id, { item: orderItem.menuItem, count: orderItem.quantity });
                    }
                });
            }
        });

        return Array.from(dishesMap.values()).sort((a, b) => b.count - a.count);
    }, [selectedPointIndex, chartData, orderHistory]);

    // Internal translation logic for advice
    const getAdvice = (type: string, value: number, min: number, max: number) => {
        const t_status = {
            high: language === 'vi' ? 'Cao' : language === 'en' ? 'High' : 'High',
            low: language === 'vi' ? 'Thấp' : language === 'en' ? 'Low' : 'Low',
            normal: language === 'vi' ? 'Bình thường' : language === 'en' ? 'Normal' : 'Normal',
        };
        
        const t_advice = {
            high: language === 'vi' ? 'Cần điều chỉnh chế độ ăn giảm các chất liên quan.' : 'Need to reduce intake of related nutrients.',
            low: language === 'vi' ? 'Cần bổ sung dinh dưỡng hợp lý.' : 'Need appropriate nutritional supplementation.',
            normal: language === 'vi' ? 'Tuyệt vời! Hãy duy trì thói quen ăn uống này.' : 'Great! Maintain this eating habit.',
            no_data: language === 'vi' ? 'Chưa có dữ liệu.' : 'No data.'
        }

        if (!value) return t_advice.no_data;

        let status = t_status.normal;
        let adviceText = t_advice.normal;

        if (value > max) {
            status = t_status.high;
            adviceText = t_advice.high;
        } else if (value < min) {
            status = t_status.low;
            adviceText = t_advice.low;
        }

        return `${type}: ${status}. ${adviceText}`;
    };

    const config = useMemo(() => {
        const intake = t.intake; 
        
        // Helper to construct return object to avoid repetition
        const makeConfig = (label: string, value: number, min: number, max: number, nutrientLabel: string, highlight: any, color: string) => ({
            label,
            intakeLabel: `${intake} ${nutrientLabel}`,
            safeRange: { min, max },
            advice: getAdvice(label.split(' (')[0], value, min, max),
            highlight,
            color
        });

        switch (activeMetric) {
            case 'glucose': return makeConfig('Glucose (mg/dL)', glucose, 70, 100, 'Carb', 'carbs', '#38bdf8');
            case 'hba1c': return makeConfig('HbA1c (%)', hba1c, 4.0, 5.7, 'Carb', 'carbs', '#a78bfa');
            case 'uricAcid': return makeConfig('Acid Uric (mg/dL)', uricAcid, 2.4, 6.0, 'Protein', 'protein', '#f472b6'); 
            case 'cholesterol': return makeConfig('Cholesterol (mg/dL)', cholesterol, 0, 200, 'Fat', 'fat', '#fbbf24');
            case 'triglyceride': return makeConfig('Triglyceride (mg/dL)', triglyceride, 0, 150, 'Fat', 'fat', '#fb7185');
            case 'protein': return makeConfig('Protein TP (g/dL)', protein, 6.0, 8.3, 'Protein', 'protein', '#818cf8');
            case 'albumin': return makeConfig('Albumin (g/dL)', albumin, 3.4, 5.4, 'Protein', 'protein', '#2dd4bf');
            case 'ure': return makeConfig('Ure (mg/dL)', ure, 7, 20, 'Protein', 'protein', '#fb923c');
            case 'creatinine': return makeConfig('Creatinine (mg/dL)', creatinine, 0.6, 1.2, 'Protein', 'protein', '#f87171');
            default:
                return { 
                    label: 'Metric', intakeLabel: 'Intake', safeRange: { min: 0, max: 100 }, advice: '', highlight: 'none' as const, color: '#ffffff' 
                };
        }
    }, [activeMetric, glucose, hba1c, uricAcid, cholesterol, triglyceride, protein, albumin, ure, creatinine, language]);

    const totalSpent = orderHistory.reduce((sum, order) => sum + order.totalPrice, 0);
    const totalOrders = orderHistory.length;

    return (
        <div className="max-w-6xl mx-auto p-4 sm:p-6 animate-fade-in space-y-6 pb-20">
            <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
                <div className="text-center sm:text-left">
                    <h2 className="text-3xl font-bold text-cyan-300">{t.customer_profile}</h2>
                    <p className="text-gray-400">{t.health_metrics}</p>
                </div>
                <button onClick={onBack} className="bg-gray-700 hover:bg-gray-600 text-white font-semibold py-2 px-6 rounded-lg transition-colors shadow-lg">
                    {t.back}
                </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-gray-900/60 backdrop-blur-xl p-4 rounded-2xl border border-cyan-500/20 flex items-center gap-4 shadow-lg shadow-cyan-900/10">
                    <img src={userData.avatar || `https://i.pravatar.cc/150?u=${userData.phone}`} className="w-16 h-16 rounded-full border-2 border-cyan-500 object-cover" alt="Avatar" />
                    <div>
                        <h3 className="text-lg font-bold text-white">{userData.fullName}</h3>
                        <div className="flex items-center gap-1 text-yellow-400 text-xs mt-1">
                            <UserIcon className="w-3 h-3" /> {NUTRITION_GOAL_TRANSLATIONS[userData.nutritionGoal][language]}
                        </div>
                    </div>
                </div>
                <div className="bg-gray-900/60 backdrop-blur-xl p-4 rounded-2xl border border-cyan-500/20 flex justify-around items-center shadow-lg shadow-cyan-900/10">
                     <div className="text-center">
                        <WeightIcon className="w-6 h-6 mx-auto text-cyan-500 mb-1" />
                        <p className="text-gray-400 text-xs">{t.weight}</p>
                        <p className="text-lg font-bold text-white">{userData.weight} kg</p>
                     </div>
                     <div className="w-px h-10 bg-gray-700"></div>
                     <div className="text-center">
                        <HeightIcon className="w-6 h-6 mx-auto text-cyan-500 mb-1" />
                        <p className="text-gray-400 text-xs">{t.height}</p>
                        <p className="text-lg font-bold text-white">{userData.height} cm</p>
                     </div>
                </div>
                <div className="bg-gray-900/60 backdrop-blur-xl p-4 rounded-2xl border border-cyan-500/20 flex justify-around items-center text-sm shadow-lg shadow-cyan-900/10">
                    <div className="text-center">
                        <p className="text-gray-400 text-xs">{t.orders}</p>
                        <p className="text-xl font-bold text-white">{totalOrders}</p>
                    </div>
                    <div className="text-center">
                        <p className="text-gray-400 text-xs">{t.spending}</p>
                        <p className="text-xl font-bold text-cyan-300">{totalSpent.toLocaleString()}đ</p>
                    </div>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-1 space-y-4">
                    <h3 className="text-lg font-bold text-white mb-2 flex items-center gap-2">
                        <ChartIcon className="w-5 h-5 text-cyan-400"/> {t.select_metric}
                    </h3>
                    <div className="grid grid-cols-2 gap-3 max-h-[500px] overflow-y-auto pr-1 custom-scrollbar">
                        <MetricCard 
                            label="Glucose" 
                            value={lab.glucose || '--'} 
                            unit="mg/dL" 
                            status={getStatus(glucose, 100, 126)}
                            onClick={() => { setActiveMetric('glucose'); setSelectedPointIndex(5); }}
                            isActive={activeMetric === 'glucose'}
                            activeColor="#38bdf8"
                        />
                        <MetricCard 
                            label="HbA1c" 
                            value={lab.hba1c || '--'} 
                            unit="%" 
                            status={getStatus(hba1c, 5.7, 6.5)}
                            onClick={() => { setActiveMetric('hba1c'); setSelectedPointIndex(5); }}
                            isActive={activeMetric === 'hba1c'}
                            activeColor="#a78bfa"
                        />
                        <MetricCard 
                            label="Acid Uric" 
                            value={lab.uricAcid || '--'} 
                            unit="mg/dL" 
                            status={getStatus(uricAcid, 6, 7)}
                            onClick={() => { setActiveMetric('uricAcid'); setSelectedPointIndex(5); }}
                            isActive={activeMetric === 'uricAcid'}
                            activeColor="#f472b6"
                        />
                        <MetricCard 
                            label="Cholesterol" 
                            value={lab.cholesterol || '--'} 
                            unit="mg/dL" 
                            status={getStatus(cholesterol, 200, 240)}
                            onClick={() => { setActiveMetric('cholesterol'); setSelectedPointIndex(5); }}
                            isActive={activeMetric === 'cholesterol'}
                            activeColor="#fbbf24"
                        />
                        <MetricCard 
                            label="Triglyceride" 
                            value={lab.triglyceride || '--'} 
                            unit="mg/dL" 
                            status={getStatus(triglyceride, 150, 200)}
                            onClick={() => { setActiveMetric('triglyceride'); setSelectedPointIndex(5); }}
                            isActive={activeMetric === 'triglyceride'}
                            activeColor="#fb7185"
                        />
                        <MetricCard 
                            label="Protein TP" 
                            value={lab.protein || '--'} 
                            unit="g/dL" 
                            status={getLowStatus(protein, 6.4, 6.0)} 
                            onClick={() => { setActiveMetric('protein'); setSelectedPointIndex(5); }}
                            isActive={activeMetric === 'protein'}
                            activeColor="#818cf8"
                        />
                        <MetricCard 
                            label="Albumin" 
                            value={lab.albumin || '--'} 
                            unit="g/dL" 
                            status={getLowStatus(albumin, 3.8, 3.5)} 
                            onClick={() => { setActiveMetric('albumin'); setSelectedPointIndex(5); }}
                            isActive={activeMetric === 'albumin'}
                            activeColor="#2dd4bf"
                        />
                        <MetricCard 
                            label="Ure" 
                            value={lab.ure || '--'} 
                            unit="mg/dL" 
                            status={getStatus(ure, 40, 50)}
                            onClick={() => { setActiveMetric('ure'); setSelectedPointIndex(5); }}
                            isActive={activeMetric === 'ure'}
                            activeColor="#fb923c"
                        />
                        <MetricCard 
                            label="Creatinine" 
                            value={lab.creatinine || '--'} 
                            unit="mg/dL" 
                            status={getStatus(creatinine, 1.2, 1.5)}
                            onClick={() => { setActiveMetric('creatinine'); setSelectedPointIndex(5); }}
                            isActive={activeMetric === 'creatinine'}
                            activeColor="#f87171"
                        />
                    </div>
                     <div className="bg-gray-800/40 p-4 rounded-xl border border-gray-700 mt-2">
                        <div className="flex items-start gap-3">
                            <AlertIcon className="w-6 h-6 text-cyan-400 flex-shrink-0 mt-0.5" />
                            <div>
                                <p className="font-bold text-cyan-300 text-sm mb-1">{t.ai_perspective}</p>
                                <p className="text-sm text-gray-300 leading-relaxed">
                                    {config.advice}
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="lg:col-span-2 bg-gray-900/60 backdrop-blur-xl p-6 rounded-2xl border border-gray-700/50 flex flex-col h-full shadow-2xl shadow-black/20">
                    <div className="flex justify-between items-center mb-6">
                         <div>
                            <h3 className="text-xl font-bold text-white flex items-center gap-2">
                                {t.correlation_chart}
                                <span className="text-xs font-normal px-2 py-0.5 rounded-full border" style={{ borderColor: config.color, color: config.color }}>
                                    {config.label} vs {config.intakeLabel}
                                </span>
                            </h3>
                            <div className="flex items-center gap-2 text-xs text-gray-400 mt-1">
                                <p>{t.click_chart_hint}</p>
                                <span className="text-gray-500">•</span>
                                <p>Dữ liệu được cập nhật từ Hồ sơ sức khỏe</p>
                            </div>
                         </div>
                    </div>
                    
                    <div className="flex-shrink-0 bg-gray-900/30 rounded-xl p-2 border border-gray-700/30 mb-6 relative">
                        {(!glucose && !hba1c && !uricAcid && !cholesterol && !triglyceride && !protein && !albumin && !ure && !creatinine && snapshots.length === 0) 
                         ? (
                             <div className="text-center text-gray-500 py-16">
                                <ChartIcon className="w-12 h-12 mx-auto mb-2 opacity-30" />
                                <p>{t.metric_no_data}</p>
                             </div>
                        ) : (
                            <TrendChart 
                                data={chartData} 
                                label={config.label} 
                                intakeLabel={config.intakeLabel}
                                safeRange={config.safeRange}
                                selectedIndex={selectedPointIndex}
                                onPointClick={setSelectedPointIndex}
                                color={config.color}
                                safeZoneLabel={t.safe_zone}
                            />
                        )}
                    </div>

                    <div className="flex-grow flex flex-col min-h-0">
                        <div className="flex items-center justify-between mb-4 pb-2 border-b border-gray-700/50">
                            <h4 className="font-bold text-white text-sm flex items-center gap-2">
                                <CalendarIcon className="w-4 h-4 text-cyan-400" />
                                {t.history_month} {chartData[selectedPointIndex]?.dateLabel}
                            </h4>
                            {selectedMonthDishes.length > 0 ? (
                                <span className="text-xs text-white bg-gray-700 px-2 py-1 rounded-full">{selectedMonthDishes.length} món</span>
                            ) : (
                                <span className="text-xs text-gray-500">{t.no_data}</span>
                            )}
                        </div>
                        
                        <div className="space-y-3 overflow-y-auto pr-2 custom-scrollbar flex-1">
                            {selectedMonthDishes.length > 0 ? (
                                selectedMonthDishes.map((entry, idx) => (
                                    <DishHistoryItem 
                                        key={idx} 
                                        item={entry.item} 
                                        count={entry.count} 
                                        highlight={config.highlight}
                                        color={config.color}
                                        t={t}
                                    />
                                ))
                            ) : (
                                <div className="h-full flex flex-col items-center justify-center text-center py-8 bg-gray-800/20 rounded-lg border border-dashed border-gray-700">
                                    <p className="text-gray-500 text-sm">{t.no_data}</p>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};
