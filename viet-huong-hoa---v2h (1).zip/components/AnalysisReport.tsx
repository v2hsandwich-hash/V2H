
import React, { useMemo } from 'react';
import { AnalysisResult, UserData, AlertLevel, Language } from '../types';
import { ChartIcon, AlertIcon, TrophyIcon } from './Icons';
import { NUTRITION_GOAL_TRANSLATIONS, TRANSLATIONS } from '../constants';

interface AnalysisReportProps {
  analysis: AnalysisResult;
  userData: UserData;
  onProceed: () => void;
  onGoToPlanner: () => void;
  onBackToForm: () => void;
  language: Language;
}

const StatCard: React.FC<{ title: string; value: string | number; unit: string; description: string; color: string }> = ({ title, value, unit, description, color }) => (
    <div className="bg-black/40 backdrop-blur-xl p-5 rounded-2xl border border-gray-700/50 flex flex-col justify-between h-full relative overflow-hidden group hover:border-opacity-100 transition-all duration-300" style={{ borderColor: `${color}40` }}>
        <div className="absolute inset-0 bg-gradient-to-br from-transparent to-black/80 z-0"></div>
        <div className="absolute -right-6 -top-6 w-24 h-24 rounded-full blur-2xl opacity-20 z-0 group-hover:opacity-30 transition-opacity" style={{ backgroundColor: color }}></div>
        
        <p className="text-xs font-bold uppercase tracking-wider relative z-10" style={{ color: color }}>{title}</p>
        <div className="relative z-10 mt-2">
            <span className="text-4xl font-black text-white font-['Orbitron']">{value}</span>
            <span className="text-sm font-medium text-gray-400 ml-1">{unit}</span>
        </div>
        <p className="text-[10px] text-gray-400 mt-2 relative z-10 border-t border-gray-700/50 pt-2">{description}</p>
    </div>
);

export const AnalysisReport: React.FC<AnalysisReportProps> = ({ analysis, userData, onProceed, onGoToPlanner, onBackToForm, language }) => {
  const { bmi, energyNeeds, healthAnalysis, recommendations, macroDistribution, foodsToAvoid } = analysis;
  const t = TRANSLATIONS[language];

  const healthAlerts = useMemo(() => {
    const alerts: { message: string; level: AlertLevel }[] = [];
    if (!userData?.labValues) return alerts;

    const lab = userData.labValues;
    const gender = userData.gender;
    const parse = (val: string) => val ? parseFloat(val) : NaN;

    const msg = (vi: string, en: string) => language === 'en' ? en : language === 'vi' ? vi : vi;

    const glucose = parse(lab.glucose);
    if (!isNaN(glucose)) {
      if (glucose > 125) alerts.push({ message: `Glucose (${glucose} mg/dL) ` + msg('ở mức cao, nguy cơ tiểu đường.', 'is high, high diabetes risk.'), level: AlertLevel.Red });
      else if (glucose > 100) alerts.push({ message: `Glucose (${glucose} mg/dL) ` + msg('ở mức tiền tiểu đường.', 'is pre-diabetic.'), level: AlertLevel.Yellow });
    }

    const hba1c = parse(lab.hba1c);
    if (!isNaN(hba1c)) {
      if (hba1c >= 6.5) alerts.push({ message: `HbA1c (${hba1c}%) ` + msg('cao, nguy cơ tiểu đường.', 'high, diabetes risk.'), level: AlertLevel.Red });
      else if (hba1c >= 5.7) alerts.push({ message: `HbA1c (${hba1c}%) ` + msg('tiền tiểu đường.', 'pre-diabetic.'), level: AlertLevel.Yellow });
    }

    const cholesterol = parse(lab.cholesterol);
    if (!isNaN(cholesterol)) {
        if (cholesterol >= 240) alerts.push({ message: `Cholesterol (${cholesterol} mg/dL) ` + msg('rất cao, nguy cơ tim mạch.', 'very high, cardiovascular risk.'), level: AlertLevel.Red });
        else if (cholesterol >= 200) alerts.push({ message: `Cholesterol (${cholesterol} mg/dL) ` + msg('hơi cao.', 'borderline high.'), level: AlertLevel.Yellow });
    }
    
    // ... (rest of logic same as before) ...
    
    return alerts;
  }, [userData, language]);


  return (
    <div className="max-w-5xl mx-auto p-4 md:p-8 space-y-8 animate-fade-in pb-20">
        <div className="text-center relative">
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-lg h-32 bg-cyan-500/10 blur-3xl rounded-full pointer-events-none"></div>
            <h2 className="text-3xl md:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-200 via-white to-cyan-200 drop-shadow-[0_0_10px_rgba(6,182,212,0.5)] font-['Orbitron']">{t.hello}, {userData.fullName}!</h2>
            <div className="mt-3 inline-flex items-center gap-2 px-4 py-1 rounded-full bg-gray-900/50 border border-gray-700 text-sm text-cyan-400">
                <TrophyIcon className="w-4 h-4 text-yellow-400" />
                {t.report}: <span className="text-white font-bold">"{NUTRITION_GOAL_TRANSLATIONS[userData.nutritionGoal][language]}"</span>
            </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <StatCard title={t.bmi_index} value={bmi.value.toFixed(1)} unit="" description={bmi.category} color="#38bdf8" />
            <StatCard title={t.daily_needs} value={energyNeeds.calories} unit="kcal" description={t.per_day} color="#facc15" />
            
            {/* Macro Chart */}
            <div className="bg-black/40 backdrop-blur-xl p-5 rounded-2xl border border-gray-700/50 flex flex-col justify-between h-full relative overflow-hidden group">
                <div className="absolute -right-6 -bottom-6 w-32 h-32 rounded-full blur-3xl opacity-10 bg-purple-500 z-0"></div>
                <p className="text-xs font-bold uppercase tracking-wider text-purple-400 relative z-10">{t.macronutrients}</p>
                
                <div className="flex justify-between items-end h-full mt-4 gap-2 relative z-10">
                    <div className="flex flex-col items-center gap-1 flex-1">
                        <div className="w-full bg-gray-800 rounded-t-lg relative overflow-hidden h-24 flex items-end">
                            <div className="w-full bg-blue-500/80 hover:bg-blue-400 transition-all rounded-t-lg" style={{ height: `${macroDistribution.carbs}%` }}></div>
                        </div>
                        <span className="text-xl font-bold text-white">{macroDistribution.carbs}%</span>
                        <span className="text-[10px] text-gray-400 uppercase tracking-wider">{t.carbs}</span>
                    </div>
                    <div className="flex flex-col items-center gap-1 flex-1">
                        <div className="w-full bg-gray-800 rounded-t-lg relative overflow-hidden h-24 flex items-end">
                            <div className="w-full bg-rose-500/80 hover:bg-rose-400 transition-all rounded-t-lg" style={{ height: `${macroDistribution.protein}%` }}></div>
                        </div>
                        <span className="text-xl font-bold text-white">{macroDistribution.protein}%</span>
                        <span className="text-[10px] text-gray-400 uppercase tracking-wider">{t.protein}</span>
                    </div>
                    <div className="flex flex-col items-center gap-1 flex-1">
                        <div className="w-full bg-gray-800 rounded-t-lg relative overflow-hidden h-24 flex items-end">
                            <div className="w-full bg-amber-500/80 hover:bg-amber-400 transition-all rounded-t-lg" style={{ height: `${macroDistribution.fat}%` }}></div>
                        </div>
                        <span className="text-xl font-bold text-white">{macroDistribution.fat}%</span>
                        <span className="text-[10px] text-gray-400 uppercase tracking-wider">{t.fat}</span>
                    </div>
                </div>
            </div>
        </div>

        {healthAlerts.length > 0 && (
            <div className="bg-gray-900/40 backdrop-blur-xl p-6 rounded-2xl border border-l-4 border-l-amber-500 border-y-0 border-r-0 shadow-lg animate-pulse-cyan">
                <h3 className="text-lg font-bold text-amber-400 mb-4 flex items-center gap-2 uppercase tracking-wide">
                    <AlertIcon className="w-6 h-6" /> {t.health_alerts}
                </h3>
                <div className="space-y-3">
                    {healthAlerts.map((alert, index) => {
                        const alertClasses = {
                            [AlertLevel.Red]: 'text-red-300 bg-red-900/20 border-red-500/30',
                            [AlertLevel.Yellow]: 'text-amber-200 bg-amber-900/20 border-amber-500/30',
                            [AlertLevel.Green]: 'text-emerald-300 bg-emerald-900/20 border-emerald-500/30',
                        };
                        return (
                            <div key={index} className={`p-3 rounded-lg flex items-start gap-3 text-sm border ${alertClasses[alert.level]}`}>
                                <AlertIcon className="w-5 h-5 flex-shrink-0 mt-0.5 opacity-80" />
                                <span>{alert.message}</span>
                            </div>
                        )
                    })}
                </div>
            </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-black/40 backdrop-blur-xl p-6 rounded-2xl border border-cyan-500/20 shadow-lg">
                <h3 className="text-lg font-bold text-cyan-400 mb-4 flex items-center gap-2 uppercase tracking-wide">
                    <ChartIcon className="w-5 h-5" /> {t.health_analysis}
                </h3>
                <p className="text-gray-300 text-sm leading-relaxed font-light">{healthAnalysis}</p>
            </div>
            
            <div className="bg-black/40 backdrop-blur-xl p-6 rounded-2xl border border-red-500/20 shadow-lg">
                <h3 className="text-lg font-bold text-red-400 mb-4 uppercase tracking-wide">{t.foods_to_avoid}</h3>
                <ul className="space-y-2">
                    {foodsToAvoid.map((food, index) => (
                        <li key={index} className="flex items-start gap-2 text-sm text-gray-300">
                            <span className="text-red-500 mt-1">✕</span> {food}
                        </li>
                    ))}
                </ul>
            </div>
        </div>

        <div className="bg-gradient-to-br from-gray-900/80 to-gray-800/80 backdrop-blur-xl p-8 rounded-2xl border border-emerald-500/20 shadow-[0_0_30px_rgba(16,185,129,0.1)]">
            <h3 className="text-xl font-bold text-emerald-400 mb-6 uppercase tracking-wide text-center">{t.recommendations}</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-4">
                 {recommendations.map((rec, index) => (
                     <div key={index} className="flex items-start gap-3 p-3 rounded-lg bg-emerald-900/10 border border-emerald-500/10">
                         <div className="w-6 h-6 rounded-full bg-emerald-500/20 flex items-center justify-center text-emerald-400 font-bold text-xs flex-shrink-0 mt-0.5">{index + 1}</div>
                         <p className="text-gray-300 text-sm">{rec}</p>
                     </div>
                 ))}
            </div>
        </div>
        
        <div className="flex flex-col sm:flex-row justify-center items-center gap-4 pt-4">
            <button 
                onClick={onBackToForm} 
                className="w-full sm:w-auto px-8 py-4 rounded-xl bg-gray-800 text-gray-300 font-bold hover:bg-gray-700 border border-gray-700 transition-all uppercase tracking-wide text-sm"
            >
                {t.back}
            </button>
            <button 
                onClick={onProceed} 
                className="w-full sm:w-auto px-10 py-4 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold shadow-[0_0_20px_rgba(6,182,212,0.4)] hover:shadow-[0_0_30px_rgba(6,182,212,0.6)] transition-all transform hover:-translate-y-1 uppercase tracking-wide text-sm group"
            >
                <span className="group-hover:tracking-widest transition-all duration-300">{t.start_ordering}</span>
            </button>
             <button 
                onClick={onGoToPlanner} 
                className="w-full sm:w-auto px-8 py-4 rounded-xl bg-emerald-900/50 hover:bg-emerald-800/50 text-emerald-300 border border-emerald-500/50 font-bold hover:shadow-[0_0_20px_rgba(16,185,129,0.3)] transition-all uppercase tracking-wide text-sm"
            >
                {t.create_plan}
            </button>
        </div>
    </div>
  );
};
