import { GoogleGenAI, Type, LiveServerMessage, Modality, Blob, FunctionDeclaration, Schema } from "@google/genai";
import { UserData, AnalysisResult, MenuItemType, Language, WeeklyMealPlan, OrderItemType, DirectionsResult, ChatMessage } from '../types';
import { encode } from '../utils/audioUtils';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getNutritionAnalysis = async (userData: UserData, language: Language): Promise<AnalysisResult> => {
    const prompt = `
    Analyze the nutritional needs for a user with the following profile:
    - Gender: ${userData.gender}
    - Birth Year: ${userData.birthYear}
    - Weight: ${userData.weight} kg
    - Height: ${userData.height} cm
    - Goal: ${userData.nutritionGoal}
    - Medical Conditions: ${userData.medicalConditions || 'None'}
    - Lab Values: ${JSON.stringify(userData.labValues)}
    
    Provide the analysis in ${language}.
    `;

    const schema: Schema = {
        type: Type.OBJECT,
        properties: {
            bmi: {
                type: Type.OBJECT,
                properties: {
                    value: { type: Type.NUMBER },
                    category: { type: Type.STRING },
                },
                required: ['value', 'category']
            },
            energyNeeds: {
                type: Type.OBJECT,
                properties: {
                    calories: { type: Type.NUMBER },
                },
                required: ['calories']
            },
            healthAnalysis: { type: Type.STRING },
            recommendations: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
            },
            macroDistribution: {
                type: Type.OBJECT,
                properties: {
                    carbs: { type: Type.NUMBER },
                    protein: { type: Type.NUMBER },
                    fat: { type: Type.NUMBER },
                },
                required: ['carbs', 'protein', 'fat']
            },
            foodsToAvoid: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
            },
        },
        required: ['bmi', 'energyNeeds', 'healthAnalysis', 'recommendations', 'macroDistribution', 'foodsToAvoid']
    };

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: schema,
            },
        });
        
        if (response.text) {
            return JSON.parse(response.text) as AnalysisResult;
        }
        throw new Error("Empty response from AI");
    } catch (error) {
        console.error("Analysis failed:", error);
        throw error;
    }
};

export const generateAvatar = async (userData: UserData): Promise<string> => {
    const prompt = `A futuristic, professional avatar for a user profile. Style: Cyberpunk/Tech. 
    User details: Gender ${userData.gender}, Goal ${userData.nutritionGoal}. 
    High quality, vibrant colors (cyan, purple).`;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-image',
            contents: {
                parts: [{ text: prompt }]
            }
        });

        for (const part of response.candidates?.[0]?.content?.parts || []) {
            if (part.inlineData) {
                return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
            }
        }
        return ''; // Fallback
    } catch (error) {
        console.error("Avatar generation failed:", error);
        return '';
    }
};

export const generateSpeech = async (text: string): Promise<string> => {
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash-preview-tts",
            contents: [{ parts: [{ text }] }],
            config: {
                responseModalities: [Modality.AUDIO],
                speechConfig: {
                    voiceConfig: {
                        prebuiltVoiceConfig: { voiceName: 'Kore' },
                    },
                },
            },
        });
        
        const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
        return base64Audio || '';
    } catch (error) {
        console.error("TTS failed:", error);
        throw error;
    }
};

export const generateNutritionistAdvice = async (userData: UserData, analysis: AnalysisResult, menuItems: Record<string, MenuItemType[]>, language: Language): Promise<string> => {
    const fullMenu = Object.values(menuItems).reduce<MenuItemType[]>((acc, val) => acc.concat(val), []);
    const simplifiedMenu = fullMenu.map(item => 
        `- ${item.name} (${item.calories}kcal, Carb:${item.carbs}g, Pro:${item.protein}g, Fat:${item.fat}g)`
    ).join('\n');

    const labSummary = Object.entries(userData.labValues)
        .filter(([_, val]) => val && val.toString().trim() !== '')
        .map(([key, val]) => `${key}: ${val}`)
        .join(', ');

    const prompt = `
        Bạn là Chuyên gia Dinh dưỡng Cao cấp của hệ thống V2H.
        Hồ sơ khách hàng:
        - Tên: ${userData.fullName}
        - BMI: ${analysis.bmi.value}
        - Bệnh lý: ${userData.medicalConditions || 'Không có'}
        - Xét nghiệm: ${labSummary || 'Chưa có'}
        - Nhu cầu: ${analysis.energyNeeds.calories} kcal/ngày.
        
        Thực đơn nhà hàng:
        ${simplifiedMenu}

        Nhiệm vụ: Tạo lời khuyên dinh dưỡng ngắn gọn (TTS) bằng ngôn ngữ "${language}".
        Chọn 2 món ăn phù hợp nhất.
        Độ dài: 80-100 từ.
    `;

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                maxOutputTokens: 350,
                temperature: 0.7
            }
        });
        return response.text || "";
    } catch (error) {
        console.error("Advice generation failed:", error);
        return "";
    }
};

export const generateMealPlan = async (analysis: AnalysisResult, menuItems: Record<string, MenuItemType[]>, language: Language): Promise<WeeklyMealPlan> => {
    // FIX: Explicitly cast Object.values result to resolve 'unknown' type error in reduce
    const allItems = (Object.values(menuItems) as MenuItemType[][]).reduce<MenuItemType[]>((acc, val) => acc.concat(val), []);
    const menuList = allItems.map(item => `${item.id}: ${item.name} (${item.calories}kcal)`).join('\n');

    const prompt = `Generate a weekly meal plan for a user with daily needs ${analysis.energyNeeds.calories} kcal.
    Available Menu Items:
    ${menuList}
    
    Return a JSON object where keys are days (Thứ Hai...Chủ Nhật) and values are objects with keys (Bữa sáng, Bữa phụ sáng, Bữa trưa, Bữa phụ chiều, Bữa tối, Bữa phụ tối).
    The value for each meal should be the ITEM ID from the list above. If no item fits, use null.
    Language: ${language}.
    `;

    const daySchema: Schema = {
        type: Type.OBJECT,
        properties: {
            "Bữa sáng": { type: Type.STRING, nullable: true },
            "Bữa phụ sáng": { type: Type.STRING, nullable: true },
            "Bữa trưa": { type: Type.STRING, nullable: true },
            "Bữa phụ chiều": { type: Type.STRING, nullable: true },
            "Bữa tối": { type: Type.STRING, nullable: true },
            "Bữa phụ tối": { type: Type.STRING, nullable: true },
        }
    };

    const schema: Schema = {
        type: Type.OBJECT,
        properties: {
            'Thứ Hai': daySchema,
            'Thứ Ba': daySchema,
            'Thứ Tư': daySchema,
            'Thứ Năm': daySchema,
            'Thứ Sáu': daySchema,
            'Thứ Bảy': daySchema,
            'Chủ Nhật': daySchema,
        }
    };

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: schema
            }
        });
        
        const rawPlan = JSON.parse(response.text || '{}');
        // Transform raw plan (which has IDs) into WeeklyMealPlan structure in the component, or return raw and let component handle.
        // Returning raw format that matches what the component expects partially (it expects objects with id to map back).
        return rawPlan; 
    } catch (error) {
        console.error("Meal plan generation failed:", error);
        throw error;
    }
};

export const getChatbotResponse = async (message: string, history: ChatMessage[], menuItems: Record<string, MenuItemType[]>, language: Language): Promise<string> => {
    // FIX: Explicitly cast Object.values result to resolve 'unknown' type error in reduce
    const allItems = (Object.values(menuItems) as MenuItemType[][]).reduce<MenuItemType[]>((acc, val) => acc.concat(val), []);
    const menuContext = allItems.map(i => `${i.name} (${i.price}đ)`).join(', ');
    
    const prompt = `You are a helpful assistant for V2H restaurant. 
    Menu: ${menuContext}.
    User message: ${message}
    Answer in ${language}. Keep it short and helpful.`;

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
        });
        return response.text || "";
    } catch (error) {
        console.error("Chatbot failed:", error);
        return "Sorry, I am having trouble connecting.";
    }
};

export const connectLive = async (callbacks: any, language: Language) => {
    return await ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        callbacks,
        config: {
            responseModalities: [Modality.AUDIO],
            speechConfig: {
                voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } },
            },
            systemInstruction: `You are a friendly restaurant assistant speaking ${language}.`,
        },
    });
};

export const createAudioBlob = (data: Float32Array): Blob => {
    const l = data.length;
    const int16 = new Int16Array(l);
    for (let i = 0; i < l; i++) {
        int16[i] = data[i] * 32768;
    }
    return {
        data: encode(new Uint8Array(int16.buffer)),
        mimeType: 'audio/pcm;rate=16000',
    };
};

export const getDirections = async (location: { latitude: number; longitude: number }, language: Language): Promise<DirectionsResult> => {
    const prompt = `How do I get from my current location (lat: ${location.latitude}, long: ${location.longitude}) to "123 Đường Sức Khỏe, Quận Dinh Dưỡng, Thành phố Vui Vẻ"? Provide concise directions in ${language}. Also provide a Google Maps URL.`;
    
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                tools: [{ googleMaps: {} }],
            },
        });
        
        let mapUrl = "";
        if (response.candidates?.[0]?.groundingMetadata?.groundingChunks) {
             const chunks = response.candidates[0].groundingMetadata.groundingChunks;
             // Check if chunks is an array and find map URI
             if (Array.isArray(chunks)) {
                 const mapChunk = chunks.find((c: any) => c.web?.uri && c.web.uri.includes('google.com/maps'));
                 if (mapChunk) mapUrl = mapChunk.web.uri;
             }
        }
        
        // Fallback map URL if grounding doesn't return one or structure is different
        if (!mapUrl) {
             mapUrl = `https://www.google.com/maps/dir/?api=1&origin=${location.latitude},${location.longitude}&destination=10.7769,106.7009`; // Dummy dest coords for V2H
        }

        return {
            directionsText: response.text || "Directions not available.",
            mapUrl: mapUrl
        };
    } catch (error) {
        console.error("Directions failed:", error);
        throw error;
    }
};