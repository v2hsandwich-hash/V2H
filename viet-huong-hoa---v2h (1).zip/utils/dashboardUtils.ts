import { PastOrderType, MenuItemType, Period, DashboardData, MealType, ChartDataPoint } from '../types';

const getPeriodRange = (period: Period): { start: Date, end: Date } => {
    const now = new Date();
    const start = new Date(now);
    const end = new Date(now);

    switch (period) {
        case 'day':
            start.setHours(0, 0, 0, 0);
            end.setHours(23, 59, 59, 999);
            break;
        case 'week':
            const dayOfWeek = now.getDay();
            const diff = now.getDate() - dayOfWeek + (dayOfWeek === 0 ? -6 : 1); // Adjust when Sunday is the first day of the week
            start.setDate(diff);
            start.setHours(0, 0, 0, 0);
            end.setDate(start.getDate() + 6);
            end.setHours(23, 59, 59, 999);
            break;
        case 'month':
            start.setDate(1);
            start.setHours(0, 0, 0, 0);
            end.setMonth(now.getMonth() + 1, 0);
            end.setHours(23, 59, 59, 999);
            break;
    }
    return { start, end };
};

const filterOrdersByPeriod = (orders: PastOrderType[], period: Period): PastOrderType[] => {
    if (!orders) return [];
    const { start, end } = getPeriodRange(period);
    return orders.filter(order => {
        const orderDate = new Date(order.date);
        return orderDate >= start && orderDate <= end;
    });
};

const getMealTypeForItem = (itemId: string, allMenus: Record<string, MenuItemType[]>): MealType | null => {
    for (const mealType in allMenus) {
        if (allMenus[mealType].some(item => item.id === itemId)) {
            return mealType as MealType;
        }
    }
    return null;
}

export const getDashboardData = (
    allOrders: PastOrderType[],
    allMenus: Record<string, MenuItemType[]>,
    period: Period
): DashboardData => {
    const orders = filterOrdersByPeriod(allOrders, period);

    // 1. Total Revenue
    const totalRevenue = orders.reduce((sum, order) => sum + order.totalPrice, 0);

    // 2. Net Profit
    const totalCost = orders.reduce((sum, order) => {
        return sum + order.items.reduce((itemSum, item) => {
            const cost = item.menuItem.ingredientCost ?? item.menuItem.price * 0.3; // Fallback
            return itemSum + (cost * item.quantity);
        }, 0);
    }, 0);
    const netProfit = totalRevenue - totalCost;

    // 3. Returning Customer Rate
    const uniqueCustomers = new Set(orders.map(o => o.userPhone).filter(p => p !== 'guest'));
    const allTimeCustomers = new Set(allOrders.map(o => o.userPhone).filter(p => p !== 'guest'));
    const returningCustomers = new Set<string>();
    
    orders.forEach(order => {
        if (order.userPhone !== 'guest') {
            const priorOrders = allOrders.filter(o => o.userPhone === order.userPhone && new Date(o.date) < new Date(order.date));
            if (priorOrders.length > 0) {
                returningCustomers.add(order.userPhone as string);
            }
        }
    });
    
    const returningCustomerRate = uniqueCustomers.size > 0 ? (returningCustomers.size / uniqueCustomers.size) * 100 : 0;

    // 4. Best Seller & Top Products
    const itemCounts = new Map<string, { item: MenuItemType, quantity: number }>();
    const menuMap = new Map<string, MenuItemType>();
    Object.values(allMenus).flat().forEach(item => menuMap.set(item.id, item));

    orders.forEach(order => {
        order.items.forEach(orderItem => {
            const existing = itemCounts.get(orderItem.menuItem.id);
            const fullMenuItem = menuMap.get(orderItem.menuItem.id);
            if(fullMenuItem){
                 itemCounts.set(orderItem.menuItem.id, {
                    item: fullMenuItem,
                    quantity: (existing?.quantity || 0) + orderItem.quantity
                });
            }
        });
    });

    const sortedItems = [...itemCounts.values()].sort((a, b) => b.quantity - a.quantity);
    const bestSeller = sortedItems.length > 0 ? { name: sortedItems[0].item.name, quantity: sortedItems[0].quantity } : undefined;
    const topProducts = sortedItems.slice(0, 5).map(i => ({
        id: i.item.id,
        name: i.item.name,
        image: i.item.image,
        quantity: i.quantity
    }));

    // 5. Revenue Chart Data
    let revenueChartData: ChartDataPoint[] = [];
    if (period === 'day') {
        revenueChartData = Array.from({ length: 24 }, (_, i) => ({ label: `${i}h`, value: 0 }));
        orders.forEach(order => {
            const hour = new Date(order.date).getHours();
            revenueChartData[hour].value += order.totalPrice;
        });
    } else if (period === 'week') {
        const daysOfWeek = ['CN', 'T2', 'T3', 'T4', 'T5', 'T6', 'T7'];
        revenueChartData = daysOfWeek.map(day => ({ label: day, value: 0 }));
        orders.forEach(order => {
            const day = new Date(order.date).getDay();
            revenueChartData[day].value += order.totalPrice;
        });
    } else { // month
        const daysInMonth = new Date().getDate();
        revenueChartData = Array.from({ length: daysInMonth }, (_, i) => ({ label: `${i + 1}`, value: 0 }));
        orders.forEach(order => {
            const day = new Date(order.date).getDate() - 1;
            revenueChartData[day].value += order.totalPrice;
        });
    }

    // 6. Revenue by Category
    const revenueByCategoryMap = new Map<MealType, number>();
     orders.forEach(order => {
        order.items.forEach(item => {
            const mealType = getMealTypeForItem(item.menuItem.id, allMenus);
            if (mealType) {
                revenueByCategoryMap.set(mealType, (revenueByCategoryMap.get(mealType) || 0) + item.totalPrice);
            }
        });
    });
    const revenueByCategory = Array.from(revenueByCategoryMap.entries()).map(([name, value]) => ({ name, value })).sort((a,b) => b.value - a.value);

    return {
        totalRevenue,
        netProfit,
        returningCustomerRate,
        bestSeller,
        revenueChartData,
        profitAnalysis: { revenue: totalRevenue, cost: totalCost },
        revenueByCategory,
        topProducts
    };
};