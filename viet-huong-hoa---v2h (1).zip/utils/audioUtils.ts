
// These functions are from the Gemini documentation for decoding raw PCM data.
let audioContext: AudioContext | null = null;
const activeAudioSources = new Set<AudioBufferSourceNode>();

const getAudioContext = (): AudioContext => {
    if (!audioContext || audioContext.state === 'closed') {
        audioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
    }
    return audioContext;
};

// Mobile browsers require audio context to be resumed/created inside a user gesture event (click/touch).
// Call this function synchronously within a click handler.
export const unlockAudioContext = async () => {
    const ctx = getAudioContext();
    if (ctx.state === 'suspended') {
        await ctx.resume();
    }
    
    // Play a silent buffer to "warm up" the iOS audio engine
    try {
        const buffer = ctx.createBuffer(1, 1, 22050);
        const source = ctx.createBufferSource();
        source.buffer = buffer;
        source.connect(ctx.destination);
        source.start(0);
    } catch (e) {
        console.error("Failed to unlock audio context:", e);
    }
};

export const stopAllAudio = () => {
    activeAudioSources.forEach(source => {
        try {
            source.stop();
        } catch (e) {
            console.warn("Could not stop audio source, it might have already finished.", e);
        }
    });
    activeAudioSources.clear();
};

export const playAudio = async (base64Audio: string): Promise<number> => {
    if (!base64Audio) {
        return 0; // Return immediately if no audio data
    }
    
    try {
        stopAllAudio(); // Stop any currently playing audio

        const ctx = getAudioContext();
        
        // Ensure context is running (vital for mobile)
        if (ctx.state === 'suspended') {
            await ctx.resume();
        }

        const decodedBytes = decode(base64Audio);
        
        if (decodedBytes.length === 0) {
            return 0; // Return if decoding produced empty data
        }

        const audioBuffer = await decodeAudioData(decodedBytes, ctx, 24000, 1);
        
        const source = ctx.createBufferSource();
        source.buffer = audioBuffer;
        source.connect(ctx.destination);
        source.start();
        
        activeAudioSources.add(source);
        source.onended = () => {
            activeAudioSources.delete(source);
        };

        return audioBuffer.duration;
    } catch (error) {
        console.error("Failed to play audio:", error);
        return 0;
    }
};


// Decodes base64 string to a Uint8Array.
export function decode(base64: string): Uint8Array {
  if (!base64) return new Uint8Array(0);
  try {
    const binaryString = atob(base64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes;
  } catch (e) {
      console.error("Failed to decode base64 string", e);
      return new Uint8Array(0);
  }
}

// Decodes raw PCM audio data into an AudioBuffer.
export async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  
  if (frameCount <= 0) {
      // Return a silent 1-frame buffer to prevent crash if data is empty
      return ctx.createBuffer(numChannels, 1, sampleRate);
  }

  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

// Encodes a Uint8Array to a base64 string.
export function encode(bytes: Uint8Array): string {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}
