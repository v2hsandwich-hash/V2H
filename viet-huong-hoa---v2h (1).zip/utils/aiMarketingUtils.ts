import { PastOrderType, UserData, MenuItemType, Promotion } from '../types';

const PROMOTION_COOLDOWN_MS = 12 * 60 * 60 * 1000; // 12 hours
const LAPSED_USER_DAYS = 14;

interface UserBehavior {
    lastOrderDate: Date | null;
    isLapsed: boolean;
    favoriteItemId: string | null;
    orderCount: number;
    mostCommonOrderHour: number | null;
}

// 1. Analyze Behavior
const analyzeUserBehavior = (phone: string): UserBehavior => {
    const allHistories = JSON.parse(localStorage.getItem('orderHistories') || '{}');
    const userHistory: PastOrderType[] = allHistories[phone] || [];

    if (userHistory.length === 0) {
        return { lastOrderDate: null, isLapsed: false, favoriteItemId: null, orderCount: 0, mostCommonOrderHour: null };
    }

    const sortedHistory = userHistory.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    const lastOrderDate = new Date(sortedHistory[0].date);
    const isLapsed = (new Date().getTime() - lastOrderDate.getTime()) > (LAPSED_USER_DAYS * 24 * 60 * 60 * 1000);

    const itemCounts = new Map<string, number>();
    const hourCounts = new Map<number, number>();

    userHistory.forEach(order => {
        const orderHour = new Date(order.date).getHours();
        hourCounts.set(orderHour, (hourCounts.get(orderHour) || 0) + 1);
        order.items.forEach(item => {
            itemCounts.set(item.menuItem.id, (itemCounts.get(item.menuItem.id) || 0) + item.quantity);
        });
    });

    const favoriteItemId = [...itemCounts.entries()].sort((a, b) => b[1] - a[1])[0]?.[0] || null;
    const mostCommonOrderHour = [...hourCounts.entries()].sort((a, b) => b[1] - a[1])[0]?.[0] || null;

    return {
        lastOrderDate,
        isLapsed,
        favoriteItemId,
        orderCount: userHistory.length,
        mostCommonOrderHour,
    };
};

// 2. Generate Promotion
export const generatePromotionForUser = (user: UserData, menuItems: Record<string, MenuItemType[]>): Promotion | null => {
    if (user.phone === 'guest') return null;

    // Frequency Capping Check
    const lastPromotionTimestamps = JSON.parse(localStorage.getItem('lastPromotionShown') || '{}');
    const lastShown = lastPromotionTimestamps[user.phone];
    if (lastShown && (new Date().getTime() - lastShown) < PROMOTION_COOLDOWN_MS) {
        return null; 
    }

    const behavior = analyzeUserBehavior(user.phone);
    const allItems = Object.values(menuItems).flat();
    const menuMap = new Map(allItems.map(i => [i.id, i]));

    // --- Promotion Scenarios ---
    
    // Scenario 1: Lapsed User
    if (behavior.isLapsed) {
        return {
            id: 'welcome-back-20',
            title: 'Chúng tôi nhớ bạn, ' + user.fullName.split(' ').pop() + '!',
            description: 'Hãy quay lại và thưởng thức những món ăn lành mạnh. Giảm giá 20% cho món ăn bất kỳ trong đơn hàng tiếp theo của bạn!',
            cta: 'Đặt món ngay!',
            type: 'welcome_back',
            discountPercentage: 20,
            image: 'https://images.unsplash.com/photo-1576866209830-589e1bfd40d6?w=400&h=300&fit=crop',
            expiresInSeconds: 3 * 24 * 60 * 60, // 3 days
        };
    }

    // Scenario 2: Favorite Item Offer
    if (behavior.favoriteItemId && behavior.orderCount > 2) {
        const favItem = menuMap.get(behavior.favoriteItemId);
        if (favItem) {
            return {
                id: `fav-item-${favItem.id}`,
                title: 'Ưu đãi dành riêng cho bạn!',
                description: `Có vẻ bạn rất thích ${favItem.name}. Giảm ngay 15% cho món này trong lần đặt tiếp theo!`,
                cta: `Thêm ${favItem.name} vào giỏ`,
                type: 'item_discount',
                targetItemId: favItem.id,
                discountPercentage: 15,
                image: favItem.image,
                expiresInSeconds: 24 * 60 * 60, // 1 day
            };
        }
    }

    // Scenario 3: Time-based Offer
    const currentHour = new Date().getHours();
    if (behavior.mostCommonOrderHour !== null && Math.abs(currentHour - behavior.mostCommonOrderHour) <= 1) {
        const potentialItems = allItems.filter(i => (i.calories > 400 && i.id !== behavior.favoriteItemId));
        const targetItem = potentialItems[Math.floor(Math.random() * potentialItems.length)];
        if (targetItem) {
             return {
                id: `time-based-${targetItem.id}`,
                title: 'Đến giờ ăn rồi!',
                description: `Chỉ trong 1 giờ tới, giảm 10% cho món ${targetItem.name} đầy năng lượng!`,
                cta: 'Đặt ngay kẻo lỡ!',
                type: 'item_discount',
                targetItemId: targetItem.id,
                discountPercentage: 10,
                image: targetItem.image,
                expiresInSeconds: 60 * 60, // 1 hour
            };
        }
    }
    
    return null;
};

// 3. Mark promotion as shown
export const markPromotionAsShown = (phone: string) => {
    const lastPromotionTimestamps = JSON.parse(localStorage.getItem('lastPromotionShown') || '{}');
    lastPromotionTimestamps[phone] = new Date().getTime();
    localStorage.setItem('lastPromotionShown', JSON.stringify(lastPromotionTimestamps));
};
