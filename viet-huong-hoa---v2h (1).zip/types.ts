
export type RatingMap = Record<string, number>;

export interface CommunityRating {
    totalRating: number;
    count: number;
}
export type CommunityRatingMap = Record<string, CommunityRating>;
import React from 'react';

export type Language = 'vi' | 'en' | 'zh' | 'ja' | 'ko' | 'hi';

export interface LabValues {
  glucose: string;
  hba1c: string;
  uricAcid: string;
  ure: string;
  creatinine: string;
  cholesterol: string;
  triglyceride: string;
  systolicBP: string;
  diastolicBP: string;
  albumin: string;
  protein: string;
}

export type NutritionGoal = 'office' | 'gym' | 'medical' | 'eat_clean' | 'obese' | 'underweight';

export type LoyaltyTier = 'Đồng' | 'Bạc' | 'Vàng' | 'Kim Cương';

export interface UserData {
  fullName: string;
  phone: string;
  birthYear: string;
  gender: 'male' | 'female' | 'other';
  weight: string;
  height: string;
  nutritionGoal: NutritionGoal;
  medicalConditions: string;
  labValues: LabValues;
  avatar?: string;
  loyaltyPoints: number;
  loyaltyTier: LoyaltyTier;
  achievements: string[]; // e.g., ['first_order', 'master_planner']
}

export interface AnalysisResult {
  bmi: {
    value: number;
    category: string;
  };
  energyNeeds: {
    calories: number;
  };
  healthAnalysis: string;
  recommendations: string[];
  macroDistribution: {
    carbs: number;
    protein: number;
    fat: number;
  };
  foodsToAvoid: string[];
}

export interface NutritionInfo {
  calories: number;
  carbs: number; // g
  protein: number; // g
  fat: number; // g
}

export interface CustomizationOption {
    id: string;
    name: string;
    priceChange: number;
    nutritionChange?: Partial<NutritionInfo>;
}

export interface Customization {
    id: string;
    name: string;
    type: 'single' | 'multiple';
    options: CustomizationOption[];
}

export interface MenuItemType extends NutritionInfo {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  customizations?: Customization[];
  stock?: number;
  ingredientCost?: number;
  // New fields for 2-level categorization
  category?: string;
  subcategory?: string;
}

export interface SelectedOption {
    customizationId: string;
    optionId: string;
}

export interface OrderItemType {
    id: string; // Unique ID for this order item instance
    menuItem: MenuItemType;
    quantity: number;
    selectedOptions: SelectedOption[];
    totalPrice: number;
    totalNutrition: NutritionInfo;
}

export enum MealType {
  Breakfast = "Bữa sáng",
  MorningSnack = "Bữa phụ sáng",
  Lunch = "Bữa trưa",
  AfternoonSnack = "Bữa phụ chiều",
  Dinner = "Bữa tối",
  EveningSnack = "Bữa phụ tối",
}


export enum AlertLevel {
  Green = "green",
  Yellow = "yellow",
  Red = "red",
}

// --- START: Delivery & Checkout Types ---
export interface DeliveryInfo {
    recipientName: string;
    recipientPhone: string;
    address: string;
    deliveryTime: string;
    notes: string;
}

export type CheckoutType = 'dine-in' | 'delivery';

export interface PastOrderType {
  id: number;
  date: string; // ISO string
  items: OrderItemType[];
  totalPrice: number;
  checkoutType: CheckoutType;
  deliveryInfo?: DeliveryInfo;
  userPhone?: string;
}
// --- END: Delivery & Checkout Types ---

export type DayOfWeek = 'Thứ Hai' | 'Thứ Ba' | 'Thứ Tư' | 'Thứ Năm' | 'Thứ Sáu' | 'Thứ Bảy' | 'Chủ Nhật';
export const DAYS_OF_WEEK: DayOfWeek[] = ['Thứ Hai', 'Thứ Ba', 'Thứ Tư', 'Thứ Năm', 'Thứ Sáu', 'Thứ Bảy', 'Chủ Nhật'];
export const PLANNER_MEAL_TYPES: MealType[] = [MealType.Breakfast, MealType.MorningSnack, MealType.Lunch, MealType.AfternoonSnack, MealType.Dinner, MealType.EveningSnack];


export interface DailyPlan {
    [mealType: string]: OrderItemType | null;
}

export interface WeeklyMealPlan {
    [day: string]: DailyPlan;
}

export type AIPlanMenuItem = {
    id: string;
    name: string;
    calories: number;
    carbs: number;
    protein: number;
    fat: number;
    price: number;
};

export type AIPlanResponse = {
    [day in DayOfWeek]: {
        [meal in MealType]: AIPlanMenuItem | null;
    };
};

export enum RecommendationLevel {
  GoodForYou = "Tốt cho bạn",
  Suitable = "Phù hợp",
  Consider = "Cân nhắc",
  Limit = "Hạn chế",
}

// Chatbot types
export interface ChatMessage {
  sender: 'user' | 'bot';
  text: string;
}

// Gamification Types
export interface Achievement {
    id: string;
    name: string;
    description: string;
    icon: React.FC<{ className?: string }>;
}

export interface LeaderboardUser {
    rank: number;
    name: string;
    avatar: string;
    points: number;
}

// --- START: Meal Package Types ---
export type MenuPackageCategory = 'Hỗ trợ tiểu đường' | 'Kiểm soát cân nặng' | 'Eat Clean' | 'Tình Yêu' | 'Hỗ trợ chuyên biệt';

export interface MenuPackage {
    id: string;
    name: string;
    description: string;
    price: number; // Discounted total price
    originalPrice: number; // Sum of individual item prices
    image: string;
    itemIds: string[];
    totalNutrition: NutritionInfo;
    category: MenuPackageCategory;
}
// --- END: Meal Package Types ---

// --- START: Dashboard Types ---
export type Period = 'day' | 'week' | 'month';

export interface ChartDataPoint {
    label: string;
    value: number;
}

export interface DashboardData {
    totalRevenue: number;
    netProfit: number;
    returningCustomerRate: number;
    bestSeller?: { name: string; quantity: number };
    revenueChartData: ChartDataPoint[];
    profitAnalysis: { revenue: number; cost: number };
    revenueByCategory: { name: MealType; value: number }[];
    topProducts: {
        id: string;
        name: string;
        image: string;
        quantity: number;
    }[];
}
// --- END: Dashboard Types ---
// --- START: AI Marketing Types ---
export interface Promotion {
    id: string; 
    title: string;
    description: string;
    cta: string; 
    type: 'item_discount' | 'combo_offer' | 'welcome_back';
    targetItemId?: string; 
    discountPercentage?: number;
    expiresInSeconds?: number;
    image?: string;
}
// --- END: AI Marketing Types ---

export interface DirectionsResult {
    directionsText: string;
    mapUrl?: string;
}
