
import React, { useState, useEffect } from 'react';
import { UserInfoForm } from './components/UserInfoForm';
import { AnalysisReport } from './components/AnalysisReport';
import { Menu } from './components/Menu';
import { NutritionTracker } from './components/NutritionTracker';
import { OrderSummary } from './components/OrderSummary';
import { OrderHistory } from './components/OrderHistory';
import { MealPlanner } from './components/MealPlanner';
import { Leaderboard } from './components/Leaderboard';
import { AchievementsModal } from './components/AchievementsModal';
import { CustomerProfile } from './components/CustomerProfile';
import { getNutritionAnalysis, generateAvatar, generateSpeech } from './services/geminiService';
import { UserData, AnalysisResult, OrderItemType, PastOrderType, WeeklyMealPlan, LoyaltyTier, LabValues, MenuItemType, RecommendationLevel, MealType, DeliveryInfo, CheckoutType, Promotion, Language } from './types';
import { UserIcon, HistoryIcon, CalendarIcon, SpinnerIcon, MedalIcon, ChatBubbleIcon, TrophyIcon, UsersIcon, ChartIcon, LockClosedIcon, LocationMarkerIcon, PhoneIcon, BuildingStorefrontIcon, HomeIcon, IdentificationIcon, MapPinIcon, ClockIcon, PencilSquareIcon, CogIcon, ClipboardDocumentListIcon } from './components/Icons';
import { Chatbot } from './components/Chatbot';
import { MapModal } from './components/MapModal';
import { NUTRITION_GOAL_OPTIONS, MENU_ITEMS, TRANSLATIONS } from './constants';
import { SplashScreen } from './components/SplashScreen';
import { playAudio, stopAllAudio } from './utils/audioUtils';
import { AdminPanel } from './components/AdminPanel';
import { AIMarketingEngine } from './components/AIMarketingEngine';
import { PromotionModal } from './components/PromotionModal';
import { markPromotionAsShown } from './utils/aiMarketingUtils';

type AppState = 'SPLASH' | 'FORM' | 'ANALYZING' | 'REPORT' | 'MENU' | 'CHECKOUT' |'ORDER_COMPLETE' | 'HISTORY' | 'MEAL_PLAN' | 'LEADERBOARD' | 'ADMIN' | 'PROFILE';

const LOYALTY_TIERS: Record<LoyaltyTier, { minPoints: number; color: string; nextTier?: LoyaltyTier, nextTierPoints?: number }> = {
    'Đồng': { minPoints: 0, color: 'text-yellow-600', nextTier: 'Bạc', nextTierPoints: 100 },
    'Bạc': { minPoints: 100, color: 'text-gray-400', nextTier: 'Vàng', nextTierPoints: 500 },
    'Vàng': { minPoints: 500, color: 'text-yellow-400', nextTier: 'Kim Cương', nextTierPoints: 2000 },
    'Kim Cương': { minPoints: 2000, color: 'text-cyan-400' },
};

const LS_USERS = 'allUsersData';
const LS_CURRENT_USER_PHONE = 'currentUserPhone';
const LS_ANALYSES = 'analysisResults';
const LS_HISTORIES = 'orderHistories';
const LS_PLANS = 'weeklyMealPlans';
const LS_USER_RATINGS = 'userRatingsCollection';
const LS_MENU_ITEMS = 'v2h_menu_items';
const LS_HEALTH_SNAPSHOTS = 'healthSnapshots';

const emptyLabValues: LabValues = {
  glucose: '', hba1c: '', uricAcid: '', ure: '', creatinine: '',
  cholesterol: '', triglyceride: '', systolicBP: '', diastolicBP: '',
  albumin: '', protein: ''
};

const guestUserData: UserData = {
  fullName: 'Khách',
  phone: 'guest',
  birthYear: '2000',
  gender: 'other',
  weight: '60',
  height: '170',
  nutritionGoal: 'eat_clean',
  medicalConditions: '',
  labValues: emptyLabValues,
  avatar: undefined,
  loyaltyPoints: 0,
  loyaltyTier: 'Đồng',
  achievements: [],
};

const defaultAnalysisResult: AnalysisResult = {
  bmi: { value: 20.76, category: 'Bình thường' },
  energyNeeds: { calories: 2000 },
  healthAnalysis: 'Đây là phân tích dinh dưỡng mặc định. Vui lòng cung cấp thông tin cá nhân của bạn để nhận được các khuyến nghị chính xác hơn.',
  recommendations: ['Uống đủ nước.', 'Ăn nhiều rau xanh và trái cây.', 'Hạn chế thực phẩm chế biến sẵn.', 'Tập thể dục đều đặn.'],
  macroDistribution: { carbs: 50, protein: 20, fat: 30 },
  foodsToAvoid: [],
};

// --- Storage Helper to Handle QuotaExceededError ---
const safeSetLocalStorage = (key: string, value: any) => {
    try {
        localStorage.setItem(key, JSON.stringify(value));
    } catch (error: any) {
        if (error.name === 'QuotaExceededError' || error.name === 'NS_ERROR_DOM_QUOTA_REACHED') {
            console.warn(`LocalStorage quota exceeded for ${key}. Attempting cleanup...`);
            
            if (key === LS_USERS) {
                // Strategy: Remove avatars (large strings) to save space
                const cleanValue = { ...value };
                Object.keys(cleanValue).forEach(k => {
                    delete cleanValue[k].avatar;
                });
                try {
                    localStorage.setItem(key, JSON.stringify(cleanValue));
                    console.log("Recovered LS_USERS by removing avatars.");
                    return;
                } catch (e) { console.error("Recovery failed for LS_USERS"); }
            } else if (key === LS_HISTORIES) {
                // Strategy: Trim old history
                const cleanValue = { ...value };
                if (cleanValue['all_orders'] && Array.isArray(cleanValue['all_orders'])) {
                    cleanValue['all_orders'] = cleanValue['all_orders'].slice(-10); // Keep last 10 global
                }
                if (cleanValue['guest_orders']) {
                    cleanValue['guest_orders'] = cleanValue['guest_orders'].slice(-5);
                }
                Object.keys(cleanValue).forEach(k => {
                    if (Array.isArray(cleanValue[k])) cleanValue[k] = cleanValue[k].slice(-5); // Keep last 5 per user
                });
                try {
                    localStorage.setItem(key, JSON.stringify(cleanValue));
                    console.log("Recovered LS_HISTORIES by trimming.");
                    return;
                } catch (e) { console.error("Recovery failed for LS_HISTORIES"); }
            } else if (key === LS_HEALTH_SNAPSHOTS) {
                 const cleanValue = { ...value };
                 Object.keys(cleanValue).forEach(k => {
                     if (Array.isArray(cleanValue[k])) cleanValue[k] = cleanValue[k].slice(-5);
                 });
                 try {
                    localStorage.setItem(key, JSON.stringify(cleanValue));
                    return;
                 } catch (e) {}
            }
            alert("Không thể lưu dữ liệu do bộ nhớ đầy. Vui lòng xóa bớt dữ liệu duyệt web hoặc một số hình ảnh sẽ không được lưu.");
        } else {
            console.error("LocalStorage Error:", error);
        }
    }
};

const generateOrderPDF = (order: PastOrderType, user: UserData) => {
    const printableContent = `
        <html>
            <head>
                <title>Hóa đơn V2H - Đơn hàng #${order.id}</title>
                <style>
                    body { font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; margin: 20px; font-size: 12px; color: #333; }
                    .container { max-width: 800px; margin: auto; padding: 20px; border: 1px solid #eee; box-shadow: 0 0 10px rgba(0,0,0,.15); }
                    .header { text-align: center; margin-bottom: 20px; }
                    .header h1 { margin: 0; font-size: 24px; color: #06b6d4; }
                    .header p { margin: 2px 0; }
                    .details { display: flex; justify-content: space-between; margin-bottom: 20px; }
                    .details div { width: 48%; }
                    .details h2, .delivery h2 { font-size: 14px; color: #06b6d4; border-bottom: 1px solid #eee; padding-bottom: 5px; margin-top: 0; }
                    table { width: 100%; border-collapse: collapse; }
                    th, td { border-bottom: 1px solid #ddd; padding: 8px; text-align: left; }
                    th { background-color: #f2f2f2; font-size: 11px; text-transform: uppercase; }
                    .total-row { font-weight: bold; font-size: 14px; }
                    .total-row td { border-bottom: 2px solid #333; }
                    .footer { text-align: center; margin-top: 30px; font-size: 10px; color: #777; }
                    .delivery { margin-top: 20px; background-color: #f9f9f9; padding: 15px; border-radius: 5px; }
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="header">
                        <h1>Việt Hương Hoa - Fastfood, Mealbox & Detox</h1>
                        <p>123 Đường Sức Khỏe, Quận Dinh Dưỡng, TP. Vui Vẻ</p>
                        <p>Hotline: 0784.111.116</p>
                    </div>
                    <div class="details">
                        <div>
                            <h2>Thông tin khách hàng</h2>
                            <p><strong>Tên:</strong> ${user.fullName}</p>
                            <p><strong>SĐT:</strong> ${user.phone}</p>
                        </div>
                        <div>
                            <h2>Chi tiết đơn hàng</h2>
                            <p><strong>Mã đơn:</strong> #${order.id}</p>
                            <p><strong>Ngày:</strong> ${new Date(order.date).toLocaleString('vi-VN')}</p>
                            <p><strong>Loại:</strong> ${order.checkoutType === 'dine-in' ? 'Ăn tại quán' : 'Giao hàng'}</p>
                        </div>
                    </div>

                    ${order.checkoutType === 'delivery' && order.deliveryInfo ? `
                    <div class="delivery">
                        <h2>Thông tin giao hàng</h2>
                        <p><strong>Người nhận:</strong> ${order.deliveryInfo.recipientName}</p>
                        <p><strong>SĐT nhận:</strong> ${order.deliveryInfo.recipientPhone}</p>
                        <p><strong>Địa chỉ:</strong> ${order.deliveryInfo.address}</p>
                        <p><strong>Thời gian mong muốn:</strong> ${order.deliveryInfo.deliveryTime || 'Sớm nhất có thể'}</p>
                        <p><strong>Ghi chú:</strong> ${order.deliveryInfo.notes || 'Không có'}</p>
                    </div>` : ''}

                    <h2 style="margin-top: 20px;">Danh sách món</h2>
                    <table>
                        <thead>
                            <tr>
                                <th>SL</th>
                                <th>Tên món</th>
                                <th>Tùy chọn</th>
                                <th style="text-align: right;">Giá</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${order.items.map(item => `
                                <tr>
                                    <td>${item.quantity}</td>
                                    <td>${item.menuItem.name}</td>
                                    <td>${item.selectedOptions.length > 0 ? item.selectedOptions.map(opt => {
                                        const customization = item.menuItem.customizations?.find(c => c.id === opt.customizationId);
                                        const option = customization?.options.find(o => o.id === opt.optionId);
                                        return `+ ${option?.name.split(' (')[0]}`;
                                    }).join('<br>') : '---'}</td>
                                    <td style="text-align: right;">${item.totalPrice.toLocaleString()}đ</td>
                                </tr>
                            `).join('')}
                            <tr class="total-row">
                                <td colspan="3">Tổng cộng</td>
                                <td style="text-align: right;">${order.totalPrice.toLocaleString()}đ</td>
                            </tr>
                        </tbody>
                    </table>
                    <div class="footer">
                        <p>Cảm ơn quý khách đã tin tưởng V2H! Chúc quý khách ngon miệng!</p>
                    </div>
                </div>
            </body>
        </html>
    `;
    const printWindow = window.open('', '_blank');
    if (printWindow) {
        printWindow.document.write(printableContent);
        printWindow.document.close();
        printWindow.focus();
        printWindow.print();
    }
};


const loadInitialState = () => {
    try {
        const currentUserPhone = localStorage.getItem(LS_CURRENT_USER_PHONE);
        const allUsersData = JSON.parse(localStorage.getItem(LS_USERS) || '{}');
        const analysisResults = JSON.parse(localStorage.getItem(LS_ANALYSES) || '{}');

        if (currentUserPhone && allUsersData[currentUserPhone] && analysisResults[currentUserPhone]) {
            const userData: UserData = allUsersData[currentUserPhone];
            const analysisResult: AnalysisResult = analysisResults[currentUserPhone];
            
            return {
                initialState: 'MENU' as AppState,
                initialUserData: userData,
                initialAnalysis: analysisResult
            };
        }
    } catch (error) {
        console.error("Failed to load initial state from localStorage:", error);
    }

    return {
        initialState: 'SPLASH' as AppState,
        initialUserData: null,
        initialAnalysis: null
    };
};

const initializeMenuItems = (): Record<string, MenuItemType[]> => {
    try {
        const savedMenu = localStorage.getItem(LS_MENU_ITEMS);
        if (savedMenu) {
            return JSON.parse(savedMenu);
        }
    } catch (e) {
        console.error("Could not parse menu from localStorage", e);
    }
    // If nothing in localStorage, initialize from constants and add new fields
    const initializedMenu: Record<string, MenuItemType[]> = {};
    for (const mealType in MENU_ITEMS) {
        initializedMenu[mealType] = MENU_ITEMS[mealType].map(item => ({
            ...item,
            stock: item.stock ?? 100, // Default stock
            ingredientCost: item.ingredientCost ?? item.price * 0.3, // Estimate cost as 30% of price
        }));
    }
    return initializedMenu;
};

const playSpeech = async (text: string) => {
    try {
        const audioData = await generateSpeech(text);
        await playAudio(audioData);
    } catch (error) {
        console.error("Failed to play speech:", error);
    }
};

interface CheckoutScreenProps {
  userData: UserData;
  selectedItems: OrderItemType[];
  onConfirm: (details: { checkoutType: CheckoutType; deliveryInfo?: DeliveryInfo }) => void;
  onBack: () => void;
  language: Language;
}

const CheckoutScreen: React.FC<CheckoutScreenProps> = ({ userData, selectedItems, onConfirm, onBack, language }) => {
    const [option, setOption] = useState<CheckoutType | null>(null);
    const [deliveryInfo, setDeliveryInfo] = useState<DeliveryInfo>({
        recipientName: userData.fullName || '',
        recipientPhone: userData.phone !== 'guest' ? userData.phone : '',
        address: '',
        deliveryTime: '',
        notes: '',
    });
    const t = TRANSLATIONS[language];

    useEffect(() => {
        if (option === 'dine-in') {
            playSpeech(t['dine_in_instruction']);
        } else if (option === 'delivery') {
            playSpeech(t['delivery_instruction']);
        }
    }, [option, language]);

    const handleDeliveryInfoChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setDeliveryInfo(prev => ({ ...prev, [name]: value }));
    };
    
    const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      if (option === 'delivery') {
        if (!deliveryInfo.recipientName || !deliveryInfo.recipientPhone || !deliveryInfo.address) {
          alert(t['recipient_info'] + ' ' + t['details']); // Simple validation alert
          return;
        }
        onConfirm({ checkoutType: 'delivery', deliveryInfo });
      } else if (option === 'dine-in') {
        onConfirm({ checkoutType: 'dine-in' });
      }
    };

    const total = selectedItems.reduce((sum, item) => sum + item.totalPrice, 0);

    const renderInput = (
      name: keyof DeliveryInfo,
      label: string,
      placeholder: string,
      Icon: React.FC<{ className?: string }>,
      type = 'text',
      required = false
    ) => (
        <div className="relative group">
            <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                <Icon className="h-5 w-5 text-cyan-500/70 group-hover:text-cyan-400 transition-colors" />
            </div>
            <input
                type={type}
                name={name}
                placeholder={placeholder}
                value={deliveryInfo[name]}
                onChange={handleDeliveryInfoChange}
                required={required}
                className="w-full bg-black/40 backdrop-blur-md p-3 pl-10 rounded-xl border border-gray-700/50 focus:ring-2 focus:ring-cyan-500/50 focus:border-cyan-500 text-white placeholder-gray-500 transition-all shadow-inner"
            />
        </div>
    );


    return (
        <div className="max-w-2xl mx-auto p-8 bg-gray-900/60 backdrop-blur-2xl rounded-3xl shadow-2xl border border-cyan-500/20 animate-fade-in relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/5 via-transparent to-purple-500/5 pointer-events-none"></div>
            <h2 className="text-3xl font-black text-center text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 to-blue-300 mb-8 relative z-10">{t['confirm_order']}</h2>

            {!option ? (
                <div className="space-y-6 relative z-10">
                    <p className="text-center text-cyan-200/80 uppercase tracking-widest text-xs font-bold">{t['payment_method']}</p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                        <button onClick={() => setOption('dine-in')} className="flex flex-col items-center gap-4 p-8 bg-gray-800/40 rounded-2xl border border-gray-700 hover:border-cyan-500 hover:bg-cyan-900/20 transition-all group hover:scale-[1.02] shadow-lg hover:shadow-cyan-500/20">
                            <div className="p-4 rounded-full bg-cyan-900/30 group-hover:bg-cyan-500/20 transition-colors">
                                <BuildingStorefrontIcon className="w-10 h-10 text-cyan-400 group-hover:text-cyan-300" />
                            </div>
                            <span className="text-lg font-bold text-white group-hover:text-cyan-300">{t['dine_in']}</span>
                        </button>
                        <button onClick={() => setOption('delivery')} className="flex flex-col items-center gap-4 p-8 bg-gray-800/40 rounded-2xl border border-gray-700 hover:border-purple-500 hover:bg-purple-900/20 transition-all group hover:scale-[1.02] shadow-lg hover:shadow-purple-500/20">
                            <div className="p-4 rounded-full bg-purple-900/30 group-hover:bg-purple-500/20 transition-colors">
                                <HomeIcon className="w-10 h-10 text-purple-400 group-hover:text-purple-300" />
                            </div>
                            <span className="text-lg font-bold text-white group-hover:text-purple-300">{t['delivery']}</span>
                        </button>
                    </div>
                </div>
            ) : (
                <form onSubmit={handleSubmit} className="relative z-10">
                    {option === 'delivery' && (
                        <div className="space-y-5 mb-8 animate-fade-in">
                           <h3 className="text-lg font-bold text-cyan-400 border-b border-gray-800 pb-3 mb-5 uppercase tracking-wide">{t['recipient_info']}</h3>
                           {renderInput('recipientName', t['recipient_name'], t['recipient_name'], IdentificationIcon, 'text', true)}
                           {renderInput('recipientPhone', t['phone'], t['phone'], PhoneIcon, 'tel', true)}
                           {renderInput('address', t['address'], t['address'], MapPinIcon, 'text', true)}
                           {renderInput('deliveryTime', t['delivery_time'], t['delivery_time'], ClockIcon, 'text')}
                           <div className="relative group">
                                <div className="pointer-events-none absolute top-3 left-0 flex items-center pl-3">
                                    <PencilSquareIcon className="h-5 w-5 text-cyan-500/70 group-hover:text-cyan-400" />
                                </div>
                                <textarea
                                    name="notes"
                                    placeholder={t['notes']}
                                    value={deliveryInfo.notes}
                                    onChange={handleDeliveryInfoChange}
                                    className="w-full bg-black/40 backdrop-blur-md p-3 pl-10 rounded-xl border border-gray-700/50 focus:ring-2 focus:ring-cyan-500/50 focus:border-cyan-500 h-28 resize-none text-white placeholder-gray-500 transition-all shadow-inner"
                                />
                            </div>
                        </div>
                    )}

                    {option === 'dine-in' && (
                        <div className="text-center p-8 bg-gradient-to-b from-gray-800/40 to-gray-900/40 rounded-3xl mb-8 animate-fade-in border border-cyan-500/30 shadow-[0_0_30px_rgba(6,182,212,0.1)] relative overflow-hidden">
                            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-cyan-500 to-transparent opacity-50"></div>
                            <div className="w-24 h-24 bg-cyan-900/20 rounded-full flex items-center justify-center mx-auto mb-6 border border-cyan-500/40 shadow-[0_0_30px_rgba(6,182,212,0.2)] animate-pulse-cyan">
                                <BuildingStorefrontIcon className="w-12 h-12 text-cyan-300" />
                            </div>
                            <h3 className="text-2xl font-bold text-white mb-3 tracking-wide font-['Orbitron']">
                                {t['dine_in']}
                            </h3>
                            <div className="w-12 h-1 bg-cyan-500 mx-auto mb-5 rounded-full shadow-[0_0_10px_rgba(6,182,212,0.8)]"></div>
                            <p className="text-cyan-100 leading-relaxed font-light text-lg">
                                {t['dine_in_instruction']}
                            </p>
                        </div>
                    )}
                    
                    <div className="border-t border-gray-800 pt-6">
                        <div className="flex justify-between items-center text-xl mb-6 bg-black/40 p-5 rounded-xl border border-gray-700/30">
                          <span className="font-bold text-gray-400 text-sm uppercase tracking-wider">{t['total']}:</span>
                          <span className="font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 to-blue-400 text-3xl font-['Orbitron']">{total.toLocaleString()}đ</span>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <button type="button" onClick={() => option ? setOption(null) : onBack()} className="w-full bg-gray-800 hover:bg-gray-700 text-gray-300 font-bold py-4 px-6 rounded-xl transition-all border border-gray-700">{t['back']}</button>
                            <button type="submit" className="w-full bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold py-4 px-6 rounded-xl shadow-[0_0_20px_rgba(6,182,212,0.3)] transition-all hover:scale-[1.02] active:scale-95 border border-cyan-400/30">
                                {t['confirm_print']}
                            </button>
                        </div>
                    </div>
                </form>
            )}
        </div>
    );
};

interface OrderCompleteScreenProps {
  onBackToMenu: () => void;
  onLogout: () => void;
  language: Language;
  checkoutType: CheckoutType;
}

const OrderCompleteScreen: React.FC<OrderCompleteScreenProps> = ({ onBackToMenu, onLogout, language, checkoutType }) => {
    const t = TRANSLATIONS[language];
    
    useEffect(() => {
        const message = checkoutType === 'delivery' ? t['delivery_success_message'] : t['thank_you_order'];
        playSpeech(message);
        const inactivityTimer = setTimeout(onLogout, 60000); // 60 seconds logout
        return () => clearTimeout(inactivityTimer);
    }, [onLogout, checkoutType, language]);
    
    return (
        <div className="relative text-center max-w-2xl mx-auto bg-gray-900/60 backdrop-blur-2xl p-12 rounded-3xl border border-cyan-500/30 animate-fade-in shadow-[0_0_50px_rgba(6,182,212,0.15)] overflow-hidden">
            <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10 pointer-events-none"></div>
            <div className="w-24 h-24 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-6 border border-green-500/50 shadow-[0_0_30px_rgba(34,197,94,0.3)] animate-pulse">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-green-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
            </div>
            <h2 className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-green-300 to-emerald-500 mb-6 font-['Orbitron']">{t['order_success']}</h2>
            <p className="text-cyan-100 mb-10 text-lg leading-relaxed font-light">
                {checkoutType === 'delivery' ? t['delivery_success_message'] : t['thank_you_order']}
            </p>
            <div className="flex justify-center gap-6">
                <button onClick={onBackToMenu} className="bg-cyan-600 hover:bg-cyan-500 text-white font-bold py-3 px-8 rounded-xl shadow-lg transition-all hover:scale-105">{t['continue_ordering']}</button>
                <button onClick={onLogout} className="bg-gray-800 hover:bg-gray-700 text-gray-300 font-bold py-3 px-8 rounded-xl transition-all border border-gray-700 hover:border-gray-500">{t['back_home']}</button>
            </div>
        </div>
    );
};


const App: React.FC = () => {
  const { initialState, initialUserData, initialAnalysis } = loadInitialState();
  
  const [appState, setAppState] = useState<AppState>(initialState);
  const [userData, setUserData] = useState<UserData | null>(initialUserData);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(initialAnalysis);
  const [selectedItems, setSelectedItems] = useState<OrderItemType[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [isAvatarGenerating, setIsAvatarGenerating] = useState(false);
  const [isChatbotOpen, setIsChatbotOpen] = useState(false);
  const [isAchievementsModalOpen, setIsAchievementsModalOpen] = useState(false);
  const [isMapModalOpen, setIsMapModalOpen] = useState(false);
  const [menuItems, setMenuItems] = useState<Record<string, MenuItemType[]>>(initializeMenuItems);
  const [activePromotion, setActivePromotion] = useState<Promotion | null>(null);
  const [currentLanguage, setCurrentLanguage] = useState<Language>('vi');
  const [isMenuHologramActive, setIsMenuHologramActive] = useState(false);
  const [lastCheckoutType, setLastCheckoutType] = useState<CheckoutType>('dine-in');

  const t = (key: string) => {
      return TRANSLATIONS[currentLanguage][key] || key;
  };

  useEffect(() => {
    try {
        safeSetLocalStorage(LS_MENU_ITEMS, menuItems);
    } catch (e) {
        console.error("Could not save menu to localStorage", e);
    }
  }, [menuItems]);


  const handleFormSubmit = async (data: UserData) => {
    setAppState('ANALYZING');
    setError(null);
    const phone = data.phone;
    if (!phone) {
        setError("Phone is required.");
        setAppState('FORM');
        return;
    }

    try {
      const result = await getNutritionAnalysis(data, currentLanguage);
      let currentUserData = { ...data };
      setUserData(currentUserData);
      setAnalysisResult(result);
      
      localStorage.setItem(LS_CURRENT_USER_PHONE, phone);

      const allUsers = JSON.parse(localStorage.getItem(LS_USERS) || '{}');
      allUsers[phone] = currentUserData;
      safeSetLocalStorage(LS_USERS, allUsers);
      
      const allAnalyses = JSON.parse(localStorage.getItem(LS_ANALYSES) || '{}');
      allAnalyses[phone] = result;
      safeSetLocalStorage(LS_ANALYSES, allAnalyses);

      // --- SAVE HEALTH SNAPSHOT TO HISTORY ---
      // This ensures we have a real historical record for the Profile Chart
      const healthSnapshots = JSON.parse(localStorage.getItem(LS_HEALTH_SNAPSHOTS) || '{}');
      const userSnapshots = healthSnapshots[phone] || [];
      userSnapshots.push({
          date: new Date().toISOString(),
          labValues: data.labValues,
          weight: data.weight,
          height: data.height
      });
      healthSnapshots[phone] = userSnapshots;
      safeSetLocalStorage(LS_HEALTH_SNAPSHOTS, healthSnapshots);
      // ---------------------------------------
      
      setAppState('REPORT');
      
      // For TTS, we rely on the AI generated report which is already in target language
      const summaryText = `${t('hello')} ${data.fullName}. ${result.healthAnalysis} ${result.recommendations.slice(0, 2).join('. ')}`;
      playSpeech(summaryText);


      if (!currentUserData.avatar) {
          setIsAvatarGenerating(true);
          try {
              const avatarBase64 = await generateAvatar(currentUserData);
              const newData = { ...currentUserData, avatar: avatarBase64 };
              setUserData(newData);
              const updatedUsers = JSON.parse(localStorage.getItem(LS_USERS) || '{}');
              updatedUsers[phone] = newData;
              safeSetLocalStorage(LS_USERS, updatedUsers);
          } catch (avatarError) {
              console.error("Không thể tạo ảnh đại diện:", avatarError);
          } finally {
              setIsAvatarGenerating(false);
          }
      }
    } catch (err) {
      setError((err as Error).message);
      setAppState('FORM');
    }
  };

  const handleSkipToMenu = () => {
    setUserData(guestUserData);
    setAnalysisResult(defaultAnalysisResult);
    setAppState('MENU');
  };
  
  const handleApplyPromotion = (promotion: Promotion) => {
        if (promotion.type === 'item_discount' && promotion.targetItemId) {
            // FIX: Explicitly cast Object.values result to resolve 'unknown' type error in reduce
            const allItems = (Object.values(menuItems) as MenuItemType[][]).reduce<MenuItemType[]>((acc, val) => acc.concat(val), []);
            const targetItem = allItems.find(item => item.id === promotion.targetItemId);
            
            if (targetItem) {
                const discountedPrice = targetItem.price * (1 - (promotion.discountPercentage || 0) / 100);
                
                const promotionalOrderItem: OrderItemType = {
                    id: `${targetItem.id}-promo-${Date.now()}`,
                    menuItem: { ...targetItem, name: `${targetItem.name} (Khuyến mãi)` },
                    quantity: 1,
                    selectedOptions: [],
                    totalPrice: discountedPrice,
                    totalNutrition: { ...targetItem }
                };
                handleAddItem(promotionalOrderItem);
            }
        }
        alert(`Đã áp dụng khuyến mãi "${promotion.title}"!`);
        setActivePromotion(null);
    };
  
const introduceMenu = async (currentUser: UserData, currentAnalysis: AnalysisResult) => {
    try {
        const prompt = `Hãy giới thiệu thực đơn ngắn gọn cho người dùng tên ${currentUser.fullName} dựa trên phân tích sức khỏe: ${currentAnalysis.healthAnalysis}. Ngôn ngữ trả lời: "${currentLanguage}". Giữ ngắn gọn dưới 50 từ.`;
        
        // Use the Chatbot function which is exposed to generate speech text
        const speechText = await import('./services/geminiService').then(mod => mod.getChatbotResponse(prompt, [], menuItems, currentLanguage));
        
        // Filter out fallback error messages
        const fallbackMessages = [
            "Xin lỗi tôi không hiểu câu hỏi của bạn",
            "Xin lỗi tôi đang gặp sự cố nhỏ"
        ];

        if (fallbackMessages.some(msg => speechText.includes(msg))) {
            return;
        }
        
        await playSpeech(speechText);
    } catch (error) {
        console.error("Failed to generate menu introduction speech:", error);
    }
};

  const handleProceedToMenu = () => {
    if (userData && analysisResult) {
        // Don't await this so the UI transition is immediate
        introduceMenu(userData, analysisResult);
    }
    setAppState('MENU');
  };
  
  const handleAddItem = (item: OrderItemType) => {
    setSelectedItems(prev => [...prev, item]);
  };
  
  const handleRemoveItem = (orderItemId: string) => {
    setSelectedItems(prev => prev.filter(item => item.id !== orderItemId));
  };

  const awardAchievement = (achievementId: string) => {
    setUserData(prevUserData => {
        if (!prevUserData || prevUserData.achievements.includes(achievementId) || prevUserData.phone === 'guest') {
            return prevUserData;
        }
        const phone = prevUserData.phone;
        const updatedUserData = {
            ...prevUserData,
            achievements: [...prevUserData.achievements, achievementId],
        };
        const allUsers = JSON.parse(localStorage.getItem(LS_USERS) || '{}');
        allUsers[phone] = updatedUserData;
        safeSetLocalStorage(LS_USERS, allUsers);
        return updatedUserData;
    });
  };
  
  const handlePlaceOrder = () => {
    if (selectedItems.length > 0) {
        setAppState('CHECKOUT');
    }
  };

  const handleConfirmCheckout = (details: { checkoutType: CheckoutType; deliveryInfo?: DeliveryInfo }) => {
    if (!userData) return;
    
    setLastCheckoutType(details.checkoutType);
    const phone = userData.phone;

    if (phone === 'guest') {
        const tempOrder: PastOrderType = {
            id: Date.now(),
            date: new Date().toISOString(),
            items: selectedItems,
            totalPrice: selectedItems.reduce((sum, item) => sum + item.totalPrice, 0),
            userPhone: 'guest',
            ...details
        };
        generateOrderPDF(tempOrder, userData);
        
        // Save guest orders to a general history for analytics
        const allHistories = JSON.parse(localStorage.getItem(LS_HISTORIES) || '{}');
        const generalHistory = allHistories['guest_orders'] || [];
        generalHistory.push(tempOrder);
        allHistories['guest_orders'] = generalHistory;
        safeSetLocalStorage(LS_HISTORIES, allHistories);

        setSelectedItems([]);
        setAppState('ORDER_COMPLETE');
        return;
    }

    const totalPrice = selectedItems.reduce((sum, item) => sum + item.totalPrice, 0);
    const newOrder: PastOrderType = {
        id: Date.now(),
        date: new Date().toISOString(),
        items: selectedItems,
        totalPrice: totalPrice,
        userPhone: phone,
        ...details
    };
    
    generateOrderPDF(newOrder, userData);

    try {
        const allHistories = JSON.parse(localStorage.getItem(LS_HISTORIES) || '{}');
        const userHistory = allHistories[phone] || [];
        if (userHistory.length === 0) {
            awardAchievement('first_order');
        }
        userHistory.push(newOrder); // Add to specific user history
        allHistories[phone] = userHistory;
        
        // Also add to a general list for easier dashboard aggregation
        const generalHistory = allHistories['all_orders'] || [];
        generalHistory.push(newOrder);
        allHistories['all_orders'] = generalHistory;
        
        safeSetLocalStorage(LS_HISTORIES, allHistories);

        const pointsEarned = Math.floor(totalPrice / 10000);
        const newPoints = userData.loyaltyPoints + pointsEarned;
        let newTier = userData.loyaltyTier;
        if (LOYALTY_TIERS[newTier].nextTier && newPoints >= (LOYALTY_TIERS[newTier].nextTierPoints || Infinity)) {
            newTier = LOYALTY_TIERS[newTier].nextTier!;
        }
        const updatedUserData = { ...userData, loyaltyPoints: newPoints, loyaltyTier: newTier };
        setUserData(updatedUserData);

        const allUsers = JSON.parse(localStorage.getItem(LS_USERS) || '{}');
        allUsers[phone] = updatedUserData;
        safeSetLocalStorage(LS_USERS, allUsers);
    } catch (e) {
        console.error("Failed to save order history or update user data:", e);
    }
    
    setSelectedItems([]);
    setAppState('ORDER_COMPLETE');
  };

  const handleInactivityLogout = () => {
    // Soft reset for the next user, does not delete previous user's data
    localStorage.removeItem(LS_CURRENT_USER_PHONE); 
    
    setUserData(null);
    setAnalysisResult(null);
    setSelectedItems([]);
    setError(null);
    setAppState('SPLASH'); 
  };

  const handleSplashComplete = (language: Language) => {
    setCurrentLanguage(language);
    setAppState('FORM');
    // Play the introduction message in the selected language
    const introText = TRANSLATIONS[language]['form_intro_message'];
    playSpeech(introText);
  };

    const handleDismissPromotion = () => {
        setActivePromotion(null);
    };


  const handleViewHistory = () => { setAppState('HISTORY'); }
  const handleViewPlanner = () => { setAppState('MEAL_PLAN'); }
  const handleViewLeaderboard = () => { setAppState('LEADERBOARD'); }
  const handleBackToMenu = () => { setAppState('MENU'); }
  const handleViewReport = () => { setAppState('REPORT'); };
  const handleBackToForm = () => { setAppState('FORM'); };
  const handleViewProfile = () => { setAppState('PROFILE'); };
  
  const handleAddPlanToOrder = (plan: WeeklyMealPlan) => {
    const itemsFromPlan: OrderItemType[] = [];
    Object.values(plan).forEach(dailyPlan => {
        Object.values(dailyPlan).forEach(meal => {
            if (meal) {
                itemsFromPlan.push({ ...meal, id: `${meal.menuItem.id}-${Date.now()}-${Math.random()}` });
            }
        });
    });
    setSelectedItems(prev => [...prev, ...itemsFromPlan]);
    setAppState('MENU');
  };


  const renderContent = () => {
    switch (appState) {
      case 'SPLASH':
        return <SplashScreen onComplete={handleSplashComplete} />;
      case 'FORM':
      case 'ANALYZING':
        return <UserInfoForm onSubmit={handleFormSubmit} isLoading={appState === 'ANALYZING'} onSkip={handleSkipToMenu} language={currentLanguage} />;
      case 'REPORT':
        return analysisResult && userData && <AnalysisReport analysis={analysisResult} userData={userData} onProceed={handleProceedToMenu} onGoToPlanner={handleViewPlanner} onBackToForm={handleBackToForm} language={currentLanguage} />;
      case 'MENU':
        return analysisResult && userData && (
          <>
            <AIMarketingEngine 
                user={userData} 
                menuItems={menuItems}
                onGeneratePromotion={setActivePromotion}
            />
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className={`lg:col-span-2 ${isMenuHologramActive ? 'lg:col-span-3' : ''}`}>
                <Menu 
                    onAddItem={handleAddItem} 
                    analysis={analysisResult} 
                    userData={userData} 
                    menuItems={menuItems} 
                    language={currentLanguage} 
                    onHologramToggle={setIsMenuHologramActive}
                />
              </div>
              {!isMenuHologramActive && (
                  <div className="lg:col-span-1">
                    <div className="sticky top-28 flex flex-col gap-8 animate-fade-in-up" style={{ animationDelay: '0.2s' }}>
                      <NutritionTracker analysis={analysisResult} selectedItems={selectedItems} language={currentLanguage} />
                      <OrderSummary selectedItems={selectedItems} onRemoveItem={handleRemoveItem} onPlaceOrder={handlePlaceOrder} language={currentLanguage} />
                    </div>
                  </div>
              )}
            </div>
          </>
        );
      case 'CHECKOUT':
        return userData && <CheckoutScreen userData={userData} selectedItems={selectedItems} onConfirm={handleConfirmCheckout} onBack={handleBackToMenu} language={currentLanguage} />;
     case 'ORDER_COMPLETE':
        return <OrderCompleteScreen onBackToMenu={handleBackToMenu} onLogout={handleInactivityLogout} language={currentLanguage} checkoutType={lastCheckoutType} />;
      case 'HISTORY':
          return userData && <OrderHistory onBack={handleBackToMenu} currentUser={userData} language={currentLanguage} />;
      case 'MEAL_PLAN':
          return analysisResult && userData && <MealPlanner analysis={analysisResult} onBack={handleBackToMenu} onAddPlanToOrder={handleAddPlanToOrder} onAwardAchievement={awardAchievement} currentUser={userData} menuItems={menuItems} language={currentLanguage} />;
      case 'LEADERBOARD':
          return userData && <Leaderboard currentUser={userData} onBack={handleBackToMenu} language={currentLanguage} />;
      case 'ADMIN':
          return <AdminPanel menuItems={menuItems} setMenuItems={setMenuItems} onBack={handleBackToMenu} />;
      case 'PROFILE':
          return userData && <CustomerProfile userData={userData} orderHistory={JSON.parse(localStorage.getItem(LS_HISTORIES) || '{}')[userData.phone] || []} onBack={handleBackToMenu} language={currentLanguage} />;
      default:
        return <UserInfoForm onSubmit={handleFormSubmit} isLoading={appState === 'ANALYZING'} onSkip={handleSkipToMenu} language={currentLanguage} />;
    }
  };

  return (
    <div className="text-gray-200 min-h-screen font-sans selection:bg-cyan-500 selection:text-black">
        {/* Dynamic ambient background - keeping the original layers from index.html but adding a subtle overlay here for specific app depth */}
        <div className="absolute inset-0 z-0 opacity-20 pointer-events-none" style={{
                backgroundImage: 'radial-gradient(circle at top left, rgba(6, 182, 212, 0.15) 0%, transparent 40%), ' +
                                 'radial-gradient(circle at bottom right, rgba(168, 85, 247, 0.15) 0%, transparent 50%)',
            }}></div>
            
        <div className="relative z-10 container mx-auto px-4 py-6 md:py-8 max-w-7xl">
             <header className="flex flex-wrap justify-between items-center mb-8 gap-4 animate-fade-in-up">
                <div className="flex items-center gap-4 group cursor-default">
                    <div className="w-14 h-14 rounded-full bg-black/60 border border-cyan-500/50 flex flex-col justify-center items-center shadow-[0_0_20px_rgba(6,182,212,0.4)] relative overflow-hidden transition-transform duration-500 group-hover:rotate-180">
                         <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/20 to-purple-500/20 group-hover:opacity-100 transition-opacity"></div>
                         {/* Tech Ring */}
                         <div className="absolute inset-1 border border-cyan-300/30 rounded-full border-dashed animate-spin duration-[10s]"></div>
                         <h1 className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 to-blue-500 z-10 font-['Orbitron'] tracking-tighter">V2H</h1>
                    </div>
                    <div>
                        <h1 className="text-2xl md:text-3xl font-bold text-white tracking-tight drop-shadow-md">{t('app_name')}</h1>
                        <p className="text-xs md:text-sm text-cyan-400/80 font-light tracking-widest uppercase">{t('slogan')}</p>
                    </div>
                </div>
                 {userData && appState !== 'FORM' && appState !== 'ANALYZING' && appState !== 'SPLASH' && (
                    <div className="flex items-center gap-4 bg-black/40 p-2 pr-4 rounded-full border border-gray-700/50 backdrop-blur-md shadow-lg hover:border-cyan-500/30 transition-colors">
                        <div className="relative group cursor-pointer">
                            <div className="absolute -inset-0.5 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full opacity-75 group-hover:opacity-100 blur transition duration-200"></div>
                            <img 
                                src={userData.avatar || `https://i.pravatar.cc/150?u=${userData.phone}`} 
                                alt="Avatar" 
                                className={`relative w-10 h-10 rounded-full border-2 object-cover bg-gray-900 ${isAvatarGenerating ? 'animate-pulse' : ''}`} 
                                style={{borderColor: userData.loyaltyTier === 'Kim Cương' ? '#22d3ee' : userData.loyaltyTier === 'Vàng' ? '#facc15' : '#374151'}}
                            />
                             {isAvatarGenerating && (
                                <div className="absolute inset-0 flex items-center justify-center bg-black/60 rounded-full z-10">
                                    <SpinnerIcon className="w-4 h-4 text-white" />
                                </div>
                            )}
                        </div>
                        <div className="text-right hidden sm:block">
                            <p className="text-sm font-bold text-white leading-tight">{userData.fullName}</p>
                            <div className="flex items-center justify-end gap-1.5 text-[10px] uppercase tracking-wide mt-0.5">
                                <span className={`${LOYALTY_TIERS[userData.loyaltyTier].color} font-bold`}>{userData.loyaltyTier}</span>
                                <span className="text-gray-600">|</span>
                                <span className="text-yellow-400 flex items-center gap-1 font-bold"><MedalIcon className="w-3 h-3" /> {userData.loyaltyPoints}</span>
                            </div>
                        </div>
                        <button onClick={handleInactivityLogout} className="text-gray-400 hover:text-red-400 transition-colors p-1 rounded-full hover:bg-white/5" title={t('logout')}>
                            <LockClosedIcon className="w-4 h-4" />
                        </button>
                    </div>
                )}
             </header>

             {userData && appState !== 'SPLASH' && appState !== 'FORM' && appState !== 'ANALYZING' && (
                 <nav className="flex flex-wrap gap-3 mb-8 justify-center sm:justify-start bg-black/20 p-2 rounded-2xl backdrop-blur-md border border-gray-800/50 shadow-inner relative z-40 transition-all duration-300">
                    {[
                        { id: 'MENU', icon: BuildingStorefrontIcon, label: t('menu') },
                        { id: 'FORM', icon: IdentificationIcon, label: t('personal_info') },
                        { id: 'PROFILE', icon: ClipboardDocumentListIcon, label: t('profile') },
                        { id: 'MEAL_PLAN', icon: CalendarIcon, label: t('weekly_plan') },
                        { id: 'REPORT', icon: ChartIcon, label: t('report') },
                        { id: 'HISTORY', icon: HistoryIcon, label: t('history') },
                        { id: 'LEADERBOARD', icon: TrophyIcon, label: t('rank') },
                        { id: 'CONTACT', icon: MapPinIcon, label: t('contact') },
                    ].map(item => (
                        <button 
                            key={item.id}
                            onClick={() => {
                                if (item.id === 'MENU') handleBackToMenu();
                                else if (item.id === 'FORM') handleBackToForm();
                                else if (item.id === 'PROFILE') handleViewProfile();
                                else if (item.id === 'MEAL_PLAN') handleViewPlanner();
                                else if (item.id === 'REPORT') handleViewReport();
                                else if (item.id === 'HISTORY') handleViewHistory();
                                else if (item.id === 'LEADERBOARD') handleViewLeaderboard();
                                else if (item.id === 'CONTACT') setIsMapModalOpen(true);
                            }}
                            className={`flex items-center gap-2 px-4 py-2 rounded-xl transition-all duration-300 text-sm font-medium ${
                                appState === item.id 
                                    ? 'bg-gradient-to-r from-cyan-600/90 to-blue-600/90 text-white shadow-[0_0_15px_rgba(6,182,212,0.4)] border border-cyan-400/30' 
                                    : 'bg-transparent text-gray-400 hover:text-white hover:bg-white/5'
                            }`}
                        >
                            <item.icon className="w-4 h-4" /> {item.label}
                        </button>
                    ))}
                    
                     <button onClick={() => setIsAchievementsModalOpen(true)} className="flex items-center gap-2 px-4 py-2 rounded-xl transition-all bg-transparent text-gray-400 hover:text-yellow-300 hover:bg-yellow-900/10 text-sm font-medium ml-auto">
                         <MedalIcon className="w-4 h-4" /> <span className="hidden md:inline">{t('achievements')}</span>
                    </button>
                     <button onClick={() => setAppState('ADMIN')} className="flex items-center gap-2 px-4 py-2 rounded-xl transition-all bg-transparent text-gray-500 hover:text-red-400 hover:bg-red-900/10 text-sm font-medium">
                         <CogIcon className="w-4 h-4" />
                    </button>
                 </nav>
             )}

             <main className="relative z-10 min-h-[60vh] transition-all duration-500">
                {renderContent()}
             </main>

             {userData && appState !== 'SPLASH' && (
                <>
                    <button 
                        onClick={() => setIsChatbotOpen(!isChatbotOpen)}
                        className="fixed bottom-8 right-8 bg-gradient-to-br from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white p-4 rounded-full shadow-[0_0_30px_rgba(6,182,212,0.5)] z-50 transition-all hover:scale-110 group border border-cyan-300/50"
                        aria-label={t('chat_ai')}
                    >
                        <div className="absolute inset-0 rounded-full animate-ping bg-cyan-400 opacity-20 group-hover:opacity-40"></div>
                        <ChatBubbleIcon className="w-7 h-7 relative z-10" />
                    </button>
                </>
             )}

            {isChatbotOpen && <Chatbot onClose={() => setIsChatbotOpen(false)} menuItems={menuItems} language={currentLanguage} />}
            
            <AchievementsModal 
                isOpen={isAchievementsModalOpen} 
                onClose={() => setIsAchievementsModalOpen(false)} 
                earnedAchievements={userData?.achievements || []} 
                language={currentLanguage}
            />

            <MapModal isOpen={isMapModalOpen} onClose={() => setIsMapModalOpen(false)} language={currentLanguage} />

            {activePromotion && (
                <PromotionModal 
                    promotion={activePromotion} 
                    onClose={handleDismissPromotion}
                    onConfirm={handleApplyPromotion}
                    language={currentLanguage}
                />
            )}
        </div>
    </div>
  );
};

export default App;
